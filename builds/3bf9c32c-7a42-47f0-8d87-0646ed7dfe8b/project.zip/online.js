/* Bena Chess Tutor — Online mode
   Peer-to-peer via WebRTC data channel. No signaling server: connection is
   established by copy-pasting two short "codes" (compressed session descriptions).
   One player creates a room (gets a HOST CODE to send to the friend),
   the friend joins with that code (gets back a JOIN CODE to send to the host),
   the host pastes the JOIN CODE to complete the connection.
*/
function encodeSD(desc) {
  return btoa(unescape(encodeURIComponent(JSON.stringify(desc))));
}
function decodeSD(code) {
  return JSON.parse(decodeURIComponent(escape(atob(code.trim()))));
}

function waitForIce(pc) {
  return new Promise((resolve) => {
    if (pc.iceGatheringState === 'complete') return resolve();
    const timeout = setTimeout(() => resolve(), 3500);
    pc.addEventListener('icegatheringstatechange', function handler() {
      if (pc.iceGatheringState === 'complete') {
        clearTimeout(timeout);
        pc.removeEventListener('icegatheringstatechange', handler);
        resolve();
      }
    });
  });
}

function OnlineMode({ onExit, mode3d }) {
  const CE = window.ChessEngine;
  const [tab, setTab] = useState('host'); // 'host' | 'join'
  const [hostCode, setHostCode] = useState('');
  const [joinInput, setJoinInput] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [answerInput, setAnswerInput] = useState('');
  const [connState, setConnState] = useState('idle'); // idle, waiting-answer, connecting, connected, error
  const [myColor, setMyColor] = useState(null);
  const [state, setState] = useState(CE.initialState());
  const [lastMove, setLastMove] = useState(null);
  const [flipped, setFlipped] = useState(false);

  const pcRef = useRef(null);
  const dcRef = useRef(null);

  function setupDataChannel(dc) {
    dcRef.current = dc;
    dc.onopen = () => setConnState('connected');
    dc.onclose = () => setConnState('idle');
    dc.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === 'move') {
          setState((prev) => {
            const legal = CE.legalMoves(prev, prev.turn);
            const found = legal.find(
              (m) => m.from[0] === msg.move.from[0] && m.from[1] === msg.move.from[1] &&
                     m.to[0] === msg.move.to[0] && m.to[1] === msg.move.to[1] &&
                     (m.promotion || null) === (msg.move.promotion || null)
            );
            if (!found) return prev;
            setLastMove(found);
            return CE.makeMove(prev, found);
          });
        } else if (msg.type === 'reset') {
          setState(CE.initialState());
          setLastMove(null);
        }
      } catch (e) { /* ignore malformed */ }
    };
  }

  async function createRoom() {
    setConnState('connecting');
    const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    pcRef.current = pc;
    const dc = pc.createDataChannel('chess');
    setupDataChannel(dc);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await waitForIce(pc);
    setHostCode(encodeSD(pc.localDescription));
    setMyColor('w');
    setConnState('waiting-answer');
  }

  async function completeRoom() {
    try {
      const answer = decodeSD(answerInput);
      await pcRef.current.setRemoteDescription(answer);
      setConnState('connecting');
    } catch (e) {
      setConnState('error');
    }
  }

  async function joinRoom() {
    try {
      setConnState('connecting');
      const offer = decodeSD(joinInput);
      const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
      pcRef.current = pc;
      pc.ondatachannel = (ev) => setupDataChannel(ev.channel);
      await pc.setRemoteDescription(offer);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await waitForIce(pc);
      setJoinCode(encodeSD(pc.localDescription));
      setMyColor('b');
      setFlipped(true);
    } catch (e) {
      setConnState('error');
    }
  }

  function sendMove(move) {
    if (dcRef.current && dcRef.current.readyState === 'open') {
      dcRef.current.send(JSON.stringify({ type: 'move', move: { from: move.from, to: move.to, promotion: move.promotion || null } }));
    }
  }

  function handleUserMove(move) {
    if (myColor !== state.turn) return; // not your turn / not your color
    setState((prev) => {
      const next = CE.makeMove(prev, move);
      setLastMove(move);
      return next;
    });
    sendMove(move);
  }

  function resetGame() {
    setState(CE.initialState());
    setLastMove(null);
    if (dcRef.current && dcRef.current.readyState === 'open') {
      dcRef.current.send(JSON.stringify({ type: 'reset' }));
    }
  }

  useEffect(() => () => {
    if (pcRef.current) pcRef.current.close();
  }, []);

  const status = CE.gameStatus(state);
  let statusText = myColor
    ? (state.turn === myColor ? 'Your move' : "Opponent's move")
    : 'Not connected yet';
  if (status.status === 'checkmate') statusText = `Checkmate — ${status.winner === 'w' ? 'White' : 'Black'} wins!`;
  else if (status.status === 'stalemate') statusText = 'Stalemate — draw';

  if (connState === 'connected') {
    return (
      <div className="main-area">
        <button className="back-link" onClick={onExit}>&larr; Back</button>
        <h2 className="section-title">Playing Online</h2>
        <p className="section-sub">You are {myColor === 'w' ? 'White' : 'Black'} · {statusText}</p>
        <div className="play-layout">
          <div className="board-column">
            <ChessBoard
              state={state}
              mode3d={mode3d}
              flipped={flipped}
              interactive={myColor === state.turn && (status.status === 'active' || status.status === 'check')}
              onUserMove={handleUserMove}
              arrow={null}
              lastMove={lastMove}
              size="normal"
            />
            <div className="btn-row">
              <button className="btn secondary" onClick={resetGame}>New game</button>
            </div>
          </div>
          <div className="side-panel">
            <h4>Connection</h4>
            <p>Live peer-to-peer game — moves sync instantly, no server involved.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="main-area">
      <button className="back-link" onClick={onExit}>&larr; Back</button>
      <h2 className="section-title">Play Online</h2>
      <p className="section-sub">Connect directly with a friend using a one-time code. No accounts, no server.</p>
      <div className="online-box">
        <div className="tabs">
          <button className={tab === 'host' ? 'active' : ''} onClick={() => setTab('host')}>Create room</button>
          <button className={tab === 'join' ? 'active' : ''} onClick={() => setTab('join')}>Join room</button>
        </div>

        {tab === 'host' && (
          <>
            <p className="status-line">1. Create a room, then send the host code to your friend.</p>
            <button className="btn" onClick={createRoom} disabled={connState !== 'idle'}>Create room</button>
            {hostCode && (
              <>
                <textarea className="code-area" readOnly value={hostCode} onClick={(e) => e.target.select()} />
                <button className="btn secondary" onClick={() => navigator.clipboard && navigator.clipboard.writeText(hostCode)}>Copy host code</button>
                <p className="status-line">2. Paste the join code your friend sends back:</p>
                <textarea
                  className="code-area"
                  placeholder="Paste join code here"
                  value={answerInput}
                  onChange={(e) => setAnswerInput(e.target.value)}
                />
                <button className="btn" onClick={completeRoom}>Connect</button>
              </>
            )}
          </>
        )}

        {tab === 'join' && (
          <>
            <p className="status-line">1. Paste the host code your friend sent you:</p>
            <textarea
              className="code-area"
              placeholder="Paste host code here"
              value={joinInput}
              onChange={(e) => setJoinInput(e.target.value)}
            />
            <button className="btn" onClick={joinRoom}>Join room</button>
            {joinCode && (
              <>
                <p className="status-line">2. Send this join code back to your friend:</p>
                <textarea className="code-area" readOnly value={joinCode} onClick={(e) => e.target.select()} />
                <button className="btn secondary" onClick={() => navigator.clipboard && navigator.clipboard.writeText(joinCode)}>Copy join code</button>
                <p className="status-line">Waiting for them to connect…</p>
              </>
            )}
          </>
        )}
        {connState === 'error' && <p className="status-line" style={{ color: '#c15a4a' }}>That code didn't work — double check it was copied in full.</p>}
      </div>
    </div>
  );
}

window.OnlineMode = OnlineMode;
