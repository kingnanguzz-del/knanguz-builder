# Bena Chess Tutor

A full chess learning app: 6 levels (piece basics → openings → tactics → real
coached games), 2D and 3D board styles, animated (non-teleporting) moves,
arrow-based move explanations, offline pass-and-play, and online play with a
friend via a one-time connection code — no backend server required.

## How to run it

No build step needed — it's plain React loaded from a CDN.

1. Unzip the folder.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, Safari).
   - Easiest: double-click it, or right-click → "Open with" your browser.
   - If your browser blocks local file scripts, instead run a tiny local
     server from inside the folder, e.g. `python3 -m http.server 8080`, then
     visit `http://localhost:8080`.
3. You need an internet connection the first time you open it (to load React
   from cdnjs) and while using **Play Online** (for the peer-to-peer
   connection). Everything else works fully offline once loaded.

## What's inside

- **Level 1 — First Steps**: how each piece moves, one at a time.
- **Level 2 — Openings & Principles**: center control, development, castling.
- **Level 3 — Tactics 101**: forks, pins, skewers — with arrow overlays
  showing exactly which square to move to and why.
- **Levels 4-6 — Guided Games / Club Player / Pro Challenge**: real games
  against a built-in engine (progressively stronger). After every move you
  make, the coach explains whether it was good, an inaccuracy, a mistake, or
  a blunder — and what the concrete consequence is (e.g. "this hangs your
  knight on c4") rather than just a score.
- **2D / 3D toggle**: 3D mode tilts the board and gives pieces a raised,
  extruded look using CSS (no external 3D asset files needed). It's a
  stylized "tabletop" 3D, not a photoreal 3D engine — a fully photoreal 3D
  mode with lit, textured piece models would need real 3D assets (e.g.
  GLTF models) that aren't included here.
- **Offline / pass-and-play**: the board fills the screen, can be switched
  between vertical and horizontal layout, and auto-flips 180° after each
  move so it's always right-side-up for whoever is moving.
- **Online play**: fully peer-to-peer using WebRTC. One player taps
  "Create room" and sends the generated code to a friend; the friend pastes
  it under "Join room" and sends back their own short code; the first player
  pastes that to connect. After that, moves sync instantly with no server or
  account involved. (This manual-code approach was chosen specifically so
  the app needs no backend of its own — if you'd rather have instant
  matchmaking without copy-pasting codes, that would need a small signaling
  server, which isn't included.)
- **Real chess rules engine** (`chessEngine.js`): full legal move generation,
  check/checkmate/stalemate detection, castling, en passant, and pawn
  promotion — written from scratch, no chess library dependency.

## File structure

```
index.html        Entry point, loads everything
styles.css         All visual design
chessEngine.js     Chess rules, AI, and move-quality coaching logic
levels.js          The 6 levels and their lesson content
board.js           The chessboard component (2D/3D, arrows, promotion)
lesson.js          Level 1-3 guided lesson runner
play.js            Level 4-6 real games vs. the built-in opponent
offline.js         Local two-player pass-and-play screen
online.js          Peer-to-peer online play (WebRTC + manual code exchange)
app.js             Home screen, level select, and screen routing
```

## Notes on honesty about scope

- The built-in opponent is a from-scratch minimax engine with alpha-beta
  pruning (depth 1-3 depending on level) — solid for teaching purposes, but
  it is not a tournament-strength engine like Stockfish.
- Piece movement animates smoothly between squares (CSS transitions) rather
  than jumping instantly.
- No user accounts or persistence are included — each session starts fresh.
