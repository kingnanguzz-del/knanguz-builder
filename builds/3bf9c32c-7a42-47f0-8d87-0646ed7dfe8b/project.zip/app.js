/* Bena Chess Tutor — App shell */
function App() {
  const [screen, setScreen] = useState('home'); // home | levels | lesson | play | online
  const [activeLevel, setActiveLevel] = useState(null);
  const [mode3d, setMode3d] = useState(false);
  const [offlineOpen, setOfflineOpen] = useState(false);

  const LEVELS = window.BenaLevels.LEVELS;

  function openLevel(level) {
    setActiveLevel(level);
    setScreen(level.type === 'lesson' ? 'lesson' : 'play');
  }

  function goHome() {
    setScreen('home');
    setActiveLevel(null);
  }

  if (offlineOpen) {
    return <OfflineMode onExit={() => setOfflineOpen(false)} mode3d={mode3d} />;
  }

  return (
    <div className="app-shell">
      <div className="topbar">
        <div className="brand" onClick={goHome}>
          <span className="brand-mark">&#9819;</span>
          <span className="brand-name"><b>Bena</b> Chess Tutor</span>
        </div>
        <div className="topbar-actions">
          <div className="pill-toggle">
            <button className={!mode3d ? 'active' : ''} onClick={() => setMode3d(false)}>2D</button>
            <button className={mode3d ? 'active' : ''} onClick={() => setMode3d(true)}>3D</button>
          </div>
          {screen !== 'home' && <button className="icon-btn" onClick={goHome}>Home</button>}
        </div>
      </div>

      {screen === 'home' && (
        <HomeScreen
          onLearn={() => setScreen('levels')}
          onOffline={() => setOfflineOpen(true)}
          onOnline={() => setScreen('online')}
        />
      )}

      {screen === 'levels' && (
        <LevelSelect levels={LEVELS} onSelect={openLevel} />
      )}

      {screen === 'lesson' && activeLevel && (
        <LessonMode level={activeLevel} mode3d={mode3d} onExit={() => setScreen('levels')} />
      )}

      {screen === 'play' && activeLevel && (
        <PlayMode level={activeLevel} mode3d={mode3d} onExit={() => setScreen('levels')} />
      )}

      {screen === 'online' && (
        <OnlineMode mode3d={mode3d} onExit={goHome} />
      )}
    </div>
  );
}

function HomeScreen({ onLearn, onOffline, onOnline }) {
  return (
    <div className="main-area">
      <div className="hero">
        <div className="hero-eyebrow">Learn chess the right way</div>
        <h1>Real teaching. Real games. <em>Zero trolling.</em></h1>
        <p>
          Six structured levels take you from "how does a knight move" to
          full games with professional-style coaching — plus 3D and 2D boards,
          and offline or online play with a friend.
        </p>
      </div>

      <div className="mode-grid">
        <button className="mode-card" onClick={onLearn}>
          <span className="glyph">&#9812;</span>
          <h3>Learn — 6 Levels</h3>
          <p>Guided lessons on piece movement, opening principles and tactics, then real games with live coaching against a built-in opponent.</p>
        </button>
        <button className="mode-card" onClick={onOffline}>
          <span className="glyph">&#9822;</span>
          <h3>Play Offline (pass & play)</h3>
          <p>Two players, one phone. The board fills the whole screen, auto-flips between turns, and works in vertical or horizontal orientation.</p>
        </button>
        <button className="mode-card" onClick={onOnline}>
          <span className="glyph">&#9819;</span>
          <h3>Play Online</h3>
          <p>Connect directly to a friend with a one-time room code — no account, no server, just a live synced game.</p>
        </button>
      </div>
    </div>
  );
}

function LevelSelect({ levels, onSelect }) {
  return (
    <div className="main-area">
      <h2 className="section-title">Choose your level</h2>
      <p className="section-sub">Levels 1-3 are guided lessons. Levels 4-6 are real games with live coaching.</p>
      <div className="level-grid">
        {levels.map((lvl) => (
          <div className="level-card" key={lvl.id}>
            <span className={`level-tag ${lvl.type === 'play' ? 'play' : ''}`}>{lvl.type === 'play' ? 'Real game' : 'Lesson'}</span>
            <h3>{lvl.title}</h3>
            <div className="sub">{lvl.subtitle}</div>
            <div className="stars">{'\u2605'.repeat(lvl.difficulty)}{'\u2606'.repeat(6 - lvl.difficulty)}</div>
            <p>{lvl.description}</p>
            <button onClick={() => onSelect(lvl)}>{lvl.type === 'play' ? 'Play' : 'Start lessons'}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
