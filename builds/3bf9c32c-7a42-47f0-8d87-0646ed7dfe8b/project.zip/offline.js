/* Bena Chess Tutor — Offline two-player (same device) mode */
function OfflineMode({ onExit, mode3d }) {
  const CE = window.ChessEngine;
  const [state, setState] = useState(CE.initialState());
  const [lastMove, setLastMove] = useState(null);
  const [orientation, setOrientation] = useState('portrait'); // 'portrait' | 'landscape'
  const [autoFlip, setAutoFlip] = useState(true);
  const [flipped, setFlipped] = useState(false);
  const [status, setStatus] = useState({ status: 'active' });

  const handleMove = useCallback((move) => {
    setState((prev) => {
      const next = CE.makeMove(prev, move);
      setLastMove(move);
      setStatus(CE.gameStatus(next));
      if (autoFlip) setFlipped(next.turn === 'b');
      return next;
    });
  }, [autoFlip]);

  function resetGame() {
    setState(CE.initialState());
    setLastMove(null);
    setStatus({ status: 'active' });
    setFlipped(false);
  }

  const whiteName = orientation === 'landscape' ? 'Player 1 (White)' : 'White';
  const blackName = orientation === 'landscape' ? 'Player 2 (Black)' : 'Black';

  let statusText = state.turn === 'w' ? "White to move" : "Black to move";
  if (status.status === 'checkmate') statusText = `Checkmate — ${status.winner === 'w' ? 'White' : 'Black'} wins!`;
  else if (status.status === 'stalemate') statusText = 'Stalemate — draw';
  else if (status.status === 'check') statusText = `${state.turn === 'w' ? 'White' : 'Black'} is in check`;

  return (
    <div className={`offline-fullscreen orientation-${orientation}`}>
      <div className="offline-topbar">
        <button className="icon-btn" onClick={onExit}>&larr; Exit</button>
        <div className="btn-row">
          <button
            className="icon-btn"
            onClick={() => setOrientation(orientation === 'portrait' ? 'landscape' : 'portrait')}
          >
            {orientation === 'portrait' ? 'Vertical' : 'Horizontal'} view
          </button>
          <button className="icon-btn" onClick={() => setAutoFlip(!autoFlip)}>
            Auto-flip: {autoFlip ? 'On' : 'Off'}
          </button>
          <button className="icon-btn" onClick={resetGame}>New game</button>
        </div>
      </div>

      <div className="offline-label-top">{blackName}</div>

      <ChessBoard
        state={state}
        mode3d={mode3d}
        flipped={flipped}
        interactive={status.status === 'active' || status.status === 'check'}
        onUserMove={handleMove}
        arrow={null}
        lastMove={lastMove}
        size="normal"
      />

      <div className="offline-label-bottom">{whiteName}</div>
      <div className="status-line" style={{ position: 'absolute', bottom: 14 }}>{statusText}</div>
    </div>
  );
}

window.OfflineMode = OfflineMode;
