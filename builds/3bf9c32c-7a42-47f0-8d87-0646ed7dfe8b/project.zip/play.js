/* Bena Chess Tutor — Play vs AI mode (Levels 4-6) */
function PlayMode({ level, onExit, mode3d }) {
  const CE = window.ChessEngine;
  const depth = level.aiDepth || 2;
  const [state, setState] = useState(CE.initialState());
  const [lastMove, setLastMove] = useState(null);
  const [coaching, setCoaching] = useState(null);
  const [thinking, setThinking] = useState(false);
  const [hintArrow, setHintArrow] = useState(null);
  const [humanColor] = useState('w');
  const [history, setHistory] = useState([]);

  const status = CE.gameStatus(state);

  function describeMove(m, board) {
    const p = board[m.from[0]][m.from[1]];
    return `${CE.pieceName(p)} ${CE.squareName(m.from[0], m.from[1])}-${CE.squareName(m.to[0], m.to[1])}`;
  }

  function handleUserMove(move) {
    if (state.turn !== humanColor || thinking) return;
    setHintArrow(null);
    const before = state;
    const explanation = level.coaching ? CE.explainMove(before, move, Math.max(depth, 1)) : null;
    const next = CE.makeMove(before, move);
    setState(next);
    setLastMove(move);
    setHistory((h) => h.concat([describeMove(move, before.board)]));
    if (explanation) setCoaching(explanation);
    setThinking(true);
  }

  // AI reply
  useEffect(() => {
    if (state.turn === humanColor) return;
    const st = CE.gameStatus(state);
    if (st.status === 'checkmate' || st.status === 'stalemate' || st.status === 'draw') {
      setThinking(false);
      return;
    }
    const timer = setTimeout(() => {
      const move = CE.findBestMove(state, depth);
      if (move) {
        setHistory((h) => h.concat([describeMove(move, state.board)]));
        setLastMove(move);
        setState((prev) => CE.makeMove(prev, move));
      }
      setThinking(false);
    }, 550 + Math.random() * 500);
    return () => clearTimeout(timer);
  }, [state, humanColor, depth]);

  function requestHint() {
    const move = CE.findBestMove(state, Math.max(depth, 1));
    if (move) setHintArrow({ from: move.from, to: move.to });
  }

  function resetGame() {
    setState(CE.initialState());
    setLastMove(null);
    setCoaching(null);
    setHintArrow(null);
    setHistory([]);
    setThinking(false);
  }

  let statusText = state.turn === humanColor ? 'Your move' : (thinking ? 'Opponent is thinking…' : "Opponent's move");
  if (status.status === 'checkmate') statusText = `Checkmate — ${status.winner === humanColor ? 'You win!' : 'The opponent wins.'}`;
  else if (status.status === 'stalemate') statusText = 'Stalemate — the game is a draw.';
  else if (status.status === 'check') statusText += ' · Check!';

  return (
    <div className="main-area">
      <button className="back-link" onClick={onExit}>&larr; Levels</button>
      <h2 className="section-title">{level.title}</h2>
      <p className="section-sub">{level.subtitle}</p>

      <div className="play-layout">
        <div className="board-column">
          <div className="status-bar">
            <span className={`turn-dot ${state.turn}`} />
            <span>{statusText}</span>
          </div>
          <ChessBoard
            state={state}
            mode3d={mode3d}
            flipped={false}
            interactive={state.turn === humanColor && !thinking && (status.status === 'active' || status.status === 'check')}
            onUserMove={handleUserMove}
            arrow={hintArrow}
            lastMove={lastMove}
            size="normal"
          />
          <div className="btn-row">
            <button className="btn secondary" onClick={requestHint} disabled={state.turn !== humanColor}>Show hint arrow</button>
            <button className="btn secondary" onClick={resetGame}>New game</button>
          </div>
        </div>

        <div className="side-panel">
          <h4>Coach</h4>
          {!coaching && <p>Play a move — you'll get instant, professional feedback here, not just a score.</p>}
          {coaching && (
            <div className={`coach-box tone-${coaching.tone}`}>
              <span className="coach-title">{coaching.quality}</span>
              {coaching.text}
            </div>
          )}
          <h4 style={{ marginTop: 18 }}>Move list</h4>
          <div className="move-history">
            {history.length === 0 && <div>No moves yet.</div>}
            {history.map((h, i) => <div key={i}>{i + 1}. {h}</div>)}
          </div>
        </div>
      </div>
    </div>
  );
}

window.PlayMode = PlayMode;
