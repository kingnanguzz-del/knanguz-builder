/* Bena Chess Tutor — Level & Lesson Content
   Levels 1-3: guided lessons (a fixed position, a correct idea, an arrow, and an explanation).
   Levels 4-6: real games against the built-in AI, with live coaching after each move.
*/
(function (global) {
  // FEN-like simple position setup: array of [square, piece] using 'wP' style codes.
  // Helper to build a board from a list of placements; everything else empty.
  function boardFrom(placements) {
    const b = Array.from({ length: 8 }, () => Array(8).fill(null));
    const fileIdx = { a: 0, b: 1, c: 2, d: 3, e: 4, f: 5, g: 6, h: 7 };
    placements.forEach(([sq, piece]) => {
      const file = sq[0];
      const rank = parseInt(sq[1], 10);
      const c = fileIdx[file];
      const r = 8 - rank;
      b[r][c] = piece;
    });
    return b;
  }

  const LEVELS = [
    {
      id: 1,
      title: 'Level 1 — First Steps',
      subtitle: 'How each piece moves',
      difficulty: 1,
      type: 'lesson',
      description: 'Learn how each piece moves and captures, one at a time, with no pressure.',
      lessons: [
        {
          key: 'pawn-move',
          instruction: 'Pawns move straight ahead, but capture diagonally. Move the white pawn forward two squares.',
          board: boardFrom([['e2', 'wP'], ['e8', 'bK'], ['e1', 'wK']]),
          turn: 'w',
          from: 'e2',
          to: 'e4',
          explanation: 'On its first move, a pawn may advance one or two squares. After this, it can only move one square at a time.',
        },
        {
          key: 'knight-move',
          instruction: 'Knights move in an L-shape and are the only piece that can jump over others. Move the knight to f3.',
          board: boardFrom([['g1', 'wN'], ['e1', 'wK'], ['e8', 'bK']]),
          turn: 'w',
          from: 'g1',
          to: 'f3',
          explanation: 'Knights hop two squares in one direction and one square perpendicular. They ignore pieces in between — a unique power.',
        },
        {
          key: 'bishop-move',
          instruction: 'Bishops slide diagonally, any distance. Move the bishop to capture the pawn on b5.',
          board: boardFrom([['c4', 'wB'], ['b5', 'bP'], ['e1', 'wK'], ['e8', 'bK']]),
          turn: 'w',
          from: 'c4',
          to: 'b5',
          explanation: 'A bishop always stays on the same color square for the whole game. Two bishops together cover both colors.',
        },
        {
          key: 'rook-move',
          instruction: 'Rooks slide horizontally or vertically. Move the rook to d8, delivering check!',
          board: boardFrom([['d1', 'wR'], ['e1', 'wK'], ['d8', 'bK']]),
          turn: 'w',
          from: 'd1',
          to: 'd8',
          explanation: 'Rooks are powerful on open files and ranks. This move puts the black king in check because it shares the d-file.',
        },
        {
          key: 'queen-move',
          instruction: 'The Queen combines the rook and bishop — she can move any direction, any distance. Capture the pawn on e6.',
          board: boardFrom([['a2', 'wQ'], ['e6', 'bP'], ['e1', 'wK'], ['h8', 'bK']]),
          turn: 'w',
          from: 'a2',
          to: 'e6',
          explanation: 'The queen reached e6 along the a2-e6 diagonal — the same move a bishop could make. On an open rank or file she moves like a rook instead. That flexibility makes her the most powerful piece on the board.',
        },
        {
          key: 'king-move',
          instruction: 'The King moves one square any direction, but must never move into check. Move the king to f2, away from danger.',
          board: boardFrom([['e1', 'wK'], ['e8', 'bR'], ['h8', 'bK']]),
          turn: 'w',
          from: 'e1',
          to: 'f2',
          explanation: 'The king is currently in check from the rook on the open e-file. Stepping to f2 escapes the attack safely.',
        },
      ],
    },
    {
      id: 2,
      title: 'Level 2 — Openings & Principles',
      subtitle: 'Control the center, develop, castle',
      difficulty: 2,
      type: 'lesson',
      description: 'Understand why strong players control the center, develop pieces quickly, and castle early.',
      lessons: [
        {
          key: 'center-control',
          instruction: 'Start the game by claiming the center. Play the classic move e4.',
          board: null, // null = use standard starting position
          turn: 'w',
          from: 'e2',
          to: 'e4',
          explanation: 'Central pawns open lines for your bishops and queen, and control key squares your opponent wants.',
        },
        {
          key: 'develop-knight',
          instruction: 'After 1.e4 e5, develop a knight toward the center rather than moving the same pawn again.',
          board: boardFrom([
            ['e4', 'wP'], ['e5', 'bP'], ['g1', 'wN'], ['e1', 'wK'], ['e8', 'bK'],
            ['d1', 'wQ'], ['a1', 'wR'], ['h1', 'wR'], ['a8', 'bR'], ['h8', 'bR'],
          ]),
          turn: 'w',
          from: 'g1',
          to: 'f3',
          explanation: 'Nf3 develops toward the center and attacks e5. Good openings bring pieces out before launching attacks.',
        },
        {
          key: 'castle-early',
          instruction: 'Your king is safest tucked behind pawns. Castle kingside now that the squares are clear.',
          board: boardFrom([
            ['e1', 'wK'], ['h1', 'wR'], ['g3', 'wP'],
            ['e8', 'bK'], ['h8', 'bR'], ['e4', 'wP'], ['e5', 'bP'], ['f3', 'wN'], ['d6', 'bB'],
          ]),
          turn: 'w',
          from: 'e1',
          to: 'g1',
          explanation: 'Castling moves your king to safety and activates a rook in one move — one of the most valuable moves in chess.',
        },
      ],
    },
    {
      id: 3,
      title: 'Level 3 — Tactics 101',
      subtitle: 'Forks, pins, and skewers',
      difficulty: 3,
      type: 'lesson',
      description: 'Spot the tactical patterns that win material: forks, pins, and skewers.',
      lessons: [
        {
          key: 'knight-fork',
          instruction: 'Knights are fork machines. Find the move that attacks both the king and the rook at once.',
          board: boardFrom([['e5', 'wN'], ['a1', 'wK'], ['d8', 'bK'], ['b8', 'bR']]),
          turn: 'w',
          from: 'e5',
          to: 'c6',
          explanation: 'This is a "family fork" — from c6 the knight attacks the king on d8 (forcing it to move) and the rook on b8, winning it next move.',
        },
        {
          key: 'pin-and-win',
          instruction: 'The bishop can pin the knight to the king so it cannot safely move. Play the pinning move.',
          board: boardFrom([['f1', 'wB'], ['c6', 'bN'], ['e8', 'bK'], ['e1', 'wK'], ['e4', 'wP'], ['e5', 'bP']]),
          turn: 'w',
          from: 'f1',
          to: 'b5',
          explanation: 'Bb5 pins the knight on c6 to the black king along the e8-b5 diagonal. The knight cannot move without exposing the king to check, so it is effectively frozen — a classic opening pin.',
        },
        {
          key: 'skewer',
          instruction: 'Move the rook onto the e-file to skewer the king and the queen behind it.',
          board: boardFrom([['a1', 'wR'], ['e5', 'bK'], ['e8', 'bQ'], ['h1', 'wK']]),
          turn: 'w',
          from: 'a1',
          to: 'e1',
          explanation: 'Re1 attacks the king along the e-file, with the queen sitting right behind it. The king must move out of check, and then the rook captures the queen for free — that is a skewer.',
        },
      ],
    },
    {
      id: 4,
      title: 'Level 4 — Guided Games',
      subtitle: 'Play a full game with live coaching',
      difficulty: 4,
      type: 'play',
      description: 'Play full games against a beginner-friendly opponent. Every move you make is reviewed instantly.',
      aiDepth: 1,
      coaching: true,
    },
    {
      id: 5,
      title: 'Level 5 — Club Player',
      subtitle: 'A tougher opponent, deeper coaching',
      difficulty: 5,
      type: 'play',
      description: 'The engine plays more solidly. Expect it to punish loose moves and hanging pieces.',
      aiDepth: 2,
      coaching: true,
    },
    {
      id: 6,
      title: 'Level 6 — Pro Challenge',
      subtitle: 'Real competitive test',
      difficulty: 6,
      type: 'play',
      description: 'The strongest built-in opponent. Sharpen your calculation and try to hold your own.',
      aiDepth: 3,
      coaching: true,
    },
  ];

  global.BenaLevels = { LEVELS, boardFrom };
})(window);
