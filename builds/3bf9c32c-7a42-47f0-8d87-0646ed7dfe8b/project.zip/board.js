/* Bena Chess Tutor — Board component
   Renders the chessboard, handles piece selection/movement, arrow hints, 2D/3D style.
*/
const { useState, useEffect, useRef, useCallback } = React;

const PIECE_GLYPHS = {
  wK: '\u2654', wQ: '\u2655', wR: '\u2656', wB: '\u2657', wN: '\u2658', wP: '\u2659',
  bK: '\u265A', bQ: '\u265B', bR: '\u265C', bB: '\u265D', bN: '\u265E', bP: '\u265F',
};

function ChessBoard({
  state,
  mode3d,
  flipped,
  interactive,
  onUserMove,
  arrow, // {from:[r,c], to:[r,c]} or null
  lastMove,
  size, // 'normal' | 'small'
  orientation, // used for offline mode label
}) {
  const CE = window.ChessEngine;
  const [selected, setSelected] = useState(null); // [r,c]
  const [legalTargets, setLegalTargets] = useState([]);
  const [pendingPromotion, setPendingPromotion] = useState(null); // {from,to}
  const boardRef = useRef(null);

  useEffect(() => {
    setSelected(null);
    setLegalTargets([]);
  }, [state.turn, state.history.length]);

  const inCheckSquare = (() => {
    if (!CE.isInCheck(state, state.turn)) return null;
    for (let r = 0; r < 8; r++)
      for (let c = 0; c < 8; c++)
        if (state.board[r][c] === state.turn + 'K') return [r, c];
    return null;
  })();

  function squareClick(r, c) {
    if (!interactive) return;
    const piece = state.board[r][c];

    if (selected) {
      const match = legalTargets.find((m) => m.to[0] === r && m.to[1] === c);
      if (match) {
        if (match.promotion && !pendingPromotion) {
          // need to ask which piece — collect all promotion options for this from/to
          const allPromoMoves = CE.legalMovesForSquare(state, selected[0], selected[1])
            .filter((m) => m.to[0] === r && m.to[1] === c && m.promotion);
          setPendingPromotion({ from: selected, to: [r, c], options: allPromoMoves });
          return;
        }
        onUserMove(match);
        setSelected(null);
        setLegalTargets([]);
        return;
      }
    }
    if (piece && CE.color(piece) === state.turn) {
      setSelected([r, c]);
      setLegalTargets(CE.legalMovesForSquare(state, r, c));
    } else {
      setSelected(null);
      setLegalTargets([]);
    }
  }

  function choosePromotion(move) {
    onUserMove(move);
    setPendingPromotion(null);
    setSelected(null);
    setLegalTargets([]);
  }

  const boardSize = size === 'small' ? 'small' : '';

  return (
    <div className={`board-wrap ${boardSize}`} ref={boardRef}>
      <div className={`board ${mode3d ? 'mode-3d' : ''} ${flipped ? 'flipped' : ''}`}>
        {Array.from({ length: 8 }).map((_, r) =>
          Array.from({ length: 8 }).map((_, c) => {
            const isLight = (r + c) % 2 === 0;
            const isSelected = selected && selected[0] === r && selected[1] === c;
            const isLastFrom = lastMove && lastMove.from[0] === r && lastMove.from[1] === c;
            const isLastTo = lastMove && lastMove.to[0] === r && lastMove.to[1] === c;
            const target = legalTargets.find((m) => m.to[0] === r && m.to[1] === c);
            const isCheckSq = inCheckSquare && inCheckSquare[0] === r && inCheckSquare[1] === c;
            return (
              <div
                key={`${r}-${c}`}
                className={[
                  'square',
                  isLight ? 'light' : 'dark',
                  isSelected ? 'selected' : '',
                  (isLastFrom || isLastTo) ? 'last-move' : '',
                  target ? (target.capture ? 'legal-capture' : 'legal-target') : '',
                  isCheckSq ? 'in-check' : '',
                ].join(' ').trim()}
                onClick={() => squareClick(r, c)}
              >
                {c === 0 && <span className="coord-label coord-rank">{8 - r}</span>}
                {r === 7 && <span className="coord-label coord-file">{'abcdefgh'[c]}</span>}
              </div>
            );
          })
        )}

        <div className="piece-layer">
          {state.board.map((row, r) =>
            row.map((piece, c) => {
              if (!piece) return null;
              const pct = 100 / 8;
              const x = flipped ? (7 - c) * pct : c * pct;
              const y = flipped ? (7 - r) * pct : r * pct;
              return (
                <div
                  key={`piece-${r}-${c}-${piece}`}
                  className={`piece ${CE.color(piece) === 'w' ? 'white' : 'black'}`}
                  style={{
                    transform: `translate(${x}%, ${y}%) ${flipped ? 'rotate(180deg)' : ''}`,
                    left: 0, top: 0,
                  }}
                  onClick={() => squareClick(r, c)}
                >
                  <span className="glyph">{PIECE_GLYPHS[piece]}</span>
                </div>
              );
            })
          )}
        </div>

        {arrow && <ArrowOverlay from={arrow.from} to={arrow.to} flipped={flipped} />}

        {pendingPromotion && (
          <div className="promo-modal">
            <div className="promo-card">
              {['Q', 'R', 'B', 'N'].map((p) => {
                const mv = pendingPromotion.options.find((o) => o.promotion === p);
                const glyph = PIECE_GLYPHS[state.turn + p];
                return (
                  <button key={p} onClick={() => choosePromotion(mv)}>{glyph}</button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ArrowOverlay({ from, to, flipped }) {
  const pct = 100 / 8;
  const cellCenter = (r, c) => {
    const rr = flipped ? 7 - r : r;
    const cc = flipped ? 7 - c : c;
    return [cc * pct + pct / 2, rr * pct + pct / 2];
  };
  const [x1, y1] = cellCenter(from[0], from[1]);
  const [x2, y2] = cellCenter(to[0], to[1]);
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const shorten = 3.2; // percent, so head doesn't overlap piece center fully
  const ex = x2 - Math.cos(angle) * shorten;
  const ey = y2 - Math.sin(angle) * shorten;
  const headLen = 3.4;
  const headWidth = 2.4;
  const hx1 = ex - headLen * Math.cos(angle - 0.5);
  const hy1 = ey - headLen * Math.sin(angle - 0.5);
  const hx2 = ex - headLen * Math.cos(angle + 0.5);
  const hy2 = ey - headLen * Math.sin(angle + 0.5);

  return (
    <svg className="arrow-svg" viewBox="0 0 100 100" preserveAspectRatio="none">
      <line x1={x1} y1={y1} x2={ex} y2={ey} className="arrow-path" vectorEffect="non-scaling-stroke" />
      <polygon className="arrow-head" points={`${ex},${ey} ${hx1},${hy1} ${hx2},${hy2}`} />
    </svg>
  );
}

window.ChessBoard = ChessBoard;
