/* Bena Chess Tutor — Lesson mode (Levels 1-3) */
function buildLessonState(lesson) {
  const CE = window.ChessEngine;
  const board = lesson.board || CE.createInitialBoard();
  return {
    board,
    turn: lesson.turn || 'w',
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassant: null,
    halfmove: 0,
    fullmove: 1,
    history: [],
  };
}

function LessonMode({ level, onExit, mode3d }) {
  const CE = window.ChessEngine;
  const [idx, setIdx] = useState(0);
  const lesson = level.lessons[idx];
  const [state, setState] = useState(() => buildLessonState(lesson));
  const [feedback, setFeedback] = useState(null); // {correct, text}
  const [showHint, setShowHint] = useState(true);
  const [lastMove, setLastMove] = useState(null);
  const [solved, setSolved] = useState(false);

  useEffect(() => {
    setState(buildLessonState(lesson));
    setFeedback(null);
    setLastMove(null);
    setSolved(false);
    setShowHint(true);
  }, [idx, level]);

  function handleMove(move) {
    const targetFrom = squareToRC(lesson.from);
    const targetTo = squareToRC(lesson.to);
    const isCorrect = move.from[0] === targetFrom[0] && move.from[1] === targetFrom[1] &&
                       move.to[0] === targetTo[0] && move.to[1] === targetTo[1];
    const next = CE.makeMove(state, move);
    setState(next);
    setLastMove(move);
    if (isCorrect) {
      setSolved(true);
      setFeedback({ correct: true, text: lesson.explanation });
    } else {
      setFeedback({ correct: false, text: "That's a legal move, but not the idea this lesson is teaching. Try undo and look at the arrow for the recommended square." });
    }
  }

  function undo() {
    setState(buildLessonState(lesson));
    setFeedback(null);
    setLastMove(null);
    setSolved(false);
  }

  function next() {
    if (idx < level.lessons.length - 1) setIdx(idx + 1);
    else onExit();
  }

  const arrow = showHint && !solved ? { from: squareToRC(lesson.from), to: squareToRC(lesson.to) } : null;

  return (
    <div className="main-area">
      <button className="back-link" onClick={onExit}>&larr; Levels</button>
      <h2 className="section-title">{level.title}</h2>
      <p className="section-sub">{level.subtitle}</p>

      <div className="lesson-progress">
        {level.lessons.map((l, i) => (
          <div key={l.key} className={`dot ${i < idx ? 'done' : ''} ${i === idx ? 'current' : ''}`} />
        ))}
      </div>

      <div className="play-layout">
        <div className="board-column">
          <ChessBoard
            state={state}
            mode3d={mode3d}
            flipped={false}
            interactive={!solved}
            onUserMove={handleMove}
            arrow={arrow}
            lastMove={lastMove}
            size="normal"
          />
          <div className="btn-row">
            <button className="btn secondary" onClick={undo}>Reset position</button>
            <button className="btn secondary" onClick={() => setShowHint((s) => !s)}>{showHint ? 'Hide' : 'Show'} arrow</button>
            {solved && <button className="btn" onClick={next}>{idx < level.lessons.length - 1 ? 'Next lesson' : 'Finish level'}</button>}
          </div>
        </div>
        <div className="side-panel">
          <h4>Your task</h4>
          <p>{lesson.instruction}</p>
          {feedback && (
            <div className={`coach-box tone-${feedback.correct ? 'good' : 'warn'}`}>
              <span className="coach-title">{feedback.correct ? 'Well played' : 'Not quite'}</span>
              {feedback.text}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function squareToRC(sq) {
  const file = 'abcdefgh'.indexOf(sq[0]);
  const rank = parseInt(sq[1], 10);
  return [8 - rank, file];
}

window.LessonMode = LessonMode;
