import { useEffect, useRef, useState } from 'react';
import Board from '../components/Board';
import Timer from '../components/Timer';
import type { GameState, Move, Pos } from '../types';
import { applyMove, gameStatus, initialState, pieceGlyph } from '../utils/chessLogic';
import { randomBotMove } from '../utils/bot';

interface Stage4Props {
  onXp: (amount: number) => void;
  onWin: () => void;
}

const TIME_LIMIT = 10 * 60; // 10 minutes, per the brief. One shared game clock (simplified from per-side clocks).

export default function Stage4({ onXp, onWin }: Stage4Props) {
  const [gameKey, setGameKey] = useState(0);
  const [state, setState] = useState<GameState>(initialState());
  const [lastMove, setLastMove] = useState<Move | null>(null);
  const [captured, setCaptured] = useState<{ w: string[]; b: string[] }>({ w: [], b: [] });
  const [result, setResult] = useState<'win' | 'loss' | 'draw' | 'timeout' | null>(null);
  const [botThinking, setBotThinking] = useState(false);
  const awardedRef = useRef(false);

  function resetGame() {
    setState(initialState());
    setLastMove(null);
    setCaptured({ w: [], b: [] });
    setResult(null);
    setBotThinking(false);
    awardedRef.current = false;
    setGameKey((k) => k + 1);
  }

  function recordCapture(move: Move) {
    if (!move.captured) return;
    setCaptured((c) =>
      move.piece.color === 'w'
        ? { ...c, w: [...c.w, move.captured!.type] }
        : { ...c, b: [...c.b, move.captured!.type] }
    );
  }

  function finishIfOver(next: GameState, lastMover: 'w' | 'b') {
    const status = gameStatus(next);
    if (status === 'checkmate') {
      setResult(lastMover === 'w' ? 'win' : 'loss');
      if (lastMover === 'w' && !awardedRef.current) {
        awardedRef.current = true;
        onXp(80);
        onWin();
      }
      return true;
    }
    if (status === 'stalemate') {
      setResult('draw');
      return true;
    }
    return false;
  }

  function handleUserMove(from: Pos, to: Pos) {
    if (result || botThinking) return;
    const piece = state.board[from.row][from.col];
    if (!piece || piece.color !== 'w') return;
    const { state: next, move } = applyMove(state, from, to);
    setState(next);
    setLastMove(move);
    recordCapture(move);
    if (finishIfOver(next, 'w')) return;
    setBotThinking(true);
  }

  useEffect(() => {
    if (!botThinking) return;
    const id = setTimeout(() => {
      const move = randomBotMove(state);
      if (!move) {
        setBotThinking(false);
        return;
      }
      const { state: next, move: applied } = applyMove(state, move.from, move.to);
      setState(next);
      setLastMove(applied);
      recordCapture(applied);
      setBotThinking(false);
      finishIfOver(next, 'b');
    }, 550);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [botThinking]);

  return (
    <div>
      <div className="section-title">Stage 4 · Middlegame</div>
      <p className="section-sub">
        Play a full game against a bot that moves randomly. Punish its mistakes, watch the clock, and try to deliver
        checkmate before time runs out.
      </p>

      <div className="row row--between" style={{ marginBottom: 10 }}>
        <div className="captured-tray">
          {captured.b.map((t, i) => (
            <span key={i}>{pieceGlyph({ type: t as any, color: 'b' })}</span>
          ))}
        </div>
        <Timer
          initialSeconds={TIME_LIMIT}
          running={!result}
          resetKey={gameKey}
          onExpire={() => setResult((r) => r ?? 'timeout')}
        />
      </div>

      <Board state={state} interactiveColor={botThinking || !!result ? 'none' : 'w'} onAttemptMove={handleUserMove} lastMove={lastMove} />

      <div className="captured-tray" style={{ marginTop: 8 }}>
        {captured.w.map((t, i) => (
          <span key={i}>{pieceGlyph({ type: t as any, color: 'w' })}</span>
        ))}
      </div>

      {botThinking && !result && (
        <p className="text-dim text-center" style={{ fontSize: 12.5, marginTop: 8 }}>
          Bot is thinking…
        </p>
      )}

      {result && (
        <div className={`status-banner ${result === 'win' ? 'win' : result === 'loss' || result === 'timeout' ? 'loss' : ''} mt-16`}>
          {result === 'win' && 'Checkmate — you win! +80 XP'}
          {result === 'loss' && 'Checkmate — the bot wins this one.'}
          {result === 'draw' && 'Stalemate — it\'s a draw.'}
          {result === 'timeout' && 'Time\'s up.'}
        </div>
      )}

      <button className="btn btn--ghost btn--block mt-16" onClick={resetGame}>
        ↻ New Game
      </button>
    </div>
  );
}
