import { useMemo, useState } from 'react';
import type { PieceType, Pos, Progress } from '../types';
import { getLegalMoves, initialState, pieceGlyph, samePos } from '../utils/chessLogic';

interface Stage1Props {
  progress: Progress;
  onPieceSeen: (type: PieceType) => void;
}

const PIECE_INFO: Record<PieceType, { name: string; text: string }> = {
  p: {
    name: 'Pawn',
    text: 'Pawns move straight forward one square, or two on their very first move, but they can never move backward. They capture diagonally, one square ahead, which is the opposite direction from how they move. Reach the far end of the board and a pawn promotes into any other piece, almost always a queen.'
  },
  n: {
    name: 'Knight',
    text: 'Knights move in an L-shape: two squares in one direction, then one square perpendicular to that. They are the only piece that can jump clean over other pieces, friend or foe. That makes them tricky to predict and dangerous in cramped positions.'
  },
  b: {
    name: 'Bishop',
    text: 'Bishops slide diagonally as far as the board allows, but never leave the color of square they started on. A pair of bishops working together can cover both light and dark squares. They are strongest on open diagonals with a clear line of sight.'
  },
  r: {
    name: 'Rook',
    text: 'Rooks slide any distance along ranks and files, but never diagonally. They are especially powerful on open files with no pawns blocking them. Rooks also take part in castling, a special king-safety move.'
  },
  q: {
    name: 'Queen',
    text: 'The queen combines the rook and bishop, sliding any distance in any straight or diagonal direction. She is the most powerful piece on the board and should usually be developed after the minor pieces. Losing the queen for less than a queen is almost always a bad trade.'
  },
  k: {
    name: 'King',
    text: 'The king moves one square in any direction and must never be moved into check. Protecting your king, often by castling early, is the top priority in every game. When a king is in check with no way to escape, that is checkmate and the game ends.'
  }
};

export default function Stage1({ progress, onPieceSeen }: Stage1Props) {
  const [selected, setSelected] = useState<Pos | null>(null);
  const [activeType, setActiveType] = useState<PieceType>('p');
  const state = useMemo(() => initialState(), []);

  const legalTargets = useMemo(() => {
    if (!selected) return [];
    return getLegalMoves(state, selected);
  }, [selected, state]);

  function handleSquareClick(pos: Pos) {
    const piece = state.board[pos.row][pos.col];
    if (piece) {
      setSelected(samePos(selected ?? { row: -1, col: -1 }, pos) ? null : pos);
      setActiveType(piece.type);
      onPieceSeen(piece.type);
    } else {
      setSelected(null);
    }
  }

  const seenCount = progress.stage1Seen.length;

  return (
    <div>
      <div className="section-title">Stage 1 · Basics</div>
      <p className="section-sub">
        Tap any piece on the board to see every square it can legally move to. Tap a piece in the legend below to read
        about how it moves. You've explored {seenCount} of 6 piece types.
      </p>

      <div className="piece-legend mt-16">
        {(['p', 'n', 'b', 'r', 'q', 'k'] as PieceType[]).map((type) => (
          <button
            key={type}
            className={`piece-legend__item ${activeType === type ? 'active' : ''}`}
            onClick={() => {
              setActiveType(type);
              onPieceSeen(type);
            }}
          >
            <span>{pieceGlyph({ type, color: 'w' })}</span>
            <span className="piece-legend__label">{PIECE_INFO[type].name}</span>
          </button>
        ))}
      </div>

      <div className="card mt-16">
        <div className="row" style={{ marginBottom: 6 }}>
          <span style={{ fontSize: 26 }}>{pieceGlyph({ type: activeType, color: 'w' })}</span>
          <strong style={{ fontFamily: 'var(--font-display)', fontSize: 17 }}>{PIECE_INFO[activeType].name}</strong>
        </div>
        <p className="text-dim" style={{ fontSize: 13.5, lineHeight: 1.55 }}>
          {PIECE_INFO[activeType].text}
        </p>
      </div>

      <div className="board-wrap mt-24">
        <div className="board">
          {Array.from({ length: 8 }).map((_, row) =>
            Array.from({ length: 8 }).map((__, col) => {
              const piece = state.board[row][col];
              const isLight = (row + col) % 2 === 0;
              const isSelected = !!selected && samePos(selected, { row, col });
              const isLegalTarget = legalTargets.some((t) => samePos(t, { row, col }));
              return (
                <div
                  key={`${row}-${col}`}
                  className={`square ${isLight ? 'light' : 'dark'} ${isSelected ? 'selected' : ''}`}
                  onClick={() => handleSquareClick({ row, col })}
                >
                  {isLegalTarget && <span className={`legal-dot ${piece ? 'capture' : ''}`} />}
                  {piece && (
                    <span className={`piece ${piece.color === 'w' ? 'white' : 'black'}`}>{pieceGlyph(piece)}</span>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
      <p className="text-dim text-center" style={{ fontSize: 12, marginTop: 10 }}>
        Green dots = legal quiet moves. Red-outlined squares = legal captures.
      </p>
    </div>
  );
}
