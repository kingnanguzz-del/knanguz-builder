import { useEffect, useState } from 'react';
import BottomNav, { type Tab } from './components/BottomNav';
import Stage1 from './stages/Stage1';
import Stage2 from './stages/Stage2';
import Stage3 from './stages/Stage3';
import Stage4 from './stages/Stage4';
import Stage5 from './stages/Stage5';
import type { PieceType, Progress, StageId } from './types';
import {
  addXp,
  levelFromXp,
  loadProgress,
  markOpeningDone,
  markPieceSeen,
  markPuzzleDone,
  saveProgress,
  unlockNextStage,
  xpIntoLevel
} from './utils/storage';

const STAGE_META: { id: StageId; title: string; desc: string }[] = [
  { id: 1, title: 'Basics', desc: 'Learn how each piece moves' },
  { id: 2, title: 'Tactics', desc: '10 puzzles: forks, pins, mates' },
  { id: 3, title: 'Openings', desc: 'Italian, Queen\'s Gambit, Sicilian' },
  { id: 4, title: 'Middlegame', desc: 'Play vs a random-move bot' },
  { id: 5, title: 'Pro', desc: 'Smarter bot + endgame drills' }
];

export default function App() {
  const [tab, setTab] = useState<Tab>('learn');
  const [openStage, setOpenStage] = useState<StageId | null>(null);
  const [progress, setProgress] = useState<Progress>(() => loadProgress());

  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  const level = levelFromXp(progress.xp);
  const xpBar = xpIntoLevel(progress.xp);

  function handleXp(amount: number) {
    setProgress((p) => addXp(p, amount));
  }

  function openIfUnlocked(id: StageId) {
    if (id <= progress.unlockedStage) setOpenStage(id);
  }

  function renderStageContent() {
    switch (openStage) {
      case 1:
        return (
          <Stage1
            progress={progress}
            onPieceSeen={(type: PieceType) => {
              setProgress((p) => {
                const withSeen = markPieceSeen(p, type);
                const allSeen = withSeen.stage1Seen.length >= 6;
                return allSeen ? unlockNextStage(addXp(withSeen, 5), 1) : addXp(withSeen, 5);
              });
            }}
          />
        );
      case 2:
        return (
          <Stage2
            progress={progress}
            onSolved={(id: number) => {
              setProgress((p) => {
                const withDone = markPuzzleDone(p, id);
                const withXp = addXp(withDone, 15);
                const allDone = withDone.completedPuzzles.length >= 10;
                return allDone ? unlockNextStage(withXp, 2) : withXp;
              });
            }}
          />
        );
      case 3:
        return (
          <Stage3
            progress={progress}
            onOpeningComplete={(id: string) => {
              setProgress((p) => {
                const withDone = markOpeningDone(p, id);
                const withXp = addXp(withDone, 20);
                const allDone = withDone.completedOpenings.length >= 3;
                return allDone ? unlockNextStage(withXp, 3) : withXp;
              });
            }}
          />
        );
      case 4:
        return <Stage4 onXp={handleXp} onWin={() => setProgress((p) => unlockNextStage(p, 4))} />;
      case 5:
        return <Stage5 onXp={handleXp} onWin={() => setProgress((p) => p)} />;
      default:
        return null;
    }
  }

  return (
    <div className="app">
      <header className="app__header">
        <div className="app__brand">
          <span className="app__brand-mark">♞</span> Knan Chess Learner
        </div>
        <div className="xp-badge">
          <div className="xp-badge__level">{level}</div>
          <div className="xp-badge__bar">
            <div className="xp-badge__bar-fill" style={{ width: `${xpBar.current}%` }} />
          </div>
        </div>
      </header>

      <main className="app__main">
        {openStage ? (
          <div>
            <button className="btn btn--ghost btn--sm" style={{ marginBottom: 14 }} onClick={() => setOpenStage(null)}>
              ← Back
            </button>
            {renderStageContent()}
          </div>
        ) : tab === 'learn' ? (
          <div>
            <div className="section-title">Learn</div>
            <p className="section-sub">Five stages, unlocked in order. Complete one to open the next.</p>
            <div className="stage-list">
              {STAGE_META.map((s) => {
                const locked = s.id > progress.unlockedStage;
                const complete =
                  (s.id === 1 && progress.stage1Seen.length >= 6) ||
                  (s.id === 2 && progress.completedPuzzles.length >= 10) ||
                  (s.id === 3 && progress.completedOpenings.length >= 3);
                return (
                  <button
                    key={s.id}
                    className={`stage-plaque ${locked ? 'locked' : ''} ${complete ? 'complete' : ''}`}
                    onClick={() => openIfUnlocked(s.id)}
                  >
                    <span className="stage-plaque__num">{s.id}</span>
                    <span className="stage-plaque__body">
                      <span className="stage-plaque__title">{s.title}</span>
                      <span className="stage-plaque__desc">{s.desc}</span>
                    </span>
                    <span className="stage-plaque__lock">{locked ? '🔒' : complete ? '✓' : '›'}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ) : tab === 'play' ? (
          <div>
            <div className="section-title">Play</div>
            <p className="section-sub">Jump straight into a game once these stages are unlocked.</p>
            <div className="stage-list">
              <button
                className={`stage-plaque ${progress.unlockedStage < 4 ? 'locked' : ''}`}
                onClick={() => openIfUnlocked(4)}
              >
                <span className="stage-plaque__num">4</span>
                <span className="stage-plaque__body">
                  <span className="stage-plaque__title">Middlegame</span>
                  <span className="stage-plaque__desc">10-minute game vs a random-move bot</span>
                </span>
                <span className="stage-plaque__lock">{progress.unlockedStage < 4 ? '🔒' : '›'}</span>
              </button>
              <button
                className={`stage-plaque ${progress.unlockedStage < 5 ? 'locked' : ''}`}
                onClick={() => openIfUnlocked(5)}
              >
                <span className="stage-plaque__num">5</span>
                <span className="stage-plaque__body">
                  <span className="stage-plaque__title">Pro</span>
                  <span className="stage-plaque__desc">5-minute game vs a sharper bot, plus endgame drills</span>
                </span>
                <span className="stage-plaque__lock">{progress.unlockedStage < 5 ? '🔒' : '›'}</span>
              </button>
            </div>
            {progress.unlockedStage < 4 && (
              <p className="text-dim text-center mt-24" style={{ fontSize: 13 }}>
                Finish Stage 3 · Openings in the Learn tab to unlock Play.
              </p>
            )}
          </div>
        ) : (
          <div>
            <div className="section-title">Profile</div>
            <p className="section-sub">Your progress is saved on this device.</p>
            <div className="row" style={{ gap: 10, marginBottom: 16 }}>
              <div className="profile-stat">
                <span className="profile-stat__value">{level}</span>
                <span className="profile-stat__label">LEVEL</span>
              </div>
              <div className="profile-stat">
                <span className="profile-stat__value">{progress.xp}</span>
                <span className="profile-stat__label">TOTAL XP</span>
              </div>
              <div className="profile-stat">
                <span className="profile-stat__value">{progress.unlockedStage}</span>
                <span className="profile-stat__label">STAGE</span>
              </div>
            </div>
            <div className="card stack">
              <div className="row row--between">
                <span className="text-dim" style={{ fontSize: 13 }}>Pieces learned</span>
                <strong>{progress.stage1Seen.length} / 6</strong>
              </div>
              <div className="row row--between">
                <span className="text-dim" style={{ fontSize: 13 }}>Puzzles solved</span>
                <strong>{progress.completedPuzzles.length} / 10</strong>
              </div>
              <div className="row row--between">
                <span className="text-dim" style={{ fontSize: 13 }}>Openings learned</span>
                <strong>{progress.completedOpenings.length} / 3</strong>
              </div>
            </div>
            <button
              className="btn btn--ghost btn--block mt-24"
              onClick={() => {
                if (confirm('Reset all progress? This cannot be undone.')) {
                  const fresh: Progress = {
                    unlockedStage: 1,
                    xp: 0,
                    completedPuzzles: [],
                    completedOpenings: [],
                    stage1Seen: []
                  };
                  setProgress(fresh);
                }
              }}
            >
              Reset progress
            </button>
          </div>
        )}
      </main>

      {!openStage && <BottomNav active={tab} onChange={setTab} />}
    </div>
  );
}
