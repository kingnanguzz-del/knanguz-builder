import { useMemo, useState } from 'react';
import type { Color, GameState, Move, Pos } from '../types';
import { getLegalMoves, isKingInCheck, pieceGlyph, posToAlgebraic, samePos } from '../utils/chessLogic';

interface BoardProps {
  state: GameState;
  /** Which side's pieces the user is allowed to pick up. 'none' makes the board read-only (e.g. while the bot thinks). */
  interactiveColor: Color | 'both' | 'none';
  onAttemptMove: (from: Pos, to: Pos) => void;
  lastMove?: Move | null;
  /** Extra squares to highlight, e.g. the move currently being demoed in Stage 3. */
  highlightSquares?: Pos[];
}

// NOTE on interaction model: the original brief mentions HTML5 drag-and-drop, but native
// HTML5 drag events do not fire reliably on Android/touch browsers. Tap-to-select then
// tap-to-move gives identical "pick up a piece, see legal moves, place it" teaching value
// while actually working on a phone, so that's what's implemented here.
export default function Board({ state, interactiveColor, onAttemptMove, lastMove, highlightSquares }: BoardProps) {
  const [selected, setSelected] = useState<Pos | null>(null);

  const legalTargets = useMemo(() => {
    if (!selected) return [];
    return getLegalMoves(state, selected);
  }, [selected, state]);

  const kingInCheckPos = useMemo(() => {
    if (!isKingInCheck(state.board, state.turn)) return null;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const sq = state.board[r][c];
        if (sq && sq.type === 'k' && sq.color === state.turn) return { row: r, col: c };
      }
    }
    return null;
  }, [state]);

  function canPickUp(pos: Pos): boolean {
    const piece = state.board[pos.row][pos.col];
    if (!piece) return false;
    if (interactiveColor === 'none') return false;
    if (interactiveColor === 'both') return piece.color === state.turn;
    return piece.color === state.turn && piece.color === interactiveColor;
  }

  function handleSquareClick(pos: Pos) {
    if (interactiveColor === 'none') return;

    if (selected && legalTargets.some((t) => samePos(t, pos))) {
      onAttemptMove(selected, pos);
      setSelected(null);
      return;
    }

    if (canPickUp(pos)) {
      setSelected(samePos(selected ?? { row: -1, col: -1 }, pos) ? null : pos);
    } else {
      setSelected(null);
    }
  }

  const squares = [];
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const piece = state.board[row][col];
      const isLight = (row + col) % 2 === 0;
      const isSelected = !!selected && samePos(selected, { row, col });
      const isLegalTarget = legalTargets.some((t) => samePos(t, { row, col }));
      const isLastMove =
        !!lastMove && (samePos(lastMove.from, { row, col }) || samePos(lastMove.to, { row, col }));
      const isCheckSquare = !!kingInCheckPos && samePos(kingInCheckPos, { row, col });
      const isHighlighted = !!highlightSquares?.some((h) => samePos(h, { row, col }));

      squares.push(
        <div
          key={`${row}-${col}`}
          className={[
            'square',
            isLight ? 'light' : 'dark',
            isSelected ? 'selected' : '',
            isLastMove && !isSelected ? 'last-move' : '',
            isCheckSquare ? 'in-check' : '',
            isHighlighted ? 'last-move' : ''
          ]
            .filter(Boolean)
            .join(' ')}
          onClick={() => handleSquareClick({ row, col })}
        >
          {col === 0 && <span className="square__coord">{8 - row}</span>}
          {row === 7 && <span className="square__coord">{posToAlgebraic({ row, col })[0]}</span>}
          {isLegalTarget && <span className={`legal-dot ${piece ? 'capture' : ''}`} />}
          {piece && (
            <span key={`${piece.color}${piece.type}`} className={`piece ${piece.color === 'w' ? 'white' : 'black'} arrived`}>
              {pieceGlyph(piece)}
            </span>
          )}
        </div>
      );
    }
  }

  return (
    <div className="board-wrap">
      <div className="board">{squares}</div>
    </div>
  );
}
