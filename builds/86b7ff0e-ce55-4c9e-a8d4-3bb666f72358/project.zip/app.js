/* Bena Chess Tutor — App shell, vanilla JS (no framework, zero dependencies) */
(function () {
  const { h, mount } = window.DOM;
  const LEVELS = window.BenaLevels.LEVELS;

  const root = document.getElementById('root');
  const topbar = h('div', { class: 'topbar' });
  const contentArea = h('div', {});
  root.appendChild(topbar);
  root.appendChild(contentArea);

  let screen = 'home';
  let activeLevel = null;
  let mode3d = false;
  let currentScreenHandle = null; // for setMode3d / destroy hooks

  function destroyCurrentScreen() {
    if (currentScreenHandle && currentScreenHandle.destroy) currentScreenHandle.destroy();
    currentScreenHandle = null;
  }

  function goHome() {
    destroyCurrentScreen();
    screen = 'home';
    activeLevel = null;
    renderAll();
  }

  function openLevel(level) {
    destroyCurrentScreen();
    activeLevel = level;
    screen = level.type === 'lesson' ? 'lesson' : 'play';
    renderAll();
  }

  function goLevels() {
    destroyCurrentScreen();
    screen = 'levels';
    renderAll();
  }

  function openOffline() {
    destroyCurrentScreen();
    screen = 'offline';
    renderAll();
  }

  function openOnline() {
    destroyCurrentScreen();
    screen = 'online';
    renderAll();
  }

  function setMode3d(v) {
    mode3d = v;
    if (currentScreenHandle && currentScreenHandle.setMode3d) currentScreenHandle.setMode3d(v);
    renderTopbar();
  }

  function renderTopbar() {
    mount(topbar,
      h('div', { class: 'brand', onClick: goHome }, [
        h('span', { class: 'brand-mark' }, ['\u2663']),
        h('span', { class: 'brand-name' }, [h('b', {}, ['Bena']), ' Chess Tutor']),
      ]),
      h('div', { class: 'topbar-actions' }, [
        h('div', { class: 'pill-toggle' }, [
          h('button', { class: !mode3d ? 'active' : '', onClick: () => setMode3d(false) }, ['2D']),
          h('button', { class: mode3d ? 'active' : '', onClick: () => setMode3d(true) }, ['3D']),
        ]),
        screen !== 'home' && h('button', { class: 'icon-btn', onClick: goHome }, ['Home']),
      ])
    );
  }

  function renderHome() {
    const hero = h('div', { class: 'hero' }, [
      h('div', { class: 'hero-eyebrow' }, ['Learn chess the right way']),
      h('h1', {}, ['Real teaching. Real games. ', h('em', {}, ['Zero trolling.'])]),
      h('p', {}, [
        'Six structured levels take you from "how does a knight move" to full games with professional-style coaching \u2014 plus 3D and 2D boards, and offline or online play with a friend.',
      ]),
    ]);

    const modeGrid = h('div', { class: 'mode-grid' }, [
      h('button', { class: 'mode-card', onClick: goLevels }, [
        h('span', { class: 'glyph' }, ['\u265A']),
        h('h3', {}, ['Learn \u2014 6 Levels']),
        h('p', {}, ['Guided lessons on piece movement, opening principles and tactics, then real games with live coaching against a built-in opponent.']),
      ]),
      h('button', { class: 'mode-card', onClick: openOffline }, [
        h('span', { class: 'glyph' }, ['\u265E']),
        h('h3', {}, ['Play Offline (pass & play)']),
        h('p', {}, ['Two players, one phone. The board fills the whole screen, auto-flips between turns, and works in vertical or horizontal orientation.']),
      ]),
      h('button', { class: 'mode-card', onClick: openOnline }, [
        h('span', { class: 'glyph' }, ['\u2663']),
        h('h3', {}, ['Play Online']),
        h('p', {}, ['Connect directly to a friend with a one-time room code \u2014 no account, no server, just a live synced game.']),
      ]),
    ]);

    mount(contentArea, hero, modeGrid);
    contentArea.className = 'main-area';
  }

  function renderLevels() {
    const cards = LEVELS.map((lvl) => {
      const stars = '\u2605'.repeat(lvl.difficulty) + '\u2606'.repeat(6 - lvl.difficulty);
      return h('div', { class: 'level-card' }, [
        h('span', { class: `level-tag ${lvl.type === 'play' ? 'play' : ''}` }, [lvl.type === 'play' ? 'Real game' : 'Lesson']),
        h('h3', {}, [lvl.title]),
        h('div', { class: 'sub' }, [lvl.subtitle]),
        h('div', { class: 'stars' }, [stars]),
        h('p', {}, [lvl.description]),
        h('button', { onClick: () => openLevel(lvl) }, [lvl.type === 'play' ? 'Play' : 'Start lessons']),
      ]);
    });

    mount(contentArea,
      h('h2', { class: 'section-title' }, ['Choose your level']),
      h('p', { class: 'section-sub' }, ['Levels 1-3 are guided lessons. Levels 4-6 are real games with live coaching.']),
      h('div', { class: 'level-grid' }, cards),
    );
    contentArea.className = 'main-area';
  }

  function renderAll() {
    renderTopbar();
    if (screen === 'home') { renderHome(); return; }
    if (screen === 'levels') { renderLevels(); return; }
    if (screen === 'lesson') { currentScreenHandle = window.renderLessonMode(contentArea, activeLevel, mode3d, goLevels); return; }
    if (screen === 'play') { currentScreenHandle = window.renderPlayMode(contentArea, activeLevel, mode3d, goLevels); return; }
    if (screen === 'offline') { currentScreenHandle = window.renderOfflineMode(contentArea, mode3d, goHome); return; }
    if (screen === 'online') { currentScreenHandle = window.renderOnlineMode(contentArea, mode3d, goHome); return; }
  }

  renderAll();
})();
