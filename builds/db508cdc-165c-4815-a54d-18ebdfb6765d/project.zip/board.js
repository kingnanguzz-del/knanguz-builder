/* Bena Chess Tutor — Board view (vanilla JS, no framework)
   Key idea for "real" (non-teleporting) movement: instead of re-creating a
   DOM element per square every render, we keep a persistent list of "visual
   pieces" (each with a stable DOM node) and only update each node's
   translate() position via CSS transition when a move is applied. Captured
   pieces fade out and are removed; the rest just glide to their new square.
*/
function createBoardView(opts) {
  const { h } = window.DOM;
  const CE = window.ChessEngine;
  let { mode3d, flipped, interactive, onUserMove, size } = opts;

  let selected = null;
  let legalTargets = [];
  let visualPieces = []; // [{id, square:[r,c], piece}]
  let idCounter = 0;
  let currentArrow = null;
  let currentLastMove = null;
  let currentState = null;

  const root = h('div', { class: `board-wrap ${size === 'small' ? 'small' : ''}` });
  const boardEl = h('div', { class: 'board' });
  const squareLayer = h('div', { class: 'square-layer', style: { position: 'absolute', inset: '0', display: 'grid', gridTemplateColumns: 'repeat(8,1fr)', gridTemplateRows: 'repeat(8,1fr)' } });
  const pieceLayer = h('div', { class: 'piece-layer' });
  const arrowLayer = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  arrowLayer.setAttribute('class', 'arrow-svg');
  arrowLayer.setAttribute('viewBox', '0 0 100 100');
  arrowLayer.setAttribute('preserveAspectRatio', 'none');
  const promoLayer = h('div', { style: { display: 'none' } });

  boardEl.style.position = 'relative';
  boardEl.appendChild(squareLayer);
  boardEl.appendChild(pieceLayer);
  boardEl.appendChild(arrowLayer);
  boardEl.appendChild(promoLayer);
  root.appendChild(boardEl);

  const squareEls = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const isLight = (r + c) % 2 === 0;
      const sq = h('div', { class: `square ${isLight ? 'light' : 'dark'}` });
      if (c === 0) sq.appendChild(h('span', { class: 'coord-label coord-rank' }, [String(8 - r)]));
      if (r === 7) sq.appendChild(h('span', { class: 'coord-label coord-file' }, ['abcdefgh'[c]]));
      sq.addEventListener('click', () => handleSquareClick(r, c));
      squareLayer.appendChild(sq);
      squareEls.push(sq);
    }
  }

  function squareEl(r, c) { return squareEls[r * 8 + c]; }

  function refreshSquareClasses() {
    const inCheckSquare = (() => {
      if (!currentState || !CE.isInCheck(currentState, currentState.turn)) return null;
      for (let r = 0; r < 8; r++)
        for (let c = 0; c < 8; c++)
          if (currentState.board[r][c] === currentState.turn + 'K') return [r, c];
      return null;
    })();
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const el = squareEl(r, c);
        const isLight = (r + c) % 2 === 0;
        const isSelected = selected && selected[0] === r && selected[1] === c;
        const isLastFrom = currentLastMove && currentLastMove.from[0] === r && currentLastMove.from[1] === c;
        const isLastTo = currentLastMove && currentLastMove.to[0] === r && currentLastMove.to[1] === c;
        const target = legalTargets.find((m) => m.to[0] === r && m.to[1] === c);
        const isCheckSq = inCheckSquare && inCheckSquare[0] === r && inCheckSquare[1] === c;
        el.className = [
          'square',
          isLight ? 'light' : 'dark',
          isSelected ? 'selected' : '',
          (isLastFrom || isLastTo) ? 'last-move' : '',
          target ? (target.capture ? 'legal-capture' : 'legal-target') : '',
          isCheckSq ? 'in-check' : '',
        ].join(' ').trim();
      }
    }
  }

  function squareTransform(r, c) {
    const pct = 100 / 8;
    return `translate(${c * pct}%, ${r * pct}%) ${flipped ? 'rotate(180deg)' : ''}`;
  }

  function makeVisualPieceEl(vp) {
    const el = h('div', { class: `piece ${CE.color(vp.piece) === 'w' ? 'white' : 'black'}` });
    el.style.left = '0'; el.style.top = '0';
    el.style.transform = squareTransform(vp.square[0], vp.square[1]);
    el.appendChild(window.BenaPieces.buildPieceSvg(vp.piece));
    el.addEventListener('click', () => handleSquareClick(vp.square[0], vp.square[1]));
    return { el, vp };
  }

  const nodeMap = new Map(); // id -> {el, vp}

  function rebuildVisualPiecesFromBoard(board) {
    visualPieces = [];
    idCounter = 0;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const p = board[r][c];
        if (p) visualPieces.push({ id: 'p' + (idCounter++), square: [r, c], piece: p });
      }
    }
    window.DOM.clear(pieceLayer);
    nodeMap.clear();
    visualPieces.forEach((vp) => {
      const rec = makeVisualPieceEl(vp);
      nodeMap.set(vp.id, rec);
      pieceLayer.appendChild(rec.el);
    });
  }

  function findVisualPieceAt(sq) {
    return visualPieces.find((vp) => vp.square[0] === sq[0] && vp.square[1] === sq[1]);
  }

  function removeVisualPiece(vp) {
    const rec = nodeMap.get(vp.id);
    if (rec) {
      rec.el.style.opacity = '0';
      rec.el.style.transform += ' scale(0.4)';
      setTimeout(() => rec.el.remove(), 260);
      nodeMap.delete(vp.id);
    }
    visualPieces = visualPieces.filter((x) => x.id !== vp.id);
  }

  function applyMoveToVisuals(move) {
    const mover = findVisualPieceAt(move.from);
    if (!mover) return; // safety
    const col = CE.color(move.piece);

    if (move.enPassant) {
      const capRow = col === 'w' ? move.to[0] + 1 : move.to[0] - 1;
      const captured = findVisualPieceAt([capRow, move.to[1]]);
      if (captured) removeVisualPiece(captured);
    } else if (move.capture) {
      const captured = findVisualPieceAt(move.to);
      if (captured) removeVisualPiece(captured);
    }

    mover.square = move.to;
    if (move.promotion) mover.piece = col + move.promotion;
    const rec = nodeMap.get(mover.id);
    if (rec) {
      rec.el.className = `piece ${col === 'w' ? 'white' : 'black'}`;
      rec.el.style.transform = squareTransform(mover.square[0], mover.square[1]);
      window.DOM.clear(rec.el);
      rec.el.appendChild(window.BenaPieces.buildPieceSvg(mover.piece));
    }

    if (move.castle) {
      const homeRow = col === 'w' ? 7 : 0;
      const rookFrom = move.castle === 'K' ? [homeRow, 7] : [homeRow, 0];
      const rookTo = move.castle === 'K' ? [homeRow, 5] : [homeRow, 3];
      const rook = findVisualPieceAt(rookFrom);
      if (rook) {
        rook.square = rookTo;
        const rrec = nodeMap.get(rook.id);
        if (rrec) rrec.el.style.transform = squareTransform(rookTo[0], rookTo[1]);
      }
    }
  }

  function handleSquareClick(r, c) {
    if (!interactive || !currentState) return;
    const piece = currentState.board[r][c];
    if (selected) {
      const match = legalTargets.find((m) => m.to[0] === r && m.to[1] === c);
      if (match) {
        if (match.promotion) {
          const options = CE.legalMovesForSquare(currentState, selected[0], selected[1])
            .filter((m) => m.to[0] === r && m.to[1] === c && m.promotion);
          showPromotionModal(currentState.turn, options);
          return;
        }
        emitMove(match);
        return;
      }
    }
    if (piece && CE.color(piece) === currentState.turn) {
      selected = [r, c];
      legalTargets = CE.legalMovesForSquare(currentState, r, c);
    } else {
      selected = null;
      legalTargets = [];
    }
    refreshSquareClasses();
  }

  function showPromotionModal(color, options) {
    window.DOM.clear(promoLayer);
    promoLayer.className = 'promo-modal';
    promoLayer.style.display = 'flex';
    const card = h('div', { class: 'promo-card' });
    ['Q', 'R', 'B', 'N'].forEach((p) => {
      const mv = options.find((o) => o.promotion === p);
      const btn = h('button', {
        onClick: () => { promoLayer.style.display = 'none'; emitMove(mv); },
      });
      btn.appendChild(window.BenaPieces.buildPieceSvg(color + p));
      card.appendChild(btn);
    });
    promoLayer.appendChild(card);
  }

  function emitMove(move) {
    selected = null;
    legalTargets = [];
    if (onUserMove) onUserMove(move);
  }

  function drawArrow(arrow) {
    while (arrowLayer.firstChild) arrowLayer.removeChild(arrowLayer.firstChild);
    if (!arrow) return;
    const pct = 100 / 8;
    const cellCenter = (r, c) => [c * pct + pct / 2, r * pct + pct / 2];
    const [x1, y1] = cellCenter(arrow.from[0], arrow.from[1]);
    const [x2, y2] = cellCenter(arrow.to[0], arrow.to[1]);
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const shorten = 3.2;
    const ex = x2 - Math.cos(angle) * shorten;
    const ey = y2 - Math.sin(angle) * shorten;
    const headLen = 3.4, headWidth = 0.5;
    const hx1 = ex - headLen * Math.cos(angle - headWidth);
    const hy1 = ey - headLen * Math.sin(angle - headWidth);
    const hx2 = ex - headLen * Math.cos(angle + headWidth);
    const hy2 = ey - headLen * Math.sin(angle + headWidth);
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', x1); line.setAttribute('y1', y1);
    line.setAttribute('x2', ex); line.setAttribute('y2', ey);
    line.setAttribute('class', 'arrow-path');
    line.setAttribute('vector-effect', 'non-scaling-stroke');
    const head = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
    head.setAttribute('points', `${ex},${ey} ${hx1},${hy1} ${hx2},${hy2}`);
    head.setAttribute('class', 'arrow-head');
    arrowLayer.appendChild(line);
    arrowLayer.appendChild(head);
  }

  function applyModeClasses() {
    boardEl.className = `board ${mode3d ? 'mode-3d' : ''} ${flipped ? 'flipped' : ''}`.trim();
  }
  applyModeClasses();

  // Public API -----------------------------------------------------------
  function setState(newState, options) {
    options = options || {};
    const isNewGame = !currentState || newState.history.length === 0 || newState.history.length < currentState.history.length;
    currentState = newState;
    if ('mode3d' in options) mode3d = options.mode3d;
    if ('flipped' in options) flipped = options.flipped;
    if ('interactive' in options) interactive = options.interactive;
    currentLastMove = 'lastMove' in options ? options.lastMove : currentLastMove;
    currentArrow = 'arrow' in options ? options.arrow : currentArrow;

    if (isNewGame || visualPieces.length === 0) {
      rebuildVisualPiecesFromBoard(newState.board);
    } else if (options.appliedMove) {
      applyMoveToVisuals(options.appliedMove);
    } else {
      // Fallback: state changed without a specific move (e.g. external sync) — rebuild.
      rebuildVisualPiecesFromBoard(newState.board);
    }

    // re-apply flipped transform to all pieces if orientation changed
    visualPieces.forEach((vp) => {
      const rec = nodeMap.get(vp.id);
      if (rec) rec.el.style.transform = squareTransform(vp.square[0], vp.square[1]);
    });

    selected = null;
    legalTargets = [];
    applyModeClasses();
    refreshSquareClasses();
    drawArrow(currentArrow);
  }

  return { el: root, setState };
}

window.createBoardView = createBoardView;
