/* Bena Chess Tutor — Online mode, vanilla JS
   Peer-to-peer via WebRTC data channel. No signaling server: connection is
   established by copy-pasting two short "codes" (compressed session
   descriptions). Requires internet for the initial connection (STUN) only.
*/
function encodeSD(desc) {
  return btoa(unescape(encodeURIComponent(JSON.stringify(desc))));
}
function decodeSD(code) {
  return JSON.parse(decodeURIComponent(escape(atob(code.trim()))));
}
function waitForIce(pc) {
  return new Promise((resolve) => {
    if (pc.iceGatheringState === 'complete') return resolve();
    const timeout = setTimeout(() => resolve(), 3500);
    pc.addEventListener('icegatheringstatechange', function handler() {
      if (pc.iceGatheringState === 'complete') {
        clearTimeout(timeout);
        pc.removeEventListener('icegatheringstatechange', handler);
        resolve();
      }
    });
  });
}

function renderOnlineMode(container, mode3d, onExit) {
  const CE = window.ChessEngine;
  const { h, mount } = window.DOM;

  let tab = 'host';
  let hostCode = '';
  let joinInput = '';
  let joinCode = '';
  let answerInput = '';
  let connState = 'idle'; // idle, waiting-answer, connecting, connected, error
  let myColor = null;
  let state = CE.initialState();
  let lastMove = null;
  let flipped = false;

  let pc = null;
  let dc = null;
  let boardView = null;

  function setupDataChannel(channel) {
    dc = channel;
    dc.onopen = () => { connState = 'connected'; render(); };
    dc.onclose = () => { connState = 'idle'; render(); };
    dc.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === 'move') {
          const legal = CE.legalMoves(state, state.turn);
          const found = legal.find(
            (m) => m.from[0] === msg.move.from[0] && m.from[1] === msg.move.from[1] &&
                   m.to[0] === msg.move.to[0] && m.to[1] === msg.move.to[1] &&
                   (m.promotion || null) === (msg.move.promotion || null)
          );
          if (found) {
            state = CE.makeMove(state, found);
            lastMove = found;
            render();
          }
        } else if (msg.type === 'reset') {
          state = CE.initialState();
          lastMove = null;
          render();
        }
      } catch (e) { /* ignore malformed */ }
    };
  }

  async function createRoom() {
    connState = 'connecting'; render();
    pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    const channel = pc.createDataChannel('chess');
    setupDataChannel(channel);
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await waitForIce(pc);
    hostCode = encodeSD(pc.localDescription);
    myColor = 'w';
    connState = 'waiting-answer';
    render();
  }

  async function completeRoom() {
    try {
      const answer = decodeSD(answerInput);
      await pc.setRemoteDescription(answer);
      connState = 'connecting';
      render();
    } catch (e) {
      connState = 'error'; render();
    }
  }

  async function joinRoom() {
    try {
      connState = 'connecting'; render();
      const offer = decodeSD(joinInput);
      pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
      pc.ondatachannel = (ev) => setupDataChannel(ev.channel);
      await pc.setRemoteDescription(offer);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await waitForIce(pc);
      joinCode = encodeSD(pc.localDescription);
      myColor = 'b';
      flipped = true;
      render();
    } catch (e) {
      connState = 'error'; render();
    }
  }

  function sendMove(move) {
    if (dc && dc.readyState === 'open') {
      dc.send(JSON.stringify({ type: 'move', move: { from: move.from, to: move.to, promotion: move.promotion || null } }));
    }
  }

  function handleUserMove(move) {
    if (myColor !== state.turn) return;
    state = CE.makeMove(state, move);
    lastMove = move;
    sendMove(move);
    render();
  }

  function resetGame() {
    state = CE.initialState();
    lastMove = null;
    if (dc && dc.readyState === 'open') dc.send(JSON.stringify({ type: 'reset' }));
    render();
  }

  function copyToClipboard(text) {
    if (navigator.clipboard) navigator.clipboard.writeText(text);
  }

  function setTab(t) { tab = t; render(); }

  function renderConnected() {
    const status = CE.gameStatus(state);
    let statusText = myColor
      ? (state.turn === myColor ? 'Your move' : "Opponent's move")
      : 'Not connected yet';
    if (status.status === 'checkmate') statusText = `Checkmate \u2014 ${status.winner === 'w' ? 'White' : 'Black'} wins!`;
    else if (status.status === 'stalemate') statusText = 'Stalemate \u2014 draw';

    if (!boardView) {
      boardView = window.createBoardView({ mode3d, flipped, interactive: true, size: 'normal', onUserMove: handleUserMove });
    }
    boardView.setState(state, {
      mode3d, flipped,
      interactive: myColor === state.turn && (status.status === 'active' || status.status === 'check'),
      lastMove, arrow: null, appliedMove: lastMove,
    });

    const boardColumn = h('div', { class: 'board-column' }, [
      boardView.el,
      h('div', { class: 'btn-row' }, [h('button', { class: 'btn secondary', onClick: resetGame }, ['New game'])]),
    ]);

    const sidePanel = h('div', { class: 'side-panel' }, [
      h('h4', {}, ['Connection']),
      h('p', {}, ['Live peer-to-peer game \u2014 moves sync instantly, no server involved.']),
    ]);

    mount(container,
      h('button', { class: 'back-link', onClick: onExit }, ['\u2190 Back']),
      h('h2', { class: 'section-title' }, ['Playing Online']),
      h('p', { class: 'section-sub' }, [`You are ${myColor === 'w' ? 'White' : 'Black'} \u00b7 ${statusText}`]),
      h('div', { class: 'play-layout' }, [boardColumn, sidePanel]),
    );
    container.className = 'main-area';
  }

  function renderSetup() {
    const tabs = h('div', { class: 'tabs' }, [
      h('button', { class: tab === 'host' ? 'active' : '', onClick: () => setTab('host') }, ['Create room']),
      h('button', { class: tab === 'join' ? 'active' : '', onClick: () => setTab('join') }, ['Join room']),
    ]);

    let panelChildren = [];
    if (tab === 'host') {
      panelChildren.push(h('p', { class: 'status-line' }, ['1. Create a room, then send the host code to your friend.']));
      panelChildren.push(h('button', { class: 'btn', onClick: createRoom, disabled: connState !== 'idle' }, ['Create room']));
      if (hostCode) {
        const ta = h('textarea', { class: 'code-area', readonly: true, onClick: (e) => e.target.select() }, [hostCode]);
        panelChildren.push(ta);
        panelChildren.push(h('button', { class: 'btn secondary', onClick: () => copyToClipboard(hostCode) }, ['Copy host code']));
        panelChildren.push(h('p', { class: 'status-line' }, ['2. Paste the join code your friend sends back:']));
        const answerArea = h('textarea', {
          class: 'code-area', placeholder: 'Paste join code here',
          onInput: (e) => { answerInput = e.target.value; },
        }, []);
        answerArea.value = answerInput;
        panelChildren.push(answerArea);
        panelChildren.push(h('button', { class: 'btn', onClick: completeRoom }, ['Connect']));
      }
    } else {
      panelChildren.push(h('p', { class: 'status-line' }, ['1. Paste the host code your friend sent you:']));
      const joinArea = h('textarea', {
        class: 'code-area', placeholder: 'Paste host code here',
        onInput: (e) => { joinInput = e.target.value; },
      }, []);
      joinArea.value = joinInput;
      panelChildren.push(joinArea);
      panelChildren.push(h('button', { class: 'btn', onClick: joinRoom }, ['Join room']));
      if (joinCode) {
        panelChildren.push(h('p', { class: 'status-line' }, ['2. Send this join code back to your friend:']));
        panelChildren.push(h('textarea', { class: 'code-area', readonly: true, onClick: (e) => e.target.select() }, [joinCode]));
        panelChildren.push(h('button', { class: 'btn secondary', onClick: () => copyToClipboard(joinCode) }, ['Copy join code']));
        panelChildren.push(h('p', { class: 'status-line' }, ['Waiting for them to connect\u2026']));
      }
    }
    if (connState === 'error') {
      panelChildren.push(h('p', { class: 'status-line', style: { color: '#c15a4a' } }, ["That code didn't work \u2014 double check it was copied in full."]));
    }

    mount(container,
      h('button', { class: 'back-link', onClick: onExit }, ['\u2190 Back']),
      h('h2', { class: 'section-title' }, ['Play Online']),
      h('p', { class: 'section-sub' }, ['Connect directly with a friend using a one-time code. No accounts, no server.']),
      h('div', { class: 'online-box' }, [tabs, ...panelChildren]),
    );
    container.className = 'main-area';
  }

  function render() {
    if (connState === 'connected') renderConnected();
    else renderSetup();
  }

  render();
  return {
    setMode3d: (v) => { mode3d = v; render(); },
    destroy: () => { if (pc) pc.close(); },
  };
}

window.renderOnlineMode = renderOnlineMode;
