/* Bena Chess Tutor — Lesson mode (Levels 1-3), vanilla JS */
function squareToRC(sq) {
  const file = 'abcdefgh'.indexOf(sq[0]);
  const rank = parseInt(sq[1], 10);
  return [8 - rank, file];
}

function buildLessonState(lesson) {
  const CE = window.ChessEngine;
  const board = lesson.board || CE.createInitialBoard();
  return {
    board,
    turn: lesson.turn || 'w',
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassant: null,
    halfmove: 0,
    fullmove: 1,
    history: [],
  };
}

function renderLessonMode(container, level, mode3d, onExit) {
  const { h, mount } = window.DOM;
  const CE = window.ChessEngine;
  let idx = 0;
  let lesson = level.lessons[idx];
  let state = buildLessonState(lesson);
  let feedback = null;
  let showHint = true;
  let lastMove = null;
  let solved = false;

  const boardView = window.createBoardView({
    mode3d, flipped: false, interactive: true, size: 'normal',
    onUserMove: handleMove,
  });

  function handleMove(move) {
    const targetFrom = squareToRC(lesson.from);
    const targetTo = squareToRC(lesson.to);
    const isCorrect = move.from[0] === targetFrom[0] && move.from[1] === targetFrom[1] &&
                       move.to[0] === targetTo[0] && move.to[1] === targetTo[1];
    const next = CE.makeMove(state, move);
    state = next;
    lastMove = move;
    if (isCorrect) {
      solved = true;
      feedback = { correct: true, text: lesson.explanation };
    } else {
      feedback = { correct: false, text: "That's a legal move, but not the idea this lesson is teaching. Try Reset and look at the arrow for the recommended square." };
    }
    render();
  }

  function undo() {
    state = buildLessonState(lesson);
    feedback = null;
    lastMove = null;
    solved = false;
    render();
  }

  function goNext() {
    if (idx < level.lessons.length - 1) idx += 1;
    else { onExit(); return; }
    lesson = level.lessons[idx];
    state = buildLessonState(lesson);
    feedback = null;
    lastMove = null;
    solved = false;
    showHint = true;
    render();
  }

  function toggleHint() {
    showHint = !showHint;
    render();
  }

  function render() {
    const arrow = showHint && !solved ? { from: squareToRC(lesson.from), to: squareToRC(lesson.to) } : null;
    boardView.setState(state, {
      mode3d, flipped: false, interactive: !solved,
      lastMove, arrow, appliedMove: lastMove,
    });

    const progressDots = level.lessons.map((l, i) =>
      h('div', { class: `dot ${i < idx ? 'done' : ''} ${i === idx ? 'current' : ''}` })
    );

    const sidePanel = h('div', { class: 'side-panel' }, [
      h('h4', {}, ['Your task']),
      h('p', {}, [lesson.instruction]),
      feedback && h('div', { class: `coach-box tone-${feedback.correct ? 'good' : 'warn'}` }, [
        h('span', { class: 'coach-title' }, [feedback.correct ? 'Well played' : 'Not quite']),
        feedback.text,
      ]),
    ]);

    const btnRow = h('div', { class: 'btn-row' }, [
      h('button', { class: 'btn secondary', onClick: undo }, ['Reset position']),
      h('button', { class: 'btn secondary', onClick: toggleHint }, [showHint ? 'Hide arrow' : 'Show arrow']),
      solved && h('button', { class: 'btn', onClick: goNext }, [idx < level.lessons.length - 1 ? 'Next lesson' : 'Finish level']),
    ]);

    const boardColumn = h('div', { class: 'board-column' }, [boardView.el, btnRow]);

    mount(container,
      h('button', { class: 'back-link', onClick: onExit }, ['\u2190 Levels']),
      h('h2', { class: 'section-title' }, [level.title]),
      h('p', { class: 'section-sub' }, [level.subtitle]),
      h('div', { class: 'lesson-progress' }, progressDots),
      h('div', { class: 'play-layout' }, [boardColumn, sidePanel]),
    );
    container.className = 'main-area';
  }

  render();
  return { setMode3d: (v) => { mode3d = v; render(); } };
}

window.renderLessonMode = renderLessonMode;
