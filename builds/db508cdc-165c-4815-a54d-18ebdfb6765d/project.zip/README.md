# Bena Chess Tutor (fully offline build)

A complete chess learning app — 6 levels, 2D/3D board, animated moves, arrow
coaching, offline pass-and-play, and online play — built with **zero external
dependencies**: no React, no CDN, no build step. Just plain HTML/CSS/JS.

## Why this version is different

The previous build loaded React/Babel from a CDN, which needs internet on
first load. This build is 100% self-contained, so it works fully offline
(the only feature that still needs internet is **Play Online**, since two
phones obviously need a network to talk to each other).

## Packaging for an APK (Capacitor, Cordova, etc.)

**Copy every file in this folder directly into your `www` folder — flat, with
no subfolder in between** — so you end up with:
```
www/index.html
www/styles.css
www/dom.js
www/chessEngine.js
www/levels.js
www/board.js
www/lesson.js
www/play.js
www/offline.js
www/online.js
www/app.js
```
This zip's files sit at the top level of the archive for exactly that reason
— extract it straight into `www` and `index.html` will already be at the
right depth.

## Running it directly (no app wrapper)

Just open `index.html` in a browser. If your browser blocks local scripts
from loading each other, run a tiny local server from inside the folder
instead:
```
python3 -m http.server 8080
```
then visit `http://localhost:8080`.

## File structure & what each file does

| File | Purpose |
|---|---|
| `index.html` | Entry point, loads all scripts in order |
| `styles.css` | All visual design — wood/brass theme, 2D/3D board, big sculpted pieces |
| `dom.js` | ~20-line DOM helper (`h()`, `mount()`, `clear()`) — the only "framework" |
| `chessEngine.js` | Full chess rules from scratch: legal moves, check/checkmate/stalemate, castling, en passant, promotion, a minimax AI, and move-quality coaching |
| `levels.js` | The 6 levels and lesson content (piece basics → openings → tactics) |
| `board.js` | The chessboard itself: squares, big 3D-styled pieces, click-to-move, arrows, promotion picker. Piece elements are kept alive across moves (not recreated) so they visibly slide instead of teleporting |
| `lesson.js` | Levels 1-3: guided lessons with arrow hints and correction feedback |
| `play.js` | Levels 4-6: real games vs. the built-in engine with live move coaching |
| `offline.js` | Local two-player pass-and-play, fullscreen board, orientation toggle, auto-flip |
| `online.js` | Peer-to-peer play over WebRTC using a manually exchanged room code |
| `app.js` | Home screen, level select, and screen routing |

## About the pieces & 3D mode

Pieces are deliberately large (each glyph fills almost its entire square) and
in 3D mode get a layered "carved" look: a gradient fill, a multi-step
extrusion shadow, and a soft contact shadow underneath so they read as
sitting on the board rather than as flat icons. This is all done with CSS —
no external 3D model files are used, so nothing extra needs to be bundled or
downloaded.

## Honest notes on scope

- The opponent is a from-scratch minimax engine (depth 1-3 depending on
  level) — good for teaching, not tournament-strength like Stockfish.
- No accounts or persistence — each session starts fresh.
- Online play needs an internet connection for the two devices to connect
  to each other (and a public STUN server for NAT traversal); everything
  else in the app works with no network at all.
