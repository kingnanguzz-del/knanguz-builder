/* Bena Chess Tutor — Piece artwork (vanilla SVG, no fonts, no external assets)
   Unicode chess glyphs (U+2654-265F) don't render on many Android WebViews —
   there's often no installed font for that character block, so pieces show
   up blank. These are hand-drawn vector silhouettes instead, so every piece
   is guaranteed to render identically everywhere, with no font dependency.
   viewBox is 0 0 100 116 (a bit taller than wide, like a real chess piece).
*/
(function (global) {
  const NS = 'http://www.w3.org/2000/svg';

  function svgEl(tag, attrs) {
    const el = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach((k) => el.setAttribute(k, attrs[k]));
    return el;
  }

  // Each shape list is drawn in order (later shapes on top). Coordinates share one viewBox per piece.
  const SHAPES = {
    P: [ // Pawn: round head, bell body, base
      { tag: 'rect', attrs: { x: 30, y: 100, width: 40, height: 10, rx: 3 } },
      { tag: 'path', attrs: { d: 'M32 100 C28 88 34 78 42 74 C34 68 34 58 42 52 C36 48 36 40 44 38 C40 30 46 22 50 22 C54 22 60 30 56 38 C64 40 64 48 58 52 C66 58 66 68 58 74 C66 78 72 88 68 100 Z' } },
      { tag: 'circle', attrs: { cx: 50, cy: 20, r: 12 } },
    ],
    R: [ // Rook: crenellated top, straight body, base
      { tag: 'rect', attrs: { x: 30, y: 100, width: 40, height: 10, rx: 3 } },
      { tag: 'path', attrs: { d: 'M28 100 L30 62 L26 62 L26 18 L36 18 L36 24 L44 24 L44 18 L56 18 L56 24 L64 24 L64 18 L74 18 L74 62 L70 62 L72 100 Z' } },
    ],
    N: [ // Knight: horse head silhouette, base
      { tag: 'rect', attrs: { x: 26, y: 100, width: 48, height: 10, rx: 3 } },
      { tag: 'path', attrs: { d: 'M64 100 C66 86 64 78 58 74 C64 70 66 62 62 54 C68 50 70 42 64 34 C60 26 50 22 40 24 C42 20 40 16 34 16 C30 22 30 28 34 32 C24 36 18 46 20 56 C14 58 12 64 16 68 C20 64 24 64 26 68 C22 74 24 82 30 84 L28 100 Z' } },
    ],
    B: [ // Bishop: mitre with slit, ball finial, base
      { tag: 'rect', attrs: { x: 28, y: 100, width: 44, height: 10, rx: 3 } },
      { tag: 'path', attrs: { d: 'M30 100 C26 90 30 82 38 78 C30 74 28 66 34 60 C26 54 28 44 38 38 C32 32 38 24 50 24 C62 24 68 32 62 38 C72 44 74 54 66 60 C72 66 70 74 62 78 C70 82 74 90 70 100 Z' } },
      { tag: 'circle', attrs: { cx: 50, cy: 14, r: 6 } },
      { tag: 'line', attrs: { x1: 44, y1: 42, x2: 56, y2: 54, 'stroke-width': 3, stroke: 'rgba(0,0,0,0.35)' } },
    ],
    Q: [ // Queen: five-point crown, flared body, base
      { tag: 'rect', attrs: { x: 26, y: 100, width: 48, height: 10, rx: 3 } },
      { tag: 'path', attrs: { d: 'M30 100 C24 88 30 76 40 72 C32 66 30 54 38 46 L34 30 L42 38 L46 24 L50 36 L54 24 L58 38 L66 30 L62 46 C70 54 68 66 60 72 C70 76 76 88 70 100 Z' } },
      { tag: 'circle', attrs: { cx: 34, cy: 27, r: 4 } },
      { tag: 'circle', attrs: { cx: 46, cy: 21, r: 4 } },
      { tag: 'circle', attrs: { cx: 58, cy: 21, r: 4 } },
      { tag: 'circle', attrs: { cx: 66, cy: 27, r: 4 } },
    ],
    K: [ // King: cross finial, crown band, flared body, base
      { tag: 'rect', attrs: { x: 26, y: 100, width: 48, height: 10, rx: 3 } },
      { tag: 'path', attrs: { d: 'M30 100 C24 88 30 76 40 72 C32 66 30 54 40 46 L34 40 L66 40 L60 46 C70 54 68 66 60 72 C70 76 76 88 70 100 Z' } },
      { tag: 'rect', attrs: { x: 32, y: 36, width: 36, height: 8, rx: 2 } },
      { tag: 'rect', attrs: { x: 46, y: 12, width: 8, height: 20, rx: 2 } },
      { tag: 'rect', attrs: { x: 40, y: 18, width: 20, height: 8, rx: 2 } },
    ],
  };

  const BASE_ELLIPSE = { cx: 50, cy: 108, rx: 26, ry: 6 };

  function buildPieceGroup(type, extraAttrs) {
    const g = svgEl('g', extraAttrs || {});
    SHAPES[type].forEach((shape) => g.appendChild(svgEl(shape.tag, shape.attrs)));
    return g;
  }

  let defsInjected = false;
  function ensureDefs() {
    if (defsInjected || document.getElementById('bena-piece-defs')) { defsInjected = true; return; }
    const svg = svgEl('svg', { id: 'bena-piece-defs', style: 'position:absolute;width:0;height:0;overflow:hidden' });
    const defs = svgEl('defs', {});

    const whiteGrad = svgEl('linearGradient', { id: 'bena-grad-white', x1: '0', y1: '0', x2: '0', y2: '1' });
    [[0, '#fffdf7'], [45, '#f3ecd9'], [75, '#dcc79c'], [100, '#b6935c']].forEach(([off, color]) => {
      whiteGrad.appendChild(svgEl('stop', { offset: `${off}%`, 'stop-color': color }));
    });

    const blackGrad = svgEl('linearGradient', { id: 'bena-grad-black', x1: '0', y1: '0', x2: '0', y2: '1' });
    [[0, '#4e4038'], [40, '#2c2118'], [75, '#150e08'], [100, '#050302']].forEach(([off, color]) => {
      blackGrad.appendChild(svgEl('stop', { offset: `${off}%`, 'stop-color': color }));
    });

    const shadowGrad = svgEl('radialGradient', { id: 'bena-grad-shadow', cx: '50%', cy: '50%', r: '50%' });
    shadowGrad.appendChild(svgEl('stop', { offset: '0%', 'stop-color': 'rgba(0,0,0,0.55)' }));
    shadowGrad.appendChild(svgEl('stop', { offset: '100%', 'stop-color': 'rgba(0,0,0,0)' }));

    defs.appendChild(whiteGrad);
    defs.appendChild(blackGrad);
    defs.appendChild(shadowGrad);
    svg.appendChild(defs);
    document.body.appendChild(svg);
    defsInjected = true;
  }

  // Builds a full <svg> for one piece: contact shadow, extrusion "depth" layer
  // (shown only in 3D mode via CSS), and the main colored silhouette.
  function buildPieceSvg(pieceCode) {
    ensureDefs();
    const color = pieceCode[0]; // 'w' | 'b'
    const type = pieceCode[1];
    const isWhite = color === 'w';

    const svg = svgEl('svg', {
      viewBox: '0 0 100 116',
      class: 'piece-svg',
      preserveAspectRatio: 'xMidYMax meet',
    });

    const shadow = svgEl('ellipse', Object.assign({ class: 'contact-shadow', fill: 'url(#bena-grad-shadow)' }, BASE_ELLIPSE));
    svg.appendChild(shadow);

    // Depth layer: several stacked offset copies in a solid dark tone, only visible in 3D mode (see CSS)
    const depthGroup = svgEl('g', { class: 'depth-layer' });
    for (let i = 5; i >= 1; i--) {
      const copy = buildPieceGroup(type, {
        fill: isWhite ? '#8a6a3c' : '#000000',
        transform: `translate(0 ${i * 1.1})`,
        opacity: 0.9,
      });
      depthGroup.appendChild(copy);
    }
    svg.appendChild(depthGroup);

    const mainGroup = buildPieceGroup(type, {
      class: 'main-layer',
      fill: `url(#bena-grad-${isWhite ? 'white' : 'black'})`,
      stroke: isWhite ? '#4a3a22' : '#e8c983',
      'stroke-width': 2,
      'stroke-linejoin': 'round',
    });
    svg.appendChild(mainGroup);

    return svg;
  }

  global.BenaPieces = { buildPieceSvg };
})(window);
