/* Bena Chess Tutor — Play vs AI mode (Levels 4-6), vanilla JS */
function renderPlayMode(container, level, mode3d, onExit) {
  const CE = window.ChessEngine;
  const { h, mount } = window.DOM;
  const depth = level.aiDepth || 2;
  const humanColor = 'w';

  let state = CE.initialState();
  let lastMove = null;
  let coaching = null;
  let thinking = false;
  let hintArrow = null;
  let history = [];
  let aiTimer = null;

  const boardView = window.createBoardView({
    mode3d, flipped: false, interactive: true, size: 'normal',
    onUserMove: handleUserMove,
  });

  function describeMove(m, board) {
    const p = board[m.from[0]][m.from[1]];
    return `${CE.pieceName(p)} ${CE.squareName(m.from[0], m.from[1])}-${CE.squareName(m.to[0], m.to[1])}`;
  }

  function handleUserMove(move) {
    if (state.turn !== humanColor || thinking) return;
    hintArrow = null;
    const before = state;
    const explanation = level.coaching ? CE.explainMove(before, move, Math.max(depth, 1)) : null;
    const next = CE.makeMove(before, move);
    history = history.concat([describeMove(move, before.board)]);
    state = next;
    lastMove = move;
    if (explanation) coaching = explanation;
    thinking = true;
    render();
    scheduleAI();
  }

  function scheduleAI() {
    if (aiTimer) clearTimeout(aiTimer);
    if (state.turn === humanColor) return;
    const st = CE.gameStatus(state);
    if (st.status === 'checkmate' || st.status === 'stalemate' || st.status === 'draw') {
      thinking = false;
      render();
      return;
    }
    aiTimer = setTimeout(() => {
      const move = CE.findBestMove(state, depth);
      if (move) {
        history = history.concat([describeMove(move, state.board)]);
        lastMove = move;
        state = CE.makeMove(state, move);
      }
      thinking = false;
      render();
    }, 550 + Math.random() * 500);
  }

  function requestHint() {
    const move = CE.findBestMove(state, Math.max(depth, 1));
    if (move) hintArrow = { from: move.from, to: move.to };
    render();
  }

  function resetGame() {
    if (aiTimer) clearTimeout(aiTimer);
    state = CE.initialState();
    lastMove = null;
    coaching = null;
    hintArrow = null;
    history = [];
    thinking = false;
    render();
  }

  function render() {
    const status = CE.gameStatus(state);
    boardView.setState(state, {
      mode3d, flipped: false,
      interactive: state.turn === humanColor && !thinking && (status.status === 'active' || status.status === 'check'),
      lastMove, arrow: hintArrow, appliedMove: lastMove,
    });

    let statusText = state.turn === humanColor ? 'Your move' : (thinking ? 'Opponent is thinking\u2026' : "Opponent's move");
    if (status.status === 'checkmate') statusText = `Checkmate \u2014 ${status.winner === humanColor ? 'You win!' : 'The opponent wins.'}`;
    else if (status.status === 'stalemate') statusText = 'Stalemate \u2014 the game is a draw.';
    else if (status.status === 'check') statusText += ' \u00b7 Check!';

    const statusBar = h('div', { class: 'status-bar' }, [
      h('span', { class: `turn-dot ${state.turn}` }),
      h('span', {}, [statusText]),
    ]);

    const btnRow = h('div', { class: 'btn-row' }, [
      h('button', { class: 'btn secondary', onClick: requestHint, disabled: state.turn !== humanColor }, ['Show hint arrow']),
      h('button', { class: 'btn secondary', onClick: resetGame }, ['New game']),
    ]);

    const boardColumn = h('div', { class: 'board-column' }, [statusBar, boardView.el, btnRow]);

    const coachBox = coaching
      ? h('div', { class: `coach-box tone-${coaching.tone}` }, [
          h('span', { class: 'coach-title' }, [coaching.quality]),
          coaching.text,
        ])
      : h('p', {}, ["Play a move \u2014 you'll get instant, professional feedback here, not just a score."]);

    const moveList = h('div', { class: 'move-history' },
      history.length === 0
        ? [h('div', {}, ['No moves yet.'])]
        : history.map((mv, i) => h('div', {}, [`${i + 1}. ${mv}`]))
    );

    const sidePanel = h('div', { class: 'side-panel' }, [
      h('h4', {}, ['Coach']),
      coachBox,
      h('h4', { style: { marginTop: '18px' } }, ['Move list']),
      moveList,
    ]);

    mount(container,
      h('button', { class: 'back-link', onClick: onExit }, ['\u2190 Levels']),
      h('h2', { class: 'section-title' }, [level.title]),
      h('p', { class: 'section-sub' }, [level.subtitle]),
      h('div', { class: 'play-layout' }, [boardColumn, sidePanel]),
    );
    container.className = 'main-area';
  }

  render();
  return {
    setMode3d: (v) => { mode3d = v; render(); },
    destroy: () => { if (aiTimer) clearTimeout(aiTimer); },
  };
}

window.renderPlayMode = renderPlayMode;
