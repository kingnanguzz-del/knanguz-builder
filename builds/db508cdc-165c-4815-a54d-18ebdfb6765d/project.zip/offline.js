/* Bena Chess Tutor — Offline two-player (same device) mode, vanilla JS */
function renderOfflineMode(container, mode3d, onExit) {
  const CE = window.ChessEngine;
  const { h, mount } = window.DOM;

  let state = CE.initialState();
  let lastMove = null;
  let orientation = 'portrait';
  let autoFlip = true;
  let flipped = false;
  let status = { status: 'active' };

  const boardView = window.createBoardView({
    mode3d, flipped, interactive: true, size: 'normal',
    onUserMove: handleMove,
  });

  function handleMove(move) {
    const next = CE.makeMove(state, move);
    state = next;
    lastMove = move;
    status = CE.gameStatus(state);
    if (autoFlip) flipped = state.turn === 'b';
    render();
  }

  function resetGame() {
    state = CE.initialState();
    lastMove = null;
    status = { status: 'active' };
    flipped = false;
    render();
  }

  function toggleOrientation() {
    orientation = orientation === 'portrait' ? 'landscape' : 'portrait';
    render();
  }

  function toggleAutoFlip() {
    autoFlip = !autoFlip;
    render();
  }

  function render() {
    const whiteName = orientation === 'landscape' ? 'Player 1 (White)' : 'White';
    const blackName = orientation === 'landscape' ? 'Player 2 (Black)' : 'Black';

    let statusText = state.turn === 'w' ? 'White to move' : 'Black to move';
    if (status.status === 'checkmate') statusText = `Checkmate \u2014 ${status.winner === 'w' ? 'White' : 'Black'} wins!`;
    else if (status.status === 'stalemate') statusText = 'Stalemate \u2014 draw';
    else if (status.status === 'check') statusText = `${state.turn === 'w' ? 'White' : 'Black'} is in check`;

    boardView.setState(state, {
      mode3d, flipped,
      interactive: status.status === 'active' || status.status === 'check',
      lastMove, arrow: null, appliedMove: lastMove,
    });

    const topbar = h('div', { class: 'offline-topbar' }, [
      h('button', { class: 'icon-btn', onClick: onExit }, ['\u2190 Exit']),
      h('div', { class: 'btn-row' }, [
        h('button', { class: 'icon-btn', onClick: toggleOrientation }, [`${orientation === 'portrait' ? 'Vertical' : 'Horizontal'} view`]),
        h('button', { class: 'icon-btn', onClick: toggleAutoFlip }, [`Auto-flip: ${autoFlip ? 'On' : 'Off'}`]),
        h('button', { class: 'icon-btn', onClick: resetGame }, ['New game']),
      ]),
    ]);

    mount(container,
      topbar,
      h('div', { class: 'offline-label-top' }, [blackName]),
      boardView.el,
      h('div', { class: 'offline-label-bottom' }, [whiteName]),
      h('div', { class: 'status-line', style: { position: 'absolute', bottom: '14px' } }, [statusText]),
    );
    container.className = `offline-fullscreen orientation-${orientation}`;
  }

  render();
  return { setMode3d: (v) => { mode3d = v; render(); } };
}

window.renderOfflineMode = renderOfflineMode;
