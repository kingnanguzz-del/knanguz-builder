/* Bena Chess Tutor — tiny DOM helper (no framework, zero dependencies) */
(function (global) {
  function h(tag, attrs, children) {
    const el = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach((key) => {
      const val = attrs[key];
      if (key === 'class') el.className = val;
      else if (key === 'style' && typeof val === 'object') Object.assign(el.style, val);
      else if (key.startsWith('on') && typeof val === 'function') el.addEventListener(key.slice(2).toLowerCase(), val);
      else if (val === true) el.setAttribute(key, '');
      else if (val === false || val == null) { /* skip */ }
      else el.setAttribute(key, val);
    });
    (children || []).forEach((child) => {
      if (child == null || child === false) return;
      if (typeof child === 'string' || typeof child === 'number') el.appendChild(document.createTextNode(String(child)));
      else el.appendChild(child);
    });
    return el;
  }
  function clear(el) {
    while (el.firstChild) el.removeChild(el.firstChild);
  }
  function mount(container, ...nodes) {
    clear(container);
    nodes.forEach((n) => n && container.appendChild(n));
  }

  global.DOM = { h, clear, mount };
})(window);
