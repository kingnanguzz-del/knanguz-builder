/* Bena Chess Tutor — real 3D board (WebGL via the bundled three.min.js, fully offline).
   Pieces are turned on a "lathe" like real Staunton pieces; the knight is a carved head.
   One shared WebGL context is reused by every board (Android limits live contexts).
   If WebGL is unavailable, supported() is false and board.js falls back to the CSS tilt. */
(function (global) {
  'use strict';
  const T = global.THREE;
  let shared = null; // null = not tried, false = unsupported
  let active = null;

  const PIECE_SCALE = 1.08; // width scale
  const SY = { P: 1.12, R: 1.1, N: 1.1, B: 1.2, Q: 1.22, K: 1.25 }; // extra height => slender, elegant pieces

  // ---------- helpers ----------
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function smooth(pts, it) { // Chaikin corner cutting: rounds the turned edges, keeps end points
    for (let k = 0; k < it; k++) {
      const out = [pts[0]];
      for (let i = 0; i < pts.length - 1; i++) {
        const a = pts[i], b = pts[i + 1];
        out.push(new T.Vector2(a.x * 0.75 + b.x * 0.25, a.y * 0.75 + b.y * 0.25));
        out.push(new T.Vector2(a.x * 0.25 + b.x * 0.75, a.y * 0.25 + b.y * 0.75));
      }
      out.push(pts[pts.length - 1]);
      pts = out;
    }
    return pts;
  }
  function lathe(arr, it) {
    const p = smooth(arr.map((a) => new T.Vector2(a[0], a[1])), it == null ? 2 : it);
    return new T.LatheGeometry(p, 56);
  }
  function arc(cx, cy, rx, ry, a0, a1, n) {
    const out = [];
    for (let i = 0; i <= n; i++) {
      const a = (a0 + (a1 - a0) * (i / n)) * Math.PI / 180;
      out.push([cx + rx * Math.cos(a), cy + ry * Math.sin(a)]);
    }
    return out;
  }

  function woodTexture(base, dark, light, seed) {
    const S = 512, c = document.createElement('canvas');
    c.width = c.height = S;
    const g = c.getContext('2d');
    g.fillStyle = base; g.fillRect(0, 0, S, S);
    const rnd = mulberry32(seed);
    for (let i = 0; i < 170; i++) {
      const y = rnd() * S, amp = 2 + rnd() * 7, k = 1 + Math.floor(rnd() * 3), ph = rnd() * 6.283;
      g.strokeStyle = rnd() < 0.55 ? dark : light;
      g.globalAlpha = 0.05 + rnd() * 0.11;
      g.lineWidth = 0.6 + rnd() * 2.4;
      g.beginPath();
      for (let x = 0; x <= S; x += 8) {
        const yy = y + Math.sin((x / S) * 6.283 * k + ph) * amp;
        if (x) g.lineTo(x, yy); else g.moveTo(x, yy);
      }
      g.stroke();
    }
    g.globalAlpha = 1;
    const id = g.getImageData(0, 0, S, S), d = id.data;
    for (let i = 0; i < d.length; i += 4) {
      const n = (rnd() - 0.5) * 12;
      d[i] += n; d[i + 1] += n; d[i + 2] += n;
    }
    g.putImageData(id, 0, 0);
    const t = new T.CanvasTexture(c);
    t.wrapS = t.wrapT = T.RepeatWrapping;
    t.encoding = T.sRGBEncoding;
    t.anisotropy = 4;
    return t;
  }

  function labelTexture(txt, color) {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d');
    g.fillStyle = color || '#d9b873'; g.font = 'bold 44px Arial, Helvetica, sans-serif';
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(txt, 32, 34);
    const t = new T.CanvasTexture(c); t.encoding = T.sRGBEncoding; return t;
  }

  function makeEnv(renderer) { // soft-box studio so glossy pieces get real reflections
    try {
      const s = new T.Scene();
      s.add(new T.Mesh(new T.SphereGeometry(50, 24, 16), new T.MeshBasicMaterial({ color: 0x4d4034, side: T.BackSide })));
      const box = (w, h, x, y, z, v) => {
        const m = new T.Mesh(new T.PlaneGeometry(w, h),
          new T.MeshBasicMaterial({ color: new T.Color(v, v * 0.95, v * 0.86), side: T.DoubleSide }));
        m.position.set(x, y, z); m.lookAt(0, 0, 0); s.add(m);
      };
      box(30, 18, -25, 30, 25, 3.2); box(20, 10, 30, 12, -10, 1.4);
      box(40, 6, 0, 35, -20, 1.8); box(14, 24, 28, 10, 28, 1.2);
      const pm = new T.PMREMGenerator(renderer);
      const rt = pm.fromScene(s, 0.04); pm.dispose();
      return rt.texture;
    } catch (e) { return null; }
  }

  // ---------- shared assets ----------
  function makeAssets() {
    const A = {};
    A.texLight = woodTexture('#e8d6b4', '#c9b48a', '#f6e8cc', 11);
    A.texDark = woodTexture('#18191d', '#050506', '#3a3c43', 23);
    A.texFrame = woodTexture('#5d3a1d', '#33190a', '#7d522b', 37);
    A.matLight = new T.MeshStandardMaterial({ map: A.texLight, roughness: 0.6, metalness: 0, envMapIntensity: 0.15 });
    A.matDark = new T.MeshStandardMaterial({ map: A.texDark, roughness: 0.55, metalness: 0, envMapIntensity: 0.15 });
    A.matFrame = new T.MeshStandardMaterial({ map: A.texFrame, roughness: 0.45, metalness: 0, envMapIntensity: 0.6 });
    A.white = new T.MeshPhysicalMaterial({ color: 0xece8de, roughness: 0.6, metalness: 0, clearcoat: 0, specularIntensity: 0.25, envMapIntensity: 0.08 });
    A.black = new T.MeshPhysicalMaterial({ color: 0x000000, roughness: 0.6, metalness: 0, clearcoat: 0, specularIntensity: 0.3, envMapIntensity: 0.05 });
    A.accentW = new T.MeshStandardMaterial({ color: 0x3a3a3e, roughness: 0.45 });
    A.accentB = new T.MeshStandardMaterial({ color: 0xb9bcc4, roughness: 0.3, metalness: 0.6 });
    const flat = (color, op) => new T.MeshBasicMaterial({ color, transparent: true, opacity: op, depthWrite: false, toneMapped: false });
    A.hlLast = flat(0xf2c200, 0.42); A.hlOutline = flat(0xffd83a, 0.95); A.hlSel = flat(0xe8c983, 0.55);
    A.hlTarget = flat(0xd49a00, 0.9); A.hlCap = flat(0xe0503c, 0.85); A.hlCheck = flat(0xe03b3b, 0.55);
    A.arrow = flat(0xe8c983, 0.9);
    const rot = (g) => { g.rotateX(-Math.PI / 2); return g; };
    A.gPlane = rot(new T.PlaneGeometry(0.96, 0.96));
    (function () {
      const sh = new T.Shape(), h = 0.5, i = 0.44;
      sh.moveTo(-h, -h); sh.lineTo(h, -h); sh.lineTo(h, h); sh.lineTo(-h, h); sh.closePath();
      const hole = new T.Path(); hole.moveTo(-i, -i); hole.lineTo(-i, i); hole.lineTo(i, i); hole.lineTo(i, -i); hole.closePath();
      sh.holes.push(hole);
      A.gOutline = rot(new T.ShapeGeometry(sh));
    })();
    A.gDisc = rot(new T.CircleGeometry(0.19, 28));
    A.gRing = rot(new T.RingGeometry(0.36, 0.46, 40));
    A.parts = {};
    return A;
  }

  function getShared() {
    if (shared !== null) return shared;
    try {
      if (!T) throw new Error('three.js missing');
      const canvas = document.createElement('canvas');
      canvas.className = 'b3d-canvas';
      const renderer = new T.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
      renderer.setPixelRatio(Math.min(global.devicePixelRatio || 1, 2));
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = T.PCFSoftShadowMap;
      renderer.outputEncoding = T.sRGBEncoding;
      renderer.toneMapping = T.NoToneMapping; // true colours: white stays white, black stays black
      renderer.setClearColor(0x000000, 0);
      canvas.addEventListener('webglcontextlost', (e) => e.preventDefault());
      canvas.addEventListener('webglcontextrestored', () => { if (active) active.invalidate(); });
      shared = { renderer, canvas, env: makeEnv(renderer), A: makeAssets() };
    } catch (e) {
      console.warn('[3D] unavailable, using CSS fallback:', e && e.message);
      shared = false;
    }
    return shared;
  }

  // ---------- piece geometry ----------
  function basePts(rad, top) { // plinth shared by all pieces
    return [[0, 0], [rad - 0.03, 0], [rad, 0.025], [rad, 0.08], [rad - 0.07, 0.14], [rad - 0.14, 0.175], [top, 0.2]];
  }

  function knightShape() {
    const P = [[-0.20, 0.00], [-0.26, 0.12], [-0.27, 0.27], [-0.27, 0.41], [-0.26, 0.54],
      [-0.19, 0.60], [-0.14, 0.68], [-0.08, 0.85], [-0.03, 0.74], [0.04, 0.82], [0.09, 0.68], [0.19, 0.56], [0.31, 0.44],
      [0.38, 0.34], [0.37, 0.26], [0.28, 0.23], [0.17, 0.27], [0.09, 0.22], [0.15, 0.11], [0.22, 0.00]];
    const curve = new T.CatmullRomCurve3(P.map((p) => new T.Vector3(p[0], p[1], 0)), true, 'centripetal');
    return new T.Shape(curve.getPoints(220).map((v) => new T.Vector2(v.x, v.y)));
  }

  function partsFor(type, A) { // returns [{g, accent, pos, rot}]
    if (A.parts[type]) return A.parts[type];
    const out = [];
    const add = (g, o) => out.push(Object.assign({ g, accent: false, pos: [0, 0, 0], rot: [0, 0, 0] }, o || {}));
    const sph = (r, y, x, z, acc) => add(new T.SphereGeometry(r, 20, 14), { pos: [x || 0, y, z || 0], accent: !!acc });

    if (type === 'P') {
      add(lathe(basePts(0.41, 0.24).concat([[0.17, 0.25], [0.13, 0.40], [0.12, 0.52], [0.14, 0.545], [0.25, 0.565],
        [0.265, 0.595], [0.24, 0.62], [0.15, 0.645], [0.115, 0.655]], arc(0, 0.80, 0.195, 0.195, -40, 90, 10))));
    } else if (type === 'R') {
      add(lathe(basePts(0.43, 0.28).concat([[0.25, 0.26], [0.235, 0.34], [0.235, 0.60], [0.25, 0.64], [0.33, 0.68],
        [0.345, 0.72], [0.345, 0.84], [0.30, 0.84], [0.295, 0.77], [0, 0.77]])));
      for (let k = 0; k < 4; k++) { // hollow cup with four battlements
        const c = Math.PI / 4 + k * Math.PI / 2, half = 0.36;
        const s = new T.Shape();
        s.absarc(0, 0, 0.345, -half, half, false);
        s.absarc(0, 0, 0.292, half, -half, true);
        s.closePath();
        const g = new T.ExtrudeGeometry(s, { depth: 0.12, bevelEnabled: true, bevelThickness: 0.01, bevelSize: 0.01, bevelSegments: 2, curveSegments: 8 });
        g.rotateX(-Math.PI / 2); g.rotateY(c); g.translate(0, 0.84, 0);
        add(g);
      }
    } else if (type === 'B') {
      add(lathe(basePts(0.41, 0.22).concat([[0.16, 0.27], [0.125, 0.42], [0.12, 0.52], [0.14, 0.545], [0.24, 0.565],
        [0.255, 0.60], [0.23, 0.625], [0.15, 0.65], [0.125, 0.67]], arc(0, 0.97, 0.215, 0.33, -62, 90, 14))));
      sph(0.055, 1.345);
      const t = new T.TorusGeometry(0.2, 0.018, 10, 44); t.rotateX(Math.PI / 2);
      add(t, { pos: [0, 0.99, 0], rot: [0, 0, 0.62], accent: true });
    } else if (type === 'Q') {
      add(lathe(basePts(0.44, 0.24).concat([[0.17, 0.30], [0.135, 0.46], [0.125, 0.58], [0.15, 0.605], [0.27, 0.63],
        [0.285, 0.665], [0.25, 0.69], [0.16, 0.715], [0.14, 0.75], [0.17, 0.88], [0.25, 1.02], [0.31, 1.14],
        [0.335, 1.20], [0.34, 1.235], [0.30, 1.255], [0.22, 1.245], [0.10, 1.235], [0, 1.235]])));
      for (let k = 0; k < 8; k++) { // pointed crown
        const a = k * Math.PI / 4, cs = Math.cos(a), sn = Math.sin(a);
        add(new T.ConeGeometry(0.05, 0.2, 12), { pos: [cs * 0.28, 1.33, sn * 0.28], rot: [sn * 0.3, 0, -cs * 0.3] });
        sph(0.036, 1.445, cs * 0.315, sn * 0.315);
      }
      sph(0.085, 1.30);
    } else if (type === 'K') {
      add(lathe(basePts(0.44, 0.24).concat([[0.17, 0.30], [0.135, 0.46], [0.125, 0.58], [0.15, 0.605], [0.27, 0.63],
        [0.285, 0.665], [0.25, 0.69], [0.16, 0.715], [0.14, 0.75], [0.17, 0.90], [0.24, 1.04], [0.30, 1.14],
        [0.32, 1.19], [0.30, 1.235], [0.20, 1.265], [0.08, 1.275], [0, 1.275]])));
      add(new T.BoxGeometry(0.075, 0.30, 0.075), { pos: [0, 1.425, 0] });
      add(new T.BoxGeometry(0.22, 0.075, 0.075), { pos: [0, 1.47, 0] });
    } else if (type === 'N') {
      add(lathe([[0, 0], [0.38, 0], [0.43, 0.025], [0.43, 0.08], [0.37, 0.14], [0.30, 0.18], [0, 0.18]]));
      const g = new T.ExtrudeGeometry(knightShape(), { depth: 0.2, bevelEnabled: true, bevelThickness: 0.05, bevelSize: 0.04, bevelSegments: 4, curveSegments: 12 });
      g.translate(0, 0, -0.1); g.scale(1.15, 1.15, 1.15); g.translate(-0.06, 0.16, 0);
      add(g);
      sph(0.03, 0.735, 0.072, 0.165, true); sph(0.03, 0.735, 0.072, -0.165, true);
    }
    A.parts[type] = out;
    return out;
  }

  // ---------- board instance ----------
  function create(host, cbs) {
    const S = getShared();
    if (!S) throw new Error('3D unsupported');
    const { renderer, canvas, A } = S;
    const scene = new T.Scene();
    if (S.env) scene.environment = S.env;
    const camera = new T.PerspectiveCamera(32, 1, 0.5, 120);
    const target = new T.Vector3(0, 0.35, 0.15);
    const HOME = { yaw: 0, elev: 50 * Math.PI / 180, zoom: 1 };
    const view = { yaw: HOME.yaw, elev: HOME.elev, zoom: HOME.zoom };
    let goal = null, flipped = false;
    const MIN_EL = 0.28, MAX_EL = 1.53; // ~16° (low side view) … 88° (straight down)
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

    // lights
    scene.add(new T.HemisphereLight(0xffffff, 0x6e6a60, 0.55));
    const key = new T.DirectionalLight(0xffffff, 0.62);
    key.position.set(-6, 13, 8); key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, { left: -7, right: 7, top: 7, bottom: -7, near: 2, far: 40 });
    key.shadow.bias = -0.0005; key.shadow.normalBias = 0.025; key.shadow.radius = 3;
    scene.add(key);
    const fill = new T.DirectionalLight(0xffffff, 0.22); fill.position.set(9, 6, -7); scene.add(fill);

    // board
    const boardGroup = new T.Group(); scene.add(boardGroup);
    const rnd = mulberry32(5);
    const sqBase = new T.BoxGeometry(1, 0.2, 1);
    const sqMeshes = [];
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const g = sqBase.clone();
        const uv = g.attributes.uv, ox = rnd(), oy = rnd();
        for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * 0.5 + ox, uv.getY(i) * 0.5 + oy);
        const m = new T.Mesh(g, (r + c) % 2 === 0 ? A.matLight : A.matDark);
        m.position.set(c - 3.5, -0.1, r - 3.5);
        m.receiveShadow = true; m.userData.sq = [r, c];
        boardGroup.add(m); sqMeshes.push(m);
      }
    }
    const frameBox = (w, h, d, x, y, z) => {
      const m = new T.Mesh(new T.BoxGeometry(w, h, d), A.matFrame);
      m.position.set(x, y, z); m.receiveShadow = true; m.castShadow = true; boardGroup.add(m);
    };
    frameBox(8.7, 0.3, 0.35, 0, -0.05, -4.175); frameBox(8.7, 0.3, 0.35, 0, -0.05, 4.175);
    frameBox(0.35, 0.3, 8, -4.175, -0.05, 0); frameBox(0.35, 0.3, 8, 4.175, -0.05, 0);
    frameBox(8.9, 0.3, 8.9, 0, -0.35, 0);
    const ground = new T.Mesh(new T.PlaneGeometry(40, 40), new T.ShadowMaterial({ opacity: 0.38 }));
    ground.rotation.x = -Math.PI / 2; ground.position.y = -0.52; ground.receiveShadow = true; scene.add(ground);
    // small coordinates inside the squares (rank on the a-file, file letters on rank 1)
    const addLabel = (txt, r, c, dx, dz) => {
      const light = (r + c) % 2 === 0;
      const m = new T.Mesh(new T.PlaneGeometry(0.2, 0.2),
        new T.MeshBasicMaterial({ map: labelTexture(txt, light ? '#3a3226' : '#e9dcc0'), transparent: true, toneMapped: false }));
      m.rotation.x = -Math.PI / 2; m.position.set(c - 3.5 + dx, 0.006, r - 3.5 + dz); boardGroup.add(m);
    };
    for (let r = 0; r < 8; r++) addLabel(String(8 - r), r, 0, -0.36, -0.36);
    for (let c = 0; c < 8; c++) addLabel('abcdefgh'[c], 7, c, 0.36, 0.36);

    const hl = new T.Group(); scene.add(hl);
    const pieceGroup = new T.Group(); scene.add(pieceGroup);
    const pieces = new Map();
    let arrowMesh = null;

    // ----- pieces -----
    function fillPiece(rec, type) {
      while (rec.group.children.length) rec.group.remove(rec.group.children[0]);
      const white = type[0] === 'w', kind = type[1];
      partsFor(kind, A).forEach((p) => {
        const m = new T.Mesh(p.g, p.accent ? (white ? A.accentW : A.accentB) : (white ? A.white : A.black));
        m.position.set(p.pos[0], p.pos[1], p.pos[2]);
        m.rotation.set(p.rot[0], p.rot[1], p.rot[2]);
        m.castShadow = true; m.receiveShadow = false; // no self-shadow blotches on the pieces
        m.userData.pieceId = rec.id;
        rec.group.add(m);
      });
      rec.group.rotation.y = kind === 'N' ? (white ? 0.95 : 0.95 + Math.PI) : 0; // 3/4 view so the horse head reads from the camera
      rec.type = type; rec.hop = kind === 'N' ? 0.35 : 0.1;
      rec.sy = SY[kind] || 1; rec.group.scale.set(PIECE_SCALE, PIECE_SCALE * rec.sy, PIECE_SCALE);
    }
    function makePiece(p) {
      const rec = { id: p.id, group: new T.Group(), lift: 0, ly: 0, scale: 1, dying: false };
      fillPiece(rec, p.type);
      const x = p.c - 3.5, z = p.r - 3.5;
      rec.group.position.set(x, 0, z); rec.tx = x; rec.tz = z;
      pieceGroup.add(rec.group);
      return rec;
    }

    // ----- highlights / arrow -----
    function flatAt(geo, mat, r, c, y, order) {
      const m = new T.Mesh(geo, mat); m.position.set(c - 3.5, y, r - 3.5); m.renderOrder = order || 1; hl.add(m);
    }
    function drawHighlights(o) {
      while (hl.children.length) hl.remove(hl.children[0]);
      if (o.lastMove) {
        [o.lastMove.from, o.lastMove.to].forEach((q) => {
          flatAt(A.gPlane, A.hlLast, q[0], q[1], 0.012);
          flatAt(A.gOutline, A.hlOutline, q[0], q[1], 0.014);
        });
      }
      if (o.check) flatAt(A.gPlane, A.hlCheck, o.check[0], o.check[1], 0.016, 2);
      if (o.selectedSq) flatAt(A.gPlane, A.hlSel, o.selectedSq[0], o.selectedSq[1], 0.02, 3);
      (o.targets || []).forEach((t) => {
        if (t.capture) flatAt(A.gRing, A.hlCap, t.r, t.c, 0.024, 4);
        else flatAt(A.gDisc, A.hlTarget, t.r, t.c, 0.024, 4);
      });
    }
    function drawArrow(a) {
      if (arrowMesh) { scene.remove(arrowMesh); arrowMesh.geometry.dispose(); arrowMesh = null; }
      if (!a) return;
      const fx = a.from[1] - 3.5, fz = a.from[0] - 3.5, tx = a.to[1] - 3.5, tz = a.to[0] - 3.5;
      const L = Math.max(0.6, Math.hypot(tx - fx, tz - fz) - 0.15), hl2 = 0.36;
      const s = new T.Shape();
      s.moveTo(0, -0.07); s.lineTo(L - hl2, -0.07); s.lineTo(L - hl2, -0.22); s.lineTo(L, 0);
      s.lineTo(L - hl2, 0.22); s.lineTo(L - hl2, 0.07); s.lineTo(0, 0.07); s.closePath();
      const g = new T.ShapeGeometry(s); g.rotateX(-Math.PI / 2);
      arrowMesh = new T.Mesh(g, A.arrow);
      arrowMesh.position.set(fx, 0.03, fz); arrowMesh.rotation.y = -Math.atan2(tz - fz, tx - fx);
      arrowMesh.renderOrder = 5; scene.add(arrowMesh);
    }

    // ----- camera / sizing -----
    function placeCamera() {
      // back off automatically when tilted high or turned diagonally, so the corners never get cropped
      const hi = clamp((view.elev - 0.87) / (MAX_EL - 0.87), 0, 1);
      const fit = (17.4 + 3.6 * hi * hi * (3 - 2 * hi)) * (1 + 0.1 * Math.abs(Math.sin(2 * view.yaw)) * (0.4 + 0.6 * hi));
      const aspect = camera.aspect || 1, d = (fit / Math.min(1, aspect)) * view.zoom;
      camera.position.set(
        target.x + d * Math.sin(view.yaw) * Math.cos(view.elev),
        target.y + d * Math.sin(view.elev),
        target.z + d * Math.cos(view.yaw) * Math.cos(view.elev));
      camera.lookAt(target);
    }
    function resize() {
      const w = host.clientWidth || 300, h = host.clientHeight || 300;
      renderer.setSize(w, h, false);
      camera.aspect = w / h; camera.updateProjectionMatrix();
      placeCamera(); invalidate();
    }

    // ----- loop -----
    let raf = 0, last = 0, disposed = false;
    function invalidate() { if (!raf && !disposed) { last = 0; raf = requestAnimationFrame(frame); } }
    function frame(now) {
      raf = 0;
      if (disposed || active !== api) return;
      const dt = last ? Math.min(0.05, (now - last) / 1000) : 0.016; last = now;
      let busy = false;
      const k = 1 - Math.exp(-dt * 13);
      pieces.forEach((rec, id) => {
        const p = rec.group.position;
        p.x += (rec.tx - p.x) * k; p.z += (rec.tz - p.z) * k;
        rec.ly += (rec.lift - rec.ly) * k;
        const rem = Math.hypot(rec.tx - p.x, rec.tz - p.z);
        p.y = rec.ly + Math.min(0.7, rem * rec.hop);
        if (rem > 0.003 || Math.abs(rec.lift - rec.ly) > 0.003) busy = true;
        else { p.x = rec.tx; p.z = rec.tz; p.y = rec.ly; }
        if (rec.dying) {
          rec.scale -= dt * 5;
          if (rec.scale <= 0) { pieceGroup.remove(rec.group); pieces.delete(id); return; }
          rec.group.scale.set(rec.scale * PIECE_SCALE, rec.scale * PIECE_SCALE * rec.sy, rec.scale * PIECE_SCALE); busy = true;
        }
      });
      if (goal) { // smooth glide for the Top view / Reset buttons
        const g = 1 - Math.exp(-dt * 9);
        view.yaw += (goal.yaw - view.yaw) * g;
        view.elev += (goal.elev - view.elev) * g;
        view.zoom += (goal.zoom - view.zoom) * g;
        if (Math.abs(goal.yaw - view.yaw) < 0.003 && Math.abs(goal.elev - view.elev) < 0.003 && Math.abs(goal.zoom - view.zoom) < 0.003) {
          view.yaw = goal.yaw; view.elev = goal.elev; view.zoom = goal.zoom; goal = null;
        }
        placeCamera(); updateUi(); busy = true;
      }
      renderer.render(scene, camera);
      if (busy || pts.size > 0) raf = requestAnimationFrame(frame);
    }

    // ----- input -----
    const ray = new T.Raycaster(), ndc = new T.Vector2();
    const pts = new Map(); // active pointers (1 finger = rotate/tilt, 2 fingers = zoom)
    let down = null, moved = false, lastPinch = 0;
    const pinchDist = () => { const a = [...pts.values()]; return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y); };
    function pick(clientX, clientY) {
      const b = canvas.getBoundingClientRect();
      let u = (clientX - b.left) / b.width, v = (clientY - b.top) / b.height;
      if (flipped) { u = 1 - u; v = 1 - v; } // board is rotated 180° with CSS in pass-and-play
      ndc.set(u * 2 - 1, -(v * 2 - 1));
      ray.setFromCamera(ndc, camera);
      const hits = ray.intersectObjects(pieceGroup.children.concat(sqMeshes), true);
      for (const h of hits) {
        if (h.object.userData.pieceId != null) {
          const rec = pieces.get(h.object.userData.pieceId);
          if (rec && !rec.dying) return [Math.round(rec.tz + 3.5), Math.round(rec.tx + 3.5)];
        } else if (h.object.userData.sq) return h.object.userData.sq;
      }
      return null;
    }
    function onDown(e) {
      try { canvas.setPointerCapture(e.pointerId); } catch (_) {}
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      goal = null;
      if (pts.size === 1) { down = { x: e.clientX, y: e.clientY }; moved = false; }
      else { moved = true; lastPinch = pinchDist(); }
    }
    function onMove(e) {
      const p = pts.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX; p.y = e.clientY;
      if (pts.size >= 2) {
        const dist = pinchDist();
        if (lastPinch > 0 && dist > 0) view.zoom = clamp(view.zoom * (lastPinch / dist), 0.5, 1.6);
        lastPinch = dist; moved = true;
        placeCamera(); invalidate(); return;
      }
      if (!down) return;
      if (!moved && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 8) moved = true;
      if (moved) {
        const sg = flipped ? -1 : 1; // board is rotated 180° with CSS in pass-and-play
        view.yaw -= sg * dx * 0.009;
        view.elev = clamp(view.elev + sg * dy * 0.008, MIN_EL, MAX_EL);
        placeCamera(); updateUi(); invalidate();
      }
    }
    function onUp(e) {
      pts.delete(e.pointerId);
      if (pts.size > 0) return;
      const wasMoved = moved, d = down; down = null; moved = false; lastPinch = 0;
      if (wasMoved || !d) return;
      const sq = pick(e.clientX, e.clientY);
      if (sq && cbs && cbs.onSquare) cbs.onSquare(sq[0], sq[1]);
    }
    function onCancel(e) { pts.delete(e.pointerId); if (!pts.size) { down = null; moved = false; lastPinch = 0; } }

    // small on-board buttons: Top view / Reset
    const ui = document.createElement('div'); ui.className = 'b3d-ui';
    const btnTop = document.createElement('button'); btnTop.type = 'button';
    const btnReset = document.createElement('button'); btnReset.type = 'button'; btnReset.textContent = 'Reset';
    ui.appendChild(btnTop); ui.appendChild(btnReset);
    function updateUi() { btnTop.textContent = view.elev > 1.3 ? '3D view' : 'Top view'; }
    btnTop.addEventListener('click', () => {
      const spin = Math.round(view.yaw / (2 * Math.PI)) * 2 * Math.PI;
      goal = view.elev > 1.3 ? { yaw: spin, elev: HOME.elev, zoom: 1 } : { yaw: spin, elev: MAX_EL, zoom: 1 };
      invalidate();
    });
    btnReset.addEventListener('click', () => {
      const spin = Math.round(view.yaw / (2 * Math.PI)) * 2 * Math.PI;
      goal = { yaw: spin, elev: HOME.elev, zoom: HOME.zoom }; invalidate();
    });
    updateUi();

    // ----- API -----
    function update(o) {
      flipped = !!o.flipped;
      const seen = new Set();
      o.pieces.forEach((p) => {
        seen.add(p.id);
        let rec = pieces.get(p.id);
        if (!rec) { rec = makePiece(p); pieces.set(p.id, rec); }
        else if (rec.type !== p.type) fillPiece(rec, p.type);
        rec.dying = false; rec.scale = 1; rec.group.scale.set(PIECE_SCALE, PIECE_SCALE * rec.sy, PIECE_SCALE);
        rec.tx = p.c - 3.5; rec.tz = p.r - 3.5;
        rec.lift = p.id === o.selectedId ? 0.3 : 0;
      });
      pieces.forEach((rec, id) => { if (!seen.has(id)) rec.dying = true; });
      drawHighlights(o); drawArrow(o.arrow);
      invalidate();
    }
    function clear() {
      pieces.forEach((rec) => pieceGroup.remove(rec.group));
      pieces.clear(); invalidate();
    }
    function activate() {
      active = api;
      host.insertBefore(canvas, host.firstChild);
      host.appendChild(ui);
      canvas.onpointerdown = onDown; canvas.onpointermove = onMove;
      canvas.onpointerup = onUp; canvas.onpointercancel = onCancel;
      resize();
    }
    function dispose() {
      disposed = true;
      if (raf) cancelAnimationFrame(raf);
      if (ro) ro.disconnect();
      if (ui.parentNode) ui.parentNode.removeChild(ui);
      if (active === api) { active = null; if (canvas.parentNode === host) host.removeChild(canvas); }
    }
    const api = { update, clear, dispose, invalidate, resize };
    let ro = null;
    if (global.ResizeObserver) { ro = new ResizeObserver(() => { if (active === api) resize(); }); ro.observe(host); }
    activate();
    return api;
  }

  global.Board3D = { supported: () => !!getShared(), create };
})(window);
