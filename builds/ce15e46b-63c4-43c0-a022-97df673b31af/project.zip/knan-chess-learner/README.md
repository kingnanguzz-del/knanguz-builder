# Knan Chess Learner

A 5-stage interactive chess teacher built with **React 18 + TypeScript + SCSS + Vite only** —
no chess.js, no UI kit, no animation library. The entire rules engine (legal moves, check,
checkmate, castling, en passant, promotion) is hand-written in `src/utils/chessLogic.ts`.

## Run it

```bash
npm i
npm run dev
```

Then open the printed local URL. `server.host: true` is set in `vite.config.ts` so you can
also open it from your phone on the same Wi-Fi network (use the printed "Network" URL) to test
on Android.

## Structure

```
src/
  App.tsx                 tabs (Learn / Play / Profile), stage routing, progress state
  main.tsx
  styles.scss             the entire design system (dark walnut + brass chess-club theme)
  types.ts
  utils/
    chessLogic.ts          board, move generation, check/checkmate/castling/en passant
    bot.ts                 random bot (Stage 4) + hanging-piece-aware bot (Stage 5)
    storage.ts             localStorage progress, XP, level
  data/
    puzzles.ts             10 hardcoded tactics puzzles
    openings.ts            Italian / Queen's Gambit / Sicilian, 8 half-moves each
  components/
    Board.tsx              the interactive board
    Timer.tsx               countdown clock
    Tooltip.tsx             bottom-sheet move explanation
    BottomNav.tsx
  stages/
    Stage1.tsx … Stage5.tsx
```

## A few deliberate deviations from a literal drag-and-drop spec

- **Tap-to-select, tap-to-move instead of HTML5 drag events.** Native HTML5 drag-and-drop does
  not fire reliably on Android/touch browsers, so it would fail the "must run on Android" goal.
  Tap-to-move gives the same "pick up a piece → see legal squares → place it" feel and actually
  works on a phone.
- **Auto-promotion to queen.** Keeps the interaction simple; the engine itself supports any
  promotion piece (`applyMove(state, from, to, 'q' | 'n' | 'b' | 'r')`) if you want to wire up a
  picker later.
- **One shared game clock** rather than separate per-side clocks, to keep Stage 4/5 simple.
- Draws are detected by stalemate only — there's no 50-move-rule or repetition draw detection.

## Progress & XP

Progress (unlocked stage, XP, solved puzzles, learned openings, pieces explored) is saved to
`localStorage` under the key `knan-chess-progress-v1`. Reset it from the Profile tab.
