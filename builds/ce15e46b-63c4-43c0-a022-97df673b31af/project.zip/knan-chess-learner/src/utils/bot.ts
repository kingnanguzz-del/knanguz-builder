import type { GameState, Move } from '../types';
import { applyMove, getAllLegalMoves, isSquareAttacked, opponent, PIECE_VALUE } from './chessLogic';

function randomOf<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** Stage 4 bot: picks a uniformly random legal move. */
export function randomBotMove(state: GameState): Move | null {
  const moves = getAllLegalMoves(state);
  if (moves.length === 0) return null;
  return randomOf(moves);
}

// Central squares are worth a small bonus so the bot doesn't shuffle rim pieces aimlessly.
const CENTER_BONUS: Record<number, number> = { 2: 0.1, 3: 0.25, 4: 0.25, 5: 0.1 };

/**
 * Stage 5 bot: a lightweight one-ply heuristic.
 * - Prefers capturing more material than it risks.
 * - Avoids moving a piece to a square attacked by the opponent unless the trade is favorable.
 * - Slight preference for central squares and checks.
 */
export function smartBotMove(state: GameState): Move | null {
  const moves = getAllLegalMoves(state);
  if (moves.length === 0) return null;

  let bestScore = -Infinity;
  let bestMoves: Move[] = [];

  for (const move of moves) {
    const { state: next } = applyMove(state, move.from, move.to, 'q', true);
    let score = 0;

    // Reward captures immediately.
    if (move.captured) score += PIECE_VALUE[move.captured.type];

    // Penalize landing somewhere the opponent can recapture for a loss.
    const movedPieceValue = PIECE_VALUE[move.piece.type];
    const canBeRecaptured = isSquareAttacked(next.board, move.to, opponent(move.piece.color));
    if (canBeRecaptured) {
      // If we captured something of equal or greater value, the trade is still fine.
      const gained = move.captured ? PIECE_VALUE[move.captured.type] : 0;
      if (gained < movedPieceValue) {
        score -= movedPieceValue - gained;
      }
    }

    // Small positional nudge toward the center.
    score += (CENTER_BONUS[move.to.row] ?? 0) + (CENTER_BONUS[move.to.col] ?? 0);

    // Slight bonus for giving check — keeps games from feeling passive.
    const givesCheck = isSquareAttacked(next.board, findEnemyKing(next, move.piece.color), move.piece.color);
    if (givesCheck) score += 0.4;

    if (score > bestScore + 1e-9) {
      bestScore = score;
      bestMoves = [move];
    } else if (Math.abs(score - bestScore) < 1e-9) {
      bestMoves.push(move);
    }
  }

  return randomOf(bestMoves);
}

function findEnemyKing(state: GameState, mover: 'w' | 'b') {
  const target = opponent(mover);
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const sq = state.board[r][c];
      if (sq && sq.type === 'k' && sq.color === target) return { row: r, col: c };
    }
  }
  return { row: -1, col: -1 };
}
