import type { Board, CastlingRights, Color, GameState, Move, Piece, PieceType, Pos, Square } from '../types';

// ── Board helpers ──────────────────────────────────────────────────────

export function isInBounds(row: number, col: number): boolean {
  return row >= 0 && row < 8 && col >= 0 && col < 8;
}

export function cloneBoard(board: Board): Board {
  return board.map((row) => row.map((sq) => (sq ? { ...sq } : null)));
}

export function pieceAt(board: Board, pos: Pos): Square {
  if (!isInBounds(pos.row, pos.col)) return null;
  return board[pos.row][pos.col];
}

export function samePos(a: Pos, b: Pos): boolean {
  return a.row === b.row && a.col === b.col;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

export function algebraicToPos(alg: string): Pos {
  const col = FILES.indexOf(alg[0]);
  const row = 8 - parseInt(alg[1], 10);
  return { row, col };
}

export function posToAlgebraic(pos: Pos): string {
  return `${FILES[pos.col]}${8 - pos.row}`;
}

const PIECE_GLYPH: Record<Color, Record<PieceType, string>> = {
  w: { p: '♙', n: '♘', b: '♗', r: '♖', q: '♕', k: '♔' },
  b: { p: '♟', n: '♞', b: '♝', r: '♜', q: '♛', k: '♚' }
};

export function pieceGlyph(piece: Piece): string {
  return PIECE_GLYPH[piece.color][piece.type];
}

export function initialBoard(): Board {
  const back: PieceType[] = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];
  const board: Board = Array.from({ length: 8 }, () => Array<Square>(8).fill(null));
  for (let col = 0; col < 8; col++) {
    board[0][col] = { type: back[col], color: 'b' };
    board[1][col] = { type: 'p', color: 'b' };
    board[6][col] = { type: 'p', color: 'w' };
    board[7][col] = { type: back[col], color: 'w' };
  }
  return board;
}

export function initialState(): GameState {
  return {
    board: initialBoard(),
    turn: 'w',
    castling: { wK: true, wQ: true, bK: true, bQ: true },
    enPassant: null,
    halfmoveClock: 0,
    moveNumber: 1
  };
}

// Build a board from a simplified piece-placement string (FEN's first field only).
// e.g. "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"
export function parseFenBoard(fen: string): Board {
  const rows = fen.split('/');
  const board: Board = Array.from({ length: 8 }, () => Array<Square>(8).fill(null));
  rows.forEach((rowStr, r) => {
    let c = 0;
    for (const ch of rowStr) {
      if (/\d/.test(ch)) {
        c += parseInt(ch, 10);
      } else {
        const color: Color = ch === ch.toUpperCase() ? 'w' : 'b';
        const type = ch.toLowerCase() as PieceType;
        board[r][c] = { type, color };
        c += 1;
      }
    }
  });
  return board;
}

export function opponent(color: Color): Color {
  return color === 'w' ? 'b' : 'w';
}

// ── Attack detection ───────────────────────────────────────────────────

const KNIGHT_DELTAS = [
  [-2, -1], [-2, 1], [-1, -2], [-1, 2],
  [1, -2], [1, 2], [2, -1], [2, 1]
];
const KING_DELTAS = [
  [-1, -1], [-1, 0], [-1, 1], [0, -1],
  [0, 1], [1, -1], [1, 0], [1, 1]
];
const BISHOP_DIRS = [[-1, -1], [-1, 1], [1, -1], [1, 1]];
const ROOK_DIRS = [[-1, 0], [1, 0], [0, -1], [0, 1]];

export function findKing(board: Board, color: Color): Pos {
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const sq = board[r][c];
      if (sq && sq.type === 'k' && sq.color === color) return { row: r, col: c };
    }
  }
  // Should never happen in a valid game, but keep TS happy.
  return { row: -1, col: -1 };
}

export function isSquareAttacked(board: Board, target: Pos, byColor: Color): boolean {
  // Pawns
  const pawnDir = byColor === 'w' ? 1 : -1; // a white pawn attacking `target` sits one rank below (higher row index)
  for (const dc of [-1, 1]) {
    const r = target.row + pawnDir;
    const c = target.col + dc;
    if (isInBounds(r, c)) {
      const sq = board[r][c];
      if (sq && sq.color === byColor && sq.type === 'p') return true;
    }
  }
  // Knights
  for (const [dr, dc] of KNIGHT_DELTAS) {
    const r = target.row + dr;
    const c = target.col + dc;
    if (isInBounds(r, c)) {
      const sq = board[r][c];
      if (sq && sq.color === byColor && sq.type === 'n') return true;
    }
  }
  // King
  for (const [dr, dc] of KING_DELTAS) {
    const r = target.row + dr;
    const c = target.col + dc;
    if (isInBounds(r, c)) {
      const sq = board[r][c];
      if (sq && sq.color === byColor && sq.type === 'k') return true;
    }
  }
  // Sliding: bishop/queen diagonals
  for (const [dr, dc] of BISHOP_DIRS) {
    let r = target.row + dr;
    let c = target.col + dc;
    while (isInBounds(r, c)) {
      const sq = board[r][c];
      if (sq) {
        if (sq.color === byColor && (sq.type === 'b' || sq.type === 'q')) return true;
        break;
      }
      r += dr;
      c += dc;
    }
  }
  // Sliding: rook/queen orthogonals
  for (const [dr, dc] of ROOK_DIRS) {
    let r = target.row + dr;
    let c = target.col + dc;
    while (isInBounds(r, c)) {
      const sq = board[r][c];
      if (sq) {
        if (sq.color === byColor && (sq.type === 'r' || sq.type === 'q')) return true;
        break;
      }
      r += dr;
      c += dc;
    }
  }
  return false;
}

export function isKingInCheck(board: Board, color: Color): boolean {
  const kingPos = findKing(board, color);
  if (kingPos.row === -1) return false;
  return isSquareAttacked(board, kingPos, opponent(color));
}

// ── Pseudo-legal move generation (per piece, ignores whether own king ends in check) ──

function pawnMoves(state: GameState, pos: Pos): Pos[] {
  const { board, enPassant } = state;
  const piece = board[pos.row][pos.col]!;
  const dir = piece.color === 'w' ? -1 : 1;
  const startRow = piece.color === 'w' ? 6 : 1;
  const moves: Pos[] = [];

  const oneAhead = { row: pos.row + dir, col: pos.col };
  if (isInBounds(oneAhead.row, oneAhead.col) && !board[oneAhead.row][oneAhead.col]) {
    moves.push(oneAhead);
    const twoAhead = { row: pos.row + dir * 2, col: pos.col };
    if (pos.row === startRow && !board[twoAhead.row][twoAhead.col]) {
      moves.push(twoAhead);
    }
  }
  for (const dc of [-1, 1]) {
    const target = { row: pos.row + dir, col: pos.col + dc };
    if (!isInBounds(target.row, target.col)) continue;
    const occupant = board[target.row][target.col];
    if (occupant && occupant.color !== piece.color) {
      moves.push(target);
    } else if (enPassant && samePos(enPassant, target)) {
      moves.push(target);
    }
  }
  return moves;
}

function knightMoves(board: Board, pos: Pos): Pos[] {
  const piece = board[pos.row][pos.col]!;
  const moves: Pos[] = [];
  for (const [dr, dc] of KNIGHT_DELTAS) {
    const r = pos.row + dr;
    const c = pos.col + dc;
    if (!isInBounds(r, c)) continue;
    const occupant = board[r][c];
    if (!occupant || occupant.color !== piece.color) moves.push({ row: r, col: c });
  }
  return moves;
}

function slidingMoves(board: Board, pos: Pos, dirs: number[][]): Pos[] {
  const piece = board[pos.row][pos.col]!;
  const moves: Pos[] = [];
  for (const [dr, dc] of dirs) {
    let r = pos.row + dr;
    let c = pos.col + dc;
    while (isInBounds(r, c)) {
      const occupant = board[r][c];
      if (!occupant) {
        moves.push({ row: r, col: c });
      } else {
        if (occupant.color !== piece.color) moves.push({ row: r, col: c });
        break;
      }
      r += dr;
      c += dc;
    }
  }
  return moves;
}

function kingMoves(state: GameState, pos: Pos): Pos[] {
  const { board, castling } = state;
  const piece = board[pos.row][pos.col]!;
  const moves: Pos[] = [];
  for (const [dr, dc] of KING_DELTAS) {
    const r = pos.row + dr;
    const c = pos.col + dc;
    if (!isInBounds(r, c)) continue;
    const occupant = board[r][c];
    if (!occupant || occupant.color !== piece.color) moves.push({ row: r, col: c });
  }
  // Castling
  const opp = opponent(piece.color);
  const homeRow = piece.color === 'w' ? 7 : 0;
  if (pos.row === homeRow && pos.col === 4 && !isSquareAttacked(board, pos, opp)) {
    const kingSideAllowed = piece.color === 'w' ? castling.wK : castling.bK;
    const queenSideAllowed = piece.color === 'w' ? castling.wQ : castling.bQ;
    if (kingSideAllowed && !board[homeRow][5] && !board[homeRow][6]) {
      const rook = board[homeRow][7];
      if (rook && rook.type === 'r' && rook.color === piece.color) {
        if (!isSquareAttacked(board, { row: homeRow, col: 5 }, opp) && !isSquareAttacked(board, { row: homeRow, col: 6 }, opp)) {
          moves.push({ row: homeRow, col: 6 });
        }
      }
    }
    if (queenSideAllowed && !board[homeRow][1] && !board[homeRow][2] && !board[homeRow][3]) {
      const rook = board[homeRow][0];
      if (rook && rook.type === 'r' && rook.color === piece.color) {
        if (!isSquareAttacked(board, { row: homeRow, col: 3 }, opp) && !isSquareAttacked(board, { row: homeRow, col: 2 }, opp)) {
          moves.push({ row: homeRow, col: 2 });
        }
      }
    }
  }
  return moves;
}

export function getPseudoLegalMoves(state: GameState, pos: Pos): Pos[] {
  const piece = pieceAt(state.board, pos);
  if (!piece) return [];
  switch (piece.type) {
    case 'p': return pawnMoves(state, pos);
    case 'n': return knightMoves(state.board, pos);
    case 'b': return slidingMoves(state.board, pos, BISHOP_DIRS);
    case 'r': return slidingMoves(state.board, pos, ROOK_DIRS);
    case 'q': return slidingMoves(state.board, pos, [...BISHOP_DIRS, ...ROOK_DIRS]);
    case 'k': return kingMoves(state, pos);
  }
}

// ── Legal move generation (filters out moves that leave own king in check) ──

export function getLegalMoves(state: GameState, pos: Pos): Pos[] {
  const piece = pieceAt(state.board, pos);
  if (!piece) return [];
  const candidates = getPseudoLegalMoves(state, pos);
  return candidates.filter((target) => {
    const { state: next } = applyMove(state, pos, target, 'q', true);
    return !isKingInCheck(next.board, piece.color);
  });
}

export function getAllLegalMoves(state: GameState): Move[] {
  const moves: Move[] = [];
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = state.board[r][c];
      if (piece && piece.color === state.turn) {
        const from = { row: r, col: c };
        for (const to of getLegalMoves(state, from)) {
          moves.push({ from, to, piece, captured: state.board[to.row][to.col] });
        }
      }
    }
  }
  return moves;
}

// ── Applying a move (immutable) ────────────────────────────────────────

export function applyMove(
  state: GameState,
  from: Pos,
  to: Pos,
  promotion: PieceType = 'q',
  quiet = false
): { state: GameState; move: Move } {
  const board = cloneBoard(state.board);
  const piece = board[from.row][from.col]!;
  let captured: Piece | null = board[to.row][to.col];
  let isEnPassant = false;
  let isCastle: 'K' | 'Q' | undefined;

  // En passant capture
  if (piece.type === 'p' && state.enPassant && samePos(to, state.enPassant) && !captured) {
    isEnPassant = true;
    const capturedRow = piece.color === 'w' ? to.row + 1 : to.row - 1;
    captured = board[capturedRow][to.col];
    board[capturedRow][to.col] = null;
  }

  // Castling: move the rook too
  if (piece.type === 'k' && Math.abs(to.col - from.col) === 2) {
    const row = from.row;
    if (to.col === 6) {
      isCastle = 'K';
      board[row][5] = board[row][7];
      board[row][7] = null;
    } else if (to.col === 2) {
      isCastle = 'Q';
      board[row][3] = board[row][0];
      board[row][0] = null;
    }
  }

  board[to.row][to.col] = piece;
  board[from.row][from.col] = null;

  // Promotion
  if (piece.type === 'p' && (to.row === 0 || to.row === 7)) {
    board[to.row][to.col] = { type: promotion, color: piece.color };
  }

  // Update castling rights
  const castling: CastlingRights = { ...state.castling };
  if (piece.type === 'k') {
    if (piece.color === 'w') { castling.wK = false; castling.wQ = false; }
    else { castling.bK = false; castling.bQ = false; }
  }
  if (piece.type === 'r') {
    if (from.row === 7 && from.col === 0) castling.wQ = false;
    if (from.row === 7 && from.col === 7) castling.wK = false;
    if (from.row === 0 && from.col === 0) castling.bQ = false;
    if (from.row === 0 && from.col === 7) castling.bK = false;
  }
  if (to.row === 7 && to.col === 0) castling.wQ = false;
  if (to.row === 7 && to.col === 7) castling.wK = false;
  if (to.row === 0 && to.col === 0) castling.bQ = false;
  if (to.row === 0 && to.col === 7) castling.bK = false;

  // En passant target for next move
  let enPassant: Pos | null = null;
  if (piece.type === 'p' && Math.abs(to.row - from.row) === 2) {
    enPassant = { row: (to.row + from.row) / 2, col: to.col };
  }

  const nextState: GameState = {
    board,
    turn: opponent(state.turn),
    castling,
    enPassant,
    halfmoveClock: piece.type === 'p' || captured ? 0 : state.halfmoveClock + 1,
    moveNumber: state.turn === 'b' ? state.moveNumber + 1 : state.moveNumber
  };

  const move: Move = {
    from,
    to,
    piece,
    captured,
    promotion: piece.type === 'p' && (to.row === 0 || to.row === 7) ? promotion : undefined,
    isCastle,
    isEnPassant,
    notation: quiet ? undefined : `${posToAlgebraic(from)}${posToAlgebraic(to)}`
  };

  return { state: nextState, move };
}

// ── Game-end detection ──────────────────────────────────────────────────

export function isCheckmate(state: GameState): boolean {
  if (!isKingInCheck(state.board, state.turn)) return false;
  return getAllLegalMoves(state).length === 0;
}

export function isStalemate(state: GameState): boolean {
  if (isKingInCheck(state.board, state.turn)) return false;
  return getAllLegalMoves(state).length === 0;
}

export function gameStatus(state: GameState): 'check' | 'checkmate' | 'stalemate' | 'playing' {
  if (isCheckmate(state)) return 'checkmate';
  if (isStalemate(state)) return 'stalemate';
  if (isKingInCheck(state.board, state.turn)) return 'check';
  return 'playing';
}

// ── Piece values (used by bots + hanging-piece detection) ───────────────

export const PIECE_VALUE: Record<PieceType, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

export function materialValue(board: Board, color: Color): number {
  let total = 0;
  for (const row of board) {
    for (const sq of row) {
      if (sq && sq.color === color) total += PIECE_VALUE[sq.type];
    }
  }
  return total;
}
