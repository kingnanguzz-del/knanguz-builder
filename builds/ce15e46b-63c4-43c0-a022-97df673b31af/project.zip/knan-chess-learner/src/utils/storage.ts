import type { PieceType, Progress, StageId } from '../types';

const KEY = 'knan-chess-progress-v1';

function defaultProgress(): Progress {
  return {
    unlockedStage: 1,
    xp: 0,
    completedPuzzles: [],
    completedOpenings: [],
    stage1Seen: []
  };
}

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultProgress();
    const parsed = JSON.parse(raw);
    return { ...defaultProgress(), ...parsed };
  } catch {
    return defaultProgress();
  }
}

export function saveProgress(progress: Progress): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(progress));
  } catch {
    // localStorage unavailable (private mode etc) — fail silently, app still works in-session
  }
}

export function addXp(progress: Progress, amount: number): Progress {
  return { ...progress, xp: progress.xp + amount };
}

export function unlockNextStage(progress: Progress, completed: StageId): Progress {
  const next = Math.min(5, completed + 1) as StageId;
  if (progress.unlockedStage >= next) return progress;
  return { ...progress, unlockedStage: next };
}

export function markPuzzleDone(progress: Progress, id: number): Progress {
  if (progress.completedPuzzles.includes(id)) return progress;
  return { ...progress, completedPuzzles: [...progress.completedPuzzles, id] };
}

export function markOpeningDone(progress: Progress, id: string): Progress {
  if (progress.completedOpenings.includes(id)) return progress;
  return { ...progress, completedOpenings: [...progress.completedOpenings, id] };
}

export function markPieceSeen(progress: Progress, type: PieceType): Progress {
  if (progress.stage1Seen.includes(type)) return progress;
  return { ...progress, stage1Seen: [...progress.stage1Seen, type] };
}

export function levelFromXp(xp: number): number {
  return Math.floor(xp / 100) + 1;
}

export function xpIntoLevel(xp: number): { current: number; needed: number } {
  const current = xp % 100;
  return { current, needed: 100 };
}
