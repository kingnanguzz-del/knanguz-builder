import { useEffect, useMemo, useState } from 'react';
import Board from '../components/Board';
import { OPENINGS } from '../data/openings';
import type { GameState, Progress } from '../types';
import { algebraicToPos, applyMove, initialState } from '../utils/chessLogic';

interface Stage3Props {
  progress: Progress;
  onAttempt: () => void;
  onOpeningComplete: (id: string) => void;
}

export default function Stage3({ progress, onAttempt, onOpeningComplete }: Stage3Props) {
  const [openingIndex, setOpeningIndex] = useState(0);
  const opening = OPENINGS[openingIndex];
  const [step, setStep] = useState(0); // number of half-moves played, 0..8
  const [autoPlay, setAutoPlay] = useState(false);

  const states = useMemo(() => {
    // Precompute the board position after each half-move so scrubbing is instant.
    let s: GameState = initialState();
    const list: GameState[] = [s];
    for (const mv of opening.moves) {
      const from = algebraicToPos(mv.from);
      const to = algebraicToPos(mv.to);
      const { state: next } = applyMove(s, from, to);
      list.push(next);
      s = next;
    }
    return list;
  }, [opening]);

  useEffect(() => {
    setStep(0);
    setAutoPlay(false);
  }, [openingIndex]);

  useEffect(() => {
    if (!autoPlay) return;
    if (step >= opening.moves.length) {
      setAutoPlay(false);
      onOpeningComplete(opening.id);
      return;
    }
    const id = setTimeout(() => setStep((s) => s + 1), 1400);
    return () => clearTimeout(id);
  }, [autoPlay, step, opening]);

  useEffect(() => {
    if (step === opening.moves.length) onOpeningComplete(opening.id);
  }, [step, opening]);

  useEffect(() => {
    if (step > 0) onAttempt();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  const currentMove = step > 0 ? opening.moves[step - 1] : null;
  const lastMove =
    currentMove != null
      ? { from: algebraicToPos(currentMove.from), to: algebraicToPos(currentMove.to), piece: { type: 'p' as const, color: 'w' as const } }
      : null;

  return (
    <div>
      <div className="section-title">Stage 3 · Openings</div>
      <p className="section-sub">
        Step through the first {opening.moves.length} moves of three essential openings, with the idea behind each move
        explained as you go.
      </p>

      <div className="row row--wrap" style={{ gap: 8, marginBottom: 12 }}>
        {OPENINGS.map((o, i) => (
          <button
            key={o.id}
            className={`btn btn--sm ${i === openingIndex ? 'btn--primary' : 'btn--ghost'}`}
            onClick={() => setOpeningIndex(i)}
          >
            {o.name} {progress.completedOpenings.includes(o.id) ? '✓' : ''}
          </button>
        ))}
      </div>

      <p className="text-dim" style={{ fontSize: 13, marginBottom: 14 }}>
        {opening.description}
      </p>

      <Board state={states[step]} interactiveColor="none" onAttemptMove={() => {}} lastMove={lastMove} />

      <div className="opening-step-dots">
        {opening.moves.map((_, i) => (
          <span key={i} className={`opening-step-dots__dot ${i === step - 1 ? 'active' : i < step - 1 ? 'done' : ''}`} />
        ))}
      </div>

      <div className="card mt-16" style={{ minHeight: 78 }}>
        {currentMove ? (
          <>
            <div className="row row--between">
              <strong style={{ fontFamily: 'var(--font-mono)' }}>
                {Math.ceil(step / 2)}. {currentMove.san}
              </strong>
              <span className="text-dim" style={{ fontSize: 11 }}>
                move {step} / {opening.moves.length}
              </span>
            </div>
            <p className="text-dim" style={{ fontSize: 13.5, marginTop: 6, lineHeight: 1.5 }}>
              {currentMove.note}
            </p>
          </>
        ) : (
          <p className="text-dim" style={{ fontSize: 13.5 }}>Press play to start the sequence from the opening position.</p>
        )}
      </div>

      <div className="row" style={{ marginTop: 16, justifyContent: 'center', gap: 10 }}>
        <button className="btn btn--ghost" disabled={step === 0} onClick={() => setStep((s) => Math.max(0, s - 1))}>
          ← Back
        </button>
        <button
          className="btn btn--felt"
          onClick={() => setAutoPlay((a) => !a)}
          disabled={step >= opening.moves.length}
        >
          {autoPlay ? '⏸ Pause' : '▶ Auto-play'}
        </button>
        <button
          className="btn btn--primary"
          disabled={step >= opening.moves.length}
          onClick={() => setStep((s) => Math.min(opening.moves.length, s + 1))}
        >
          Next →
        </button>
      </div>
    </div>
  );
}
