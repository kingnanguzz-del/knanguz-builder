import { useMemo, useState } from 'react';
import Board from '../components/Board';
import Tooltip from '../components/Tooltip';
import { PUZZLES } from '../data/puzzles';
import type { GameState, Pos, Progress } from '../types';
import { applyMove, parseFenBoard, posToAlgebraic } from '../utils/chessLogic';

interface Stage2Props {
  progress: Progress;
  onAttempt: () => void;
  onSolved: (puzzleId: number) => void;
}

function buildState(fenBoard: string, turn: 'w' | 'b'): GameState {
  return {
    board: parseFenBoard(fenBoard),
    turn,
    castling: { wK: false, wQ: false, bK: false, bQ: false },
    enPassant: null,
    halfmoveClock: 0,
    moveNumber: 1
  };
}

export default function Stage2({ progress, onAttempt, onSolved }: Stage2Props) {
  const [index, setIndex] = useState(0);
  const puzzle = PUZZLES[index];

  const baseState = useMemo(() => buildState(puzzle.fenBoard, puzzle.turn), [puzzle]);
  const [displayState, setDisplayState] = useState(baseState);
  const [popup, setPopup] = useState<'good' | 'bad' | null>(null);
  const [hint, setHint] = useState(false);
  const [solved, setSolved] = useState(progress.completedPuzzles.includes(puzzle.id));

  function loadPuzzle(i: number) {
    const p = PUZZLES[i];
    setIndex(i);
    setDisplayState(buildState(p.fenBoard, p.turn));
    setPopup(null);
    setHint(false);
    setSolved(progress.completedPuzzles.includes(p.id));
  }

  function handleAttempt(from: Pos, to: Pos) {
    const attempt = `${posToAlgebraic(from)}${posToAlgebraic(to)}`;
    onAttempt();
    if (puzzle.solution.includes(attempt)) {
      const { state: next } = applyMove(displayState, from, to);
      setDisplayState(next);
      setPopup('good');
      setSolved(true);
      onSolved(puzzle.id);
    } else {
      setPopup('bad');
    }
  }

  const hintPos = puzzle.solution[0];
  const hintFrom = hintPos.slice(0, 2);
  const hintTo = hintPos.slice(2, 4);

  return (
    <div>
      <div className="section-title">Stage 2 · Tactics</div>
      <p className="section-sub">
        Find the strongest move in each position. Ten hand-picked puzzles cover forks, pins, skewers, and mates. Tap a
        piece, then tap a highlighted square to play your answer.
      </p>

      <div className="puzzle-nav">
        {PUZZLES.map((p, i) => (
          <button
            key={p.id}
            className={`puzzle-chip ${i === index ? 'active' : ''} ${progress.completedPuzzles.includes(p.id) ? 'done' : ''}`}
            onClick={() => loadPuzzle(i)}
          >
            {p.id}
          </button>
        ))}
      </div>

      <div className="card row row--between" style={{ marginBottom: 12 }}>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 16 }}>{puzzle.title}</div>
          <div className="text-dim" style={{ fontSize: 12 }}>
            {puzzle.turn === 'w' ? 'White' : 'Black'} to move{solved ? ' · solved' : ''}
          </div>
        </div>
        <button className="btn btn--ghost btn--sm" onClick={() => setHint((h) => !h)}>
          💡 Hint
        </button>
      </div>

      {hint && (
        <p className="text-dim text-center" style={{ fontSize: 12.5, marginBottom: 10 }}>
          Best move: <strong style={{ color: 'var(--brass-bright)' }}>{hintFrom} → {hintTo}</strong>
        </p>
      )}

      <Board state={displayState} interactiveColor="both" onAttemptMove={handleAttempt} />

      <div className="row" style={{ marginTop: 16, justifyContent: 'center', gap: 12 }}>
        <button className="btn btn--ghost" disabled={index === 0} onClick={() => loadPuzzle(index - 1)}>
          ← Prev
        </button>
        <button className="btn btn--primary" disabled={index === PUZZLES.length - 1} onClick={() => loadPuzzle(index + 1)}>
          Next →
        </button>
      </div>

      {popup === 'good' && (
        <Tooltip
          kind="good"
          title="Correct!"
          text={puzzle.explanation}
          actionLabel={index < PUZZLES.length - 1 ? 'Next puzzle' : 'Done'}
          onClose={() => {
            setPopup(null);
            if (index < PUZZLES.length - 1) loadPuzzle(index + 1);
          }}
        />
      )}
      {popup === 'bad' && (
        <Tooltip kind="bad" title="Not the best move" text={puzzle.wrongExplanation} onClose={() => setPopup(null)} />
      )}
    </div>
  );
}
