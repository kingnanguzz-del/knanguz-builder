import { useEffect, useRef, useState } from 'react';
import Board from '../components/Board';
import Timer from '../components/Timer';
import type { GameState, Move, Pos } from '../types';
import { applyMove, gameStatus, initialState, parseFenBoard, pieceGlyph } from '../utils/chessLogic';
import { randomBotMove, smartBotMove } from '../utils/bot';

interface Stage5Props {
  onXp: (amount: number) => void;
  onWin: () => void;
}

const TIME_LIMIT = 5 * 60;

function endgameState(): GameState {
  // White king + queen vs lone black king — the classic KQvK checkmating drill.
  return {
    board: parseFenBoard('4k3/8/8/8/8/8/8/3QK3'),
    turn: 'w',
    castling: { wK: false, wQ: false, bK: false, bQ: false },
    enPassant: null,
    halfmoveClock: 0,
    moveNumber: 1
  };
}

export default function Stage5({ onXp, onWin }: Stage5Props) {
  const [mode, setMode] = useState<'game' | 'endgame'>('game');
  const [gameKey, setGameKey] = useState(0);
  const [state, setState] = useState<GameState>(initialState());
  const [lastMove, setLastMove] = useState<Move | null>(null);
  const [captured, setCaptured] = useState<{ w: string[]; b: string[] }>({ w: [], b: [] });
  const [result, setResult] = useState<'win' | 'loss' | 'draw' | 'timeout' | null>(null);
  const [botThinking, setBotThinking] = useState(false);
  const awardedRef = useRef(false);

  function reset(nextMode: 'game' | 'endgame' = mode) {
    setMode(nextMode);
    setState(nextMode === 'game' ? initialState() : endgameState());
    setLastMove(null);
    setCaptured({ w: [], b: [] });
    setResult(null);
    setBotThinking(false);
    awardedRef.current = false;
    setGameKey((k) => k + 1);
  }

  function recordCapture(move: Move) {
    if (!move.captured) return;
    setCaptured((c) =>
      move.piece.color === 'w'
        ? { ...c, w: [...c.w, move.captured!.type] }
        : { ...c, b: [...c.b, move.captured!.type] }
    );
  }

  function finishIfOver(next: GameState, lastMover: 'w' | 'b') {
    const status = gameStatus(next);
    if (status === 'checkmate') {
      setResult(lastMover === 'w' ? 'win' : 'loss');
      if (lastMover === 'w' && !awardedRef.current) {
        awardedRef.current = true;
        onXp(mode === 'endgame' ? 60 : 120);
        onWin();
      }
      return true;
    }
    if (status === 'stalemate') {
      setResult('draw');
      return true;
    }
    return false;
  }

  function handleUserMove(from: Pos, to: Pos) {
    if (result || botThinking) return;
    const piece = state.board[from.row][from.col];
    if (!piece || piece.color !== 'w') return;
    const { state: next, move } = applyMove(state, from, to);
    setState(next);
    setLastMove(move);
    recordCapture(move);
    if (finishIfOver(next, 'w')) return;
    setBotThinking(true);
  }

  useEffect(() => {
    if (!botThinking) return;
    const id = setTimeout(() => {
      // In the endgame drill Black has only a king, so a random legal move is enough;
      // in a full game, use the hanging-piece-aware bot.
      const move = mode === 'endgame' ? randomBotMove(state) : smartBotMove(state);
      if (!move) {
        setBotThinking(false);
        return;
      }
      const { state: next, move: applied } = applyMove(state, move.from, move.to);
      setState(next);
      setLastMove(applied);
      recordCapture(applied);
      setBotThinking(false);
      finishIfOver(next, 'b');
    }, 550);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [botThinking]);

  return (
    <div>
      <div className="section-title">Stage 5 · Pro</div>
      <p className="section-sub">
        The bot now avoids hanging its pieces and looks for checks, so careless moves get punished. Or switch to the
        King + Queen vs King drill to sharpen your basic checkmating technique.
      </p>

      <div className="row" style={{ gap: 8, marginBottom: 14 }}>
        <button className={`btn btn--sm ${mode === 'game' ? 'btn--primary' : 'btn--ghost'}`} onClick={() => reset('game')}>
          Full Game
        </button>
        <button className={`btn btn--sm ${mode === 'endgame' ? 'btn--primary' : 'btn--ghost'}`} onClick={() => reset('endgame')}>
          K+Q vs K Drill
        </button>
      </div>

      <div className="row row--between" style={{ marginBottom: 10 }}>
        <div className="captured-tray">
          {captured.b.map((t, i) => (
            <span key={i}>{pieceGlyph({ type: t as any, color: 'b' })}</span>
          ))}
        </div>
        <Timer
          initialSeconds={TIME_LIMIT}
          running={!result}
          resetKey={gameKey}
          onExpire={() => setResult((r) => r ?? 'timeout')}
        />
      </div>

      <Board state={state} interactiveColor={botThinking || !!result ? 'none' : 'w'} onAttemptMove={handleUserMove} lastMove={lastMove} />

      <div className="captured-tray" style={{ marginTop: 8 }}>
        {captured.w.map((t, i) => (
          <span key={i}>{pieceGlyph({ type: t as any, color: 'w' })}</span>
        ))}
      </div>

      {mode === 'endgame' && !result && (
        <p className="text-dim text-center" style={{ fontSize: 12.5, marginTop: 8 }}>
          Tip: use your king and queen together to herd the black king toward the edge of the board, then deliver mate.
        </p>
      )}

      {botThinking && !result && (
        <p className="text-dim text-center" style={{ fontSize: 12.5, marginTop: 8 }}>
          Bot is thinking…
        </p>
      )}

      {result && (
        <div className={`status-banner ${result === 'win' ? 'win' : result === 'loss' || result === 'timeout' ? 'loss' : ''} mt-16`}>
          {result === 'win' && `Checkmate — you win! +${mode === 'endgame' ? 60 : 120} XP`}
          {result === 'loss' && 'Checkmate — the bot wins this one.'}
          {result === 'draw' && 'Stalemate — it\'s a draw.'}
          {result === 'timeout' && 'Time\'s up.'}
        </div>
      )}

      <button className="btn btn--ghost btn--block mt-16" onClick={() => reset()}>
        ↻ New Game
      </button>
    </div>
  );
}
