import type { Puzzle } from '../types';

// Each fenBoard is the piece-placement field only (ranks 8→1, separated by "/").
// Positions are deliberately minimal so the tactic is unambiguous and easy to verify by eye.
export const PUZZLES: Puzzle[] = [
  {
    id: 1,
    title: 'Back-Rank Mate',
    fenBoard: '6k1/5ppp/8/8/8/8/8/4R2K',
    turn: 'w',
    solution: ['e1e8'],
    explanation:
      'Re1-e8 is checkmate. The black king cannot step to f8 or h8 because your rook covers the whole 8th rank, and g7/f7/h7 pawns block every other escape square.',
    wrongExplanation: 'Wrong. Better was Re1-e8, delivering checkmate along the open back rank — the king has nowhere to run.'
  },
  {
    id: 2,
    title: 'Free Piece',
    fenBoard: '4k3/8/8/r7/8/8/8/Q3K3',
    turn: 'w',
    solution: ['a1a5'],
    explanation:
      'The rook on a5 is completely undefended. Qxa5 simply wins it for free — always scan for hanging pieces before looking for anything fancier.',
    wrongExplanation: 'Wrong. Better was Qa1xa5, capturing the undefended rook — free material was sitting right there.'
  },
  {
    id: 3,
    title: 'Knight Fork',
    fenBoard: '8/2q1k3/8/8/1N6/8/8/4K3',
    turn: 'w',
    solution: ['b4d5'],
    explanation:
      'Nd5+ forks the king on e7 and the queen on c7 at the same time. The king must move out of check, and next turn the knight scoops up the queen.',
    wrongExplanation: 'Wrong. Better was Nb4-d5+, forking the king and queen — one knight move threatens both.'
  },
  {
    id: 4,
    title: 'Exploit the Pin',
    fenBoard: '4k3/8/8/4n3/3P4/8/8/4R1K1',
    turn: 'w',
    solution: ['d4e5'],
    explanation:
      'The knight on e5 is pinned to the king by your rook on e1 — it is not allowed to move at all. That means dxe5 wins it for nothing, since it cannot even recapture.',
    wrongExplanation: 'Wrong. Better was dxe5 — the knight was pinned by your rook and legally could not move, so it was free to take.'
  },
  {
    id: 5,
    title: 'Discovered Attack',
    fenBoard: '4q3/8/8/8/4B3/8/8/4R1K1',
    turn: 'w',
    solution: ['e4d5'],
    explanation:
      'Moving the bishop off the e-file uncovers your rook, which now attacks the queen on e8 down the open file. The queen must move immediately or be lost.',
    wrongExplanation: 'Wrong. Better was Be4-d5 — stepping the bishop aside reveals your rook attacking the queen on e8.'
  },
  {
    id: 6,
    title: 'Skewer',
    fenBoard: '4r3/4k3/8/8/8/8/8/Q5K1',
    turn: 'w',
    solution: ['a1e5'],
    explanation:
      'Qe5+ lines up the king and rook on the same file. The king is forced to move off the e-file, and then Qxe8 collects the rook behind it.',
    wrongExplanation: 'Wrong. Better was Qa1-e5+ — a skewer that forces the king to move, then wins the rook standing behind it.'
  },
  {
    id: 7,
    title: 'Pawn Fork',
    fenBoard: '4k3/8/2n1b3/8/3P4/8/8/4K3',
    turn: 'w',
    solution: ['d4d5'],
    explanation:
      'The humble pawn push d4-d5 attacks both the knight on c6 and the bishop on e6 at once. A pawn fork wins a whole piece since both cannot be saved.',
    wrongExplanation: 'Wrong. Better was d4-d5 — the pawn attacks both minor pieces at once, and only one can escape.'
  },
  {
    id: 8,
    title: 'Rook Fork',
    fenBoard: '4k3/8/r6b/8/8/8/8/3R2K1',
    turn: 'w',
    solution: ['d1d6'],
    explanation:
      'Rd6 lands in the middle of the open 6th rank, attacking the rook on a6 and the bishop on h6 simultaneously. One of them is lost.',
    wrongExplanation: 'Wrong. Better was Rd1-d6 — the rook forks both black pieces along the open rank.'
  },
  {
    id: 9,
    title: 'Queen Fork',
    fenBoard: 'r6r/4k3/8/3Q4/8/8/8/4K3',
    turn: 'w',
    solution: ['d5d8'],
    explanation:
      'Qd8 attacks both rooks on the back rank at the same time. Whichever one moves, the queen takes the other.',
    wrongExplanation: 'Wrong. Better was Qd5-d8 — it forks both rooks on the 8th rank.'
  },
  {
    id: 10,
    title: 'Queen Infiltration Mate',
    fenBoard: '7k/6pp/8/8/8/8/8/1K1Q4',
    turn: 'w',
    solution: ['d1d8'],
    explanation:
      'Qd8 is checkmate. The king cannot step to g8 because the queen covers the whole 8th rank, and g7/h7 are blocked by its own pawns.',
    wrongExplanation: 'Wrong. Better was Qd1-d8, delivering mate on the back rank — the king was boxed in by its own pawns.'
  }
];
