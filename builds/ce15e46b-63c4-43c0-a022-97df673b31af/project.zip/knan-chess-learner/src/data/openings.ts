import type { Opening } from '../types';

export const OPENINGS: Opening[] = [
  {
    id: 'italian',
    name: 'Italian Game',
    description:
      'One of the oldest recorded openings. Both sides develop naturally and aim the bishop at the weak f7/f2 square early.',
    moves: [
      { san: 'e4', from: 'e2', to: 'e4', note: 'Claims the center and opens lines for the bishop and queen.' },
      { san: 'e5', from: 'e7', to: 'e5', note: 'Black mirrors White, fighting for the same central squares.' },
      { san: 'Nf3', from: 'g1', to: 'f3', note: 'Develops a piece and attacks the e5 pawn.' },
      { san: 'Nc6', from: 'b8', to: 'c6', note: 'Defends e5 and develops toward the center.' },
      { san: 'Bc4', from: 'f1', to: 'c4', note: 'The "Italian" bishop eyes the fragile f7 square.' },
      { san: 'Bc5', from: 'f8', to: 'c5', note: 'Black develops symmetrically, eyeing f2 in return.' },
      { san: 'c3', from: 'c2', to: 'c3', note: 'Prepares d4 to build a big center.' },
      { san: 'Nf6', from: 'g8', to: 'f6', note: 'Develops and attacks the e4 pawn, keeping the position balanced.' }
    ]
  },
  {
    id: 'queens-gambit',
    name: "Queen's Gambit",
    description:
      'A positional opening where White offers a wing pawn to build a strong, flexible center. Black rarely keeps the pawn.',
    moves: [
      { san: 'd4', from: 'd2', to: 'd4', note: 'Grabs the center with the queen pawn.' },
      { san: 'd5', from: 'd7', to: 'd5', note: 'Black stakes an equal claim in the center.' },
      { san: 'c4', from: 'c2', to: 'c4', note: 'The "gambit" — White offers the c-pawn to pull Black\'s d-pawn away from the center.' },
      { san: 'e6', from: 'e7', to: 'e6', note: 'Black declines the pawn and solidifies d5 instead (Queen\'s Gambit Declined).' },
      { san: 'Nc3', from: 'b1', to: 'c3', note: 'Develops and adds pressure on d5.' },
      { san: 'Nf6', from: 'g8', to: 'f6', note: 'Develops and defends d5 again.' },
      { san: 'Bg5', from: 'c1', to: 'g5', note: 'Pins the knight to the queen, adding more pressure on the center.' },
      { san: 'Be7', from: 'f8', to: 'e7', note: 'Breaks the pin and prepares to castle.' }
    ]
  },
  {
    id: 'sicilian',
    name: 'Sicilian Defense',
    description:
      "Black's most popular and combative reply to 1.e4, fighting for the center asymmetrically instead of mirroring White.",
    moves: [
      { san: 'e4', from: 'e2', to: 'e4', note: 'White claims the center.' },
      { san: 'c5', from: 'c7', to: 'c5', note: 'Black strikes on the opposite side of the board instead of copying e5.' },
      { san: 'Nf3', from: 'g1', to: 'f3', note: 'Develops and prepares d4 to open the center.' },
      { san: 'd6', from: 'd7', to: 'd6', note: 'Supports a future e5 push and opens a path for the bishop.' },
      { san: 'd4', from: 'd2', to: 'd4', note: 'White strikes the center, inviting a trade of pawns.' },
      { san: 'cxd4', from: 'c5', to: 'd4', note: 'Black captures, opening the c-file for a future rook.' },
      { san: 'Nxd4', from: 'f3', to: 'd4', note: 'White recaptures, centralizing the knight.' },
      { san: 'Nf6', from: 'g8', to: 'f6', note: 'Develops while attacking the e4 pawn.' }
    ]
  }
];
