// ── Core chess types ────────────────────────────────────────────────────

export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type Color = 'w' | 'b';

export interface Piece {
  type: PieceType;
  color: Color;
}

export type Square = Piece | null;
export type Board = Square[][]; // board[row][col], row 0 = rank 8 (top, black side)

export interface Pos {
  row: number;
  col: number;
}

export interface CastlingRights {
  wK: boolean; // white king-side
  wQ: boolean; // white queen-side
  bK: boolean;
  bQ: boolean;
}

export interface GameState {
  board: Board;
  turn: Color;
  castling: CastlingRights;
  enPassant: Pos | null; // square a pawn can capture en passant onto
  halfmoveClock: number;
  moveNumber: number;
}

export interface Move {
  from: Pos;
  to: Pos;
  piece: Piece;
  captured?: Piece | null;
  promotion?: PieceType;
  isCastle?: 'K' | 'Q';
  isEnPassant?: boolean;
  notation?: string;
}

export interface MoveResult {
  state: GameState;
  move: Move;
  isCheck: boolean;
  isCheckmate: boolean;
  isStalemate: boolean;
}

// ── App / progress types ───────────────────────────────────────────────

export type StageId = 1 | 2 | 3 | 4 | 5;

export interface Progress {
  unlockedStage: StageId;
  xp: number;
  completedPuzzles: number[];
  completedOpenings: string[];
  stage1Seen: PieceType[];
}

export interface Puzzle {
  id: number;
  title: string;
  fenBoard: string; // simplified board-only FEN (piece placement field only)
  turn: Color;
  solution: string[]; // sequence of moves in "e2e4" style, alternating if needed
  explanation: string;
  wrongExplanation: string;
}

export interface Opening {
  id: string;
  name: string;
  description: string;
  moves: { san: string; from: string; to: string; note: string }[];
}
