interface TooltipProps {
  kind: 'good' | 'bad' | 'info';
  title: string;
  text: string;
  onClose: () => void;
  actionLabel?: string;
}

export default function Tooltip({ kind, title, text, onClose, actionLabel = 'Continue' }: TooltipProps) {
  return (
    <div className="tooltip-overlay" onClick={onClose}>
      <div className="tooltip-card" onClick={(e) => e.stopPropagation()}>
        <span className={`tooltip-card__badge ${kind === 'bad' ? 'bad' : 'good'}`}>
          {kind === 'bad' ? 'NOT QUITE' : kind === 'info' ? 'TIP' : 'NICE'}
        </span>
        <div className="section-title" style={{ fontSize: 18, margin: '2px 0 8px' }}>
          {title}
        </div>
        <p className="tooltip-card__text">{text}</p>
        <button className="btn btn--primary btn--block mt-16" onClick={onClose}>
          {actionLabel}
        </button>
      </div>
    </div>
  );
}
