import { useEffect, useRef, useState } from 'react';

interface TimerProps {
  initialSeconds: number;
  running: boolean;
  onExpire?: () => void;
  /** Bumping this resets the clock back to initialSeconds (e.g. starting a new game). */
  resetKey?: number | string;
}

export default function Timer({ initialSeconds, running, onExpire, resetKey }: TimerProps) {
  const [secondsLeft, setSecondsLeft] = useState(initialSeconds);
  const onExpireRef = useRef(onExpire);
  onExpireRef.current = onExpire;

  useEffect(() => {
    setSecondsLeft(initialSeconds);
  }, [resetKey, initialSeconds]);

  useEffect(() => {
    if (!running) return;
    if (secondsLeft <= 0) return;

    const id = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(id);
          onExpireRef.current?.();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, resetKey]);

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;
  const display = `${mins}:${secs.toString().padStart(2, '0')}`;

  return <div className={`clock ${secondsLeft <= 30 ? 'low' : ''}`}>{display}</div>;
}
