/* Bena Chess Tutor — Chess Engine
   Plain JS, no dependencies. Exposes window.ChessEngine
   Board layout: 8x8 array, row 0 = rank 8 (top, black home), row 7 = rank 1 (bottom, white home)
   col 0 = file a .. col 7 = file h
   Piece string: color + type, e.g. 'wP','bK'. null = empty square.
*/
(function (global) {
  const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

  function squareName(r, c) {
    return FILES[c] + (8 - r);
  }

  function createInitialBoard() {
    const back = ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'];
    const board = Array.from({ length: 8 }, () => Array(8).fill(null));
    for (let c = 0; c < 8; c++) {
      board[0][c] = 'b' + back[c];
      board[1][c] = 'bP';
      board[6][c] = 'wP';
      board[7][c] = 'w' + back[c];
    }
    return board;
  }

  function cloneBoard(board) {
    return board.map((row) => row.slice());
  }

  function inBounds(r, c) {
    return r >= 0 && r < 8 && c >= 0 && c < 8;
  }

  function color(piece) {
    return piece ? piece[0] : null;
  }
  function type(piece) {
    return piece ? piece[1] : null;
  }
  function opposite(c) {
    return c === 'w' ? 'b' : 'w';
  }

  function initialState() {
    return {
      board: createInitialBoard(),
      turn: 'w',
      castling: { wK: true, wQ: true, bK: true, bQ: true },
      enPassant: null, // [r,c] of the square that can be captured onto
      halfmove: 0,
      fullmove: 1,
      history: [], // list of moves made (for undo / display)
    };
  }

  const DIRS = {
    B: [[-1, -1], [-1, 1], [1, -1], [1, 1]],
    R: [[-1, 0], [1, 0], [0, -1], [0, 1]],
    Q: [[-1, -1], [-1, 1], [1, -1], [1, 1], [-1, 0], [1, 0], [0, -1], [0, 1]],
  };
  const KNIGHT_OFFSETS = [
    [-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1],
  ];
  const KING_OFFSETS = [
    [-1, -1], [-1, 0], [-1, 1], [0, -1], [0, 1], [1, -1], [1, 0], [1, 1],
  ];

  // Generates pseudo-legal moves (does not check for leaving own king in check)
  function pseudoMovesForSquare(state, r, c) {
    const { board } = state;
    const piece = board[r][c];
    if (!piece) return [];
    const col = color(piece);
    const t = type(piece);
    const moves = [];

    const pushMove = (tr, tc, extra) => {
      moves.push(Object.assign({ from: [r, c], to: [tr, tc], piece }, extra));
    };

    if (t === 'P') {
      const dir = col === 'w' ? -1 : 1;
      const startRow = col === 'w' ? 6 : 1;
      const promoRow = col === 'w' ? 0 : 7;
      const oneStep = r + dir;
      if (inBounds(oneStep, c) && !board[oneStep][c]) {
        if (oneStep === promoRow) {
          ['Q', 'R', 'B', 'N'].forEach((p) => pushMove(oneStep, c, { promotion: p }));
        } else {
          pushMove(oneStep, c, {});
        }
        const twoStep = r + dir * 2;
        if (r === startRow && !board[twoStep][c]) {
          pushMove(twoStep, c, { doubleStep: true });
        }
      }
      for (const dc of [-1, 1]) {
        const tr = r + dir;
        const tc = c + dc;
        if (!inBounds(tr, tc)) continue;
        const target = board[tr][tc];
        if (target && color(target) !== col) {
          if (tr === promoRow) {
            ['Q', 'R', 'B', 'N'].forEach((p) => pushMove(tr, tc, { capture: true, promotion: p }));
          } else {
            pushMove(tr, tc, { capture: true });
          }
        } else if (!target && state.enPassant && state.enPassant[0] === tr && state.enPassant[1] === tc) {
          pushMove(tr, tc, { capture: true, enPassant: true });
        }
      }
    } else if (t === 'N') {
      for (const [dr, dc] of KNIGHT_OFFSETS) {
        const tr = r + dr, tc = c + dc;
        if (!inBounds(tr, tc)) continue;
        const target = board[tr][tc];
        if (!target || color(target) !== col) pushMove(tr, tc, { capture: !!target });
      }
    } else if (t === 'B' || t === 'R' || t === 'Q') {
      for (const [dr, dc] of DIRS[t]) {
        let tr = r + dr, tc = c + dc;
        while (inBounds(tr, tc)) {
          const target = board[tr][tc];
          if (!target) {
            pushMove(tr, tc, {});
          } else {
            if (color(target) !== col) pushMove(tr, tc, { capture: true });
            break;
          }
          tr += dr; tc += dc;
        }
      }
    } else if (t === 'K') {
      for (const [dr, dc] of KING_OFFSETS) {
        const tr = r + dr, tc = c + dc;
        if (!inBounds(tr, tc)) continue;
        const target = board[tr][tc];
        if (!target || color(target) !== col) pushMove(tr, tc, { capture: !!target });
      }
      // castling
      const rights = state.castling;
      const homeRow = col === 'w' ? 7 : 0;
      if (r === homeRow && c === 4) {
        const kSide = col === 'w' ? rights.wK : rights.bK;
        const qSide = col === 'w' ? rights.wQ : rights.bQ;
        if (kSide && !board[homeRow][5] && !board[homeRow][6] &&
            !isSquareAttacked(state, homeRow, 4, opposite(col)) &&
            !isSquareAttacked(state, homeRow, 5, opposite(col)) &&
            !isSquareAttacked(state, homeRow, 6, opposite(col))) {
          pushMove(homeRow, 6, { castle: 'K' });
        }
        if (qSide && !board[homeRow][3] && !board[homeRow][2] && !board[homeRow][1] &&
            !isSquareAttacked(state, homeRow, 4, opposite(col)) &&
            !isSquareAttacked(state, homeRow, 3, opposite(col)) &&
            !isSquareAttacked(state, homeRow, 2, opposite(col))) {
          pushMove(homeRow, 2, { castle: 'Q' });
        }
      }
    }
    return moves;
  }

  function allPseudoMoves(state, col) {
    const moves = [];
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const p = state.board[r][c];
        if (p && color(p) === col) {
          moves.push(...pseudoMovesForSquare(state, r, c));
        }
      }
    }
    return moves;
  }

  function isSquareAttacked(state, r, c, byColor) {
    const { board } = state;
    // pawns
    const pawnDir = byColor === 'w' ? 1 : -1; // attacker pawn sits pawnDir away from target
    for (const dc of [-1, 1]) {
      const pr = r + pawnDir, pc = c + dc;
      if (inBounds(pr, pc)) {
        const p = board[pr][pc];
        if (p && color(p) === byColor && type(p) === 'P') return true;
      }
    }
    // knights
    for (const [dr, dc] of KNIGHT_OFFSETS) {
      const pr = r + dr, pc = c + dc;
      if (inBounds(pr, pc)) {
        const p = board[pr][pc];
        if (p && color(p) === byColor && type(p) === 'N') return true;
      }
    }
    // king
    for (const [dr, dc] of KING_OFFSETS) {
      const pr = r + dr, pc = c + dc;
      if (inBounds(pr, pc)) {
        const p = board[pr][pc];
        if (p && color(p) === byColor && type(p) === 'K') return true;
      }
    }
    // sliding: bishop/queen diagonals
    for (const [dr, dc] of DIRS.B) {
      let pr = r + dr, pc = c + dc;
      while (inBounds(pr, pc)) {
        const p = board[pr][pc];
        if (p) {
          if (color(p) === byColor && (type(p) === 'B' || type(p) === 'Q')) return true;
          break;
        }
        pr += dr; pc += dc;
      }
    }
    // sliding: rook/queen straight
    for (const [dr, dc] of DIRS.R) {
      let pr = r + dr, pc = c + dc;
      while (inBounds(pr, pc)) {
        const p = board[pr][pc];
        if (p) {
          if (color(p) === byColor && (type(p) === 'R' || type(p) === 'Q')) return true;
          break;
        }
        pr += dr; pc += dc;
      }
    }
    return false;
  }

  function findKing(board, col) {
    for (let r = 0; r < 8; r++)
      for (let c = 0; c < 8; c++)
        if (board[r][c] === col + 'K') return [r, c];
    return null;
  }

  function isInCheck(state, col) {
    const k = findKing(state.board, col);
    if (!k) return false;
    return isSquareAttacked(state, k[0], k[1], opposite(col));
  }

  function makeMove(state, move) {
    const board = cloneBoard(state.board);
    const [fr, fc] = move.from;
    const [tr, tc] = move.to;
    const piece = board[fr][fc];
    const col = color(piece);
    let capturedPiece = board[tr][tc];

    board[fr][fc] = null;

    if (move.enPassant) {
      const capRow = col === 'w' ? tr + 1 : tr - 1;
      capturedPiece = board[capRow][tc];
      board[capRow][tc] = null;
    }

    board[tr][tc] = move.promotion ? col + move.promotion : piece;

    let newCastling = Object.assign({}, state.castling);
    if (move.castle) {
      const homeRow = col === 'w' ? 7 : 0;
      if (move.castle === 'K') {
        board[homeRow][5] = board[homeRow][7];
        board[homeRow][7] = null;
      } else {
        board[homeRow][3] = board[homeRow][0];
        board[homeRow][0] = null;
      }
    }
    // update castling rights
    if (type(piece) === 'K') {
      if (col === 'w') { newCastling.wK = false; newCastling.wQ = false; }
      else { newCastling.bK = false; newCastling.bQ = false; }
    }
    const clearRookRight = (r, c) => {
      if (r === 7 && c === 0) newCastling.wQ = false;
      if (r === 7 && c === 7) newCastling.wK = false;
      if (r === 0 && c === 0) newCastling.bQ = false;
      if (r === 0 && c === 7) newCastling.bK = false;
    };
    clearRookRight(fr, fc);
    clearRookRight(tr, tc);

    let newEnPassant = null;
    if (move.doubleStep) {
      newEnPassant = [(fr + tr) / 2, fc];
    }

    const newState = {
      board,
      turn: opposite(state.turn),
      castling: newCastling,
      enPassant: newEnPassant,
      halfmove: (type(piece) === 'P' || capturedPiece) ? 0 : state.halfmove + 1,
      fullmove: col === 'b' ? state.fullmove + 1 : state.fullmove,
      history: state.history.concat([Object.assign({}, move, { captured: capturedPiece })]),
    };
    return newState;
  }

  function legalMoves(state, col) {
    col = col || state.turn;
    const pseudo = allPseudoMoves(state, col);
    const legal = [];
    for (const m of pseudo) {
      const next = makeMove(state, m);
      if (!isInCheck(next, col)) legal.push(m);
    }
    return legal;
  }

  function legalMovesForSquare(state, r, c) {
    const piece = state.board[r][c];
    if (!piece || color(piece) !== state.turn) return [];
    return legalMoves(state, state.turn).filter((m) => m.from[0] === r && m.from[1] === c);
  }

  function insufficientMaterial(board) {
    let minors = 0;
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) continue;
      const t = type(p);
      if (t === 'K') continue;
      if (t === 'N' || t === 'B') minors++; else return false;
    }
    return minors <= 1;
  }

  function gameStatus(state) {
    const moves = legalMoves(state, state.turn);
    const inCheck = isInCheck(state, state.turn);
    if (moves.length === 0) {
      return inCheck ? { status: 'checkmate', winner: opposite(state.turn) } : { status: 'stalemate' };
    }
    if (state.halfmove >= 100) return { status: 'draw', reason: 'fifty-move rule' };
    if (insufficientMaterial(state.board)) return { status: 'draw', reason: 'insufficient material' };
    return { status: inCheck ? 'check' : 'active' };
  }

  // --- Evaluation ---
  const VALUES = { P: 100, N: 320, B: 330, R: 500, Q: 900, K: 0 };
  const PAWN_TABLE = [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [50, 50, 50, 50, 50, 50, 50, 50],
    [10, 10, 20, 30, 30, 20, 10, 10],
    [5, 5, 10, 25, 25, 10, 5, 5],
    [0, 0, 0, 20, 20, 0, 0, 0],
    [5, -5, -10, 0, 0, -10, -5, 5],
    [5, 10, 10, -20, -20, 10, 10, 5],
    [0, 0, 0, 0, 0, 0, 0, 0],
  ];
  const KNIGHT_TABLE = [
    [-50, -40, -30, -30, -30, -30, -40, -50],
    [-40, -20, 0, 0, 0, 0, -20, -40],
    [-30, 0, 10, 15, 15, 10, 0, -30],
    [-30, 5, 15, 20, 20, 15, 5, -30],
    [-30, 0, 15, 20, 20, 15, 0, -30],
    [-30, 5, 10, 15, 15, 10, 5, -30],
    [-40, -20, 0, 5, 5, 0, -20, -40],
    [-50, -40, -30, -30, -30, -30, -40, -50],
  ];

  function evaluateBoard(board) {
    let score = 0;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const p = board[r][c];
        if (!p) continue;
        const col = color(p), t = type(p);
        let val = VALUES[t];
        if (t === 'P') val += col === 'w' ? PAWN_TABLE[r][c] : PAWN_TABLE[7 - r][c];
        if (t === 'N') val += col === 'w' ? KNIGHT_TABLE[r][c] : KNIGHT_TABLE[7 - r][c];
        score += col === 'w' ? val : -val;
      }
    }
    score += mopUp(board);
    return score; // positive favors white
  }

  // Endgame helper: when clearly ahead against a nearly bare king, drive that king to the edge
  // and bring our own king close. This is what turns a won position into a FAST checkmate.
  function mopUp(board) {
    let wk = null, bk = null, wm = 0, bm = 0, wp = 0, bp = 0;
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
      const p = board[r][c];
      if (!p) continue;
      const t = type(p), col = color(p);
      if (t === 'K') { if (col === 'w') wk = [r, c]; else bk = [r, c]; continue; }
      if (t === 'P') { if (col === 'w') wp++; else bp++; continue; }
      if (col === 'w') wm += VALUES[t]; else bm += VALUES[t];
    }
    if (!wk || !bk) return 0;
    const dist = Math.abs(wk[0] - bk[0]) + Math.abs(wk[1] - bk[1]);
    const edge = (k) => Math.abs(k[0] - 3.5) + Math.abs(k[1] - 3.5);
    if (wm - bm >= 250 && bm <= 500 && bp === 0) return 10 * edge(bk) + 4 * (14 - dist);
    if (bm - wm >= 250 && wm <= 500 && wp === 0) return -(10 * edge(wk) + 4 * (14 - dist));
    return 0;
  }

  function minimax(state, depth, alpha, beta, maximizing) {
    const status = gameStatus(state);
    if (status.status === 'checkmate') {
      return { score: maximizing ? -100000 - depth : 100000 + depth };
    }
    if (status.status === 'stalemate' || status.status === 'draw') return { score: 0 };
    if (depth === 0) return { score: evaluateBoard(state.board) };

    const moves = legalMoves(state, state.turn);
    // simple move ordering: captures first
    moves.sort((a, b) => (b.capture ? 1 : 0) - (a.capture ? 1 : 0));

    let bestMove = null;
    if (maximizing) {
      let best = -Infinity;
      for (const m of moves) {
        const next = makeMove(state, m);
        const { score } = minimax(next, depth - 1, alpha, beta, false);
        if (score > best) { best = score; bestMove = m; }
        alpha = Math.max(alpha, best);
        if (beta <= alpha) break;
      }
      return { score: best, move: bestMove };
    } else {
      let best = Infinity;
      for (const m of moves) {
        const next = makeMove(state, m);
        const { score } = minimax(next, depth - 1, alpha, beta, true);
        if (score < best) { best = score; bestMove = m; }
        beta = Math.min(beta, best);
        if (beta <= alpha) break;
      }
      return { score: best, move: bestMove };
    }
  }

  function findBestMove(state, depth) {
    const maximizing = state.turn === 'w';
    const { score, move } = minimax(state, depth, -Infinity, Infinity, maximizing);
    return move;
  }

  // Explain quality of a move the human just played, compared to what the engine would have done.
  function explainMove(stateBefore, move, depth) {
    const mover = stateBefore.turn;
    const maximizing = mover === 'w';
    const bestResult = minimax(stateBefore, depth, -Infinity, Infinity, maximizing);
    const bestMove = bestResult.move;
    const bestScore = bestResult.score;

    const afterPlayed = makeMove(stateBefore, move);
    const playedEval = minimax(afterPlayed, Math.max(depth - 1, 1), -Infinity, Infinity, !maximizing).score;

    // scores are from white's perspective; convert to "mover's favor"
    const bestForMover = maximizing ? bestScore : -bestScore;
    const playedForMover = maximizing ? playedEval : -playedEval;
    const lossCentipawns = Math.max(0, bestForMover - playedForMover);
    const lossPawns = lossCentipawns / 100;

    let quality, tone;
    if (lossPawns < 0.35) { quality = 'Good move'; tone = 'good'; }
    else if (lossPawns < 1.0) { quality = 'Inaccuracy'; tone = 'ok'; }
    else if (lossPawns < 2.5) { quality = 'Mistake'; tone = 'warn'; }
    else { quality = 'Blunder'; tone = 'bad'; }

    // See what the opponent's best reply is, to describe the concrete consequence
    const oppBest = minimax(afterPlayed, 1, -Infinity, Infinity, afterPlayed.turn === 'w');
    let consequenceText = '';
    if (lossPawns >= 1.0 && oppBest.move) {
      const target = afterPlayed.board[oppBest.move.from[0]][oppBest.move.from[1]];
      const capturedAt = afterPlayed.board[oppBest.move.to[0]][oppBest.move.to[1]];
      if (oppBest.move.capture && capturedAt) {
        consequenceText = `This lets the opponent play ${squareName(oppBest.move.from[0], oppBest.move.from[1])}-${squareName(oppBest.move.to[0], oppBest.move.to[1])}, winning your ${pieceName(capturedAt)} on ${squareName(oppBest.move.to[0], oppBest.move.to[1])}.`;
      } else {
        consequenceText = `It gives the opponent a strong reply, ${squareName(oppBest.move.from[0], oppBest.move.from[1])}-${squareName(oppBest.move.to[0], oppBest.move.to[1])}, that swings the position in their favor.`;
      }
    }

    let suggestion = '';
    if (bestMove && lossPawns >= 0.35) {
      suggestion = `A stronger idea here was ${squareName(bestMove.from[0], bestMove.from[1])}-${squareName(bestMove.to[0], bestMove.to[1])}.`;
    }

    return {
      quality,
      tone,
      lossPawns: Math.round(lossPawns * 10) / 10,
      text: [quality + '.', consequenceText, suggestion].filter(Boolean).join(' '),
      bestMove,
    };
  }


  // ===== Smart move selection (used by the opponent AND by the hint button) =====
  const MATE = 100000;

  function positionKey(state) {
    let k = '';
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) k += (state.board[r][c] || '--');
    const ca = state.castling;
    return k + state.turn + (ca.wK ? 'K' : '') + (ca.wQ ? 'Q' : '') + (ca.bK ? 'k' : '') + (ca.bQ ? 'q' : '') +
      (state.enPassant ? state.enPassant[1] : '');
  }

  function evalFor(state) {
    const e = evaluateBoard(state.board);
    return state.turn === 'w' ? e : -e;
  }

  function orderMoves(state, moves, prev) {
    const b = state.board;
    const sc = (m) => {
      let s = 0;
      if (prev && prev.has(m)) s += 100000 + prev.get(m);
      const v = b[m.to[0]][m.to[1]];
      if (m.capture || v) s += 10 * (VALUES[type(v || 'wP')] || 100) - (VALUES[type(b[m.from[0]][m.from[1]])] || 0) / 10;
      if (m.promotion) s += 800;
      return s;
    };
    return moves.map((m) => [m, sc(m)]).sort((a, b2) => b2[1] - a[1]).map((x) => x[0]);
  }

  function negamax(state, depth, alpha, beta, ctx) {
    if (ctx.canAbort && ctx.deadline && ((++ctx.nodes) & 127) === 0 && Date.now() > ctx.deadline) ctx.abort = true;
    if (ctx.abort) return 0;
    const moves = legalMoves(state, state.turn);
    if (moves.length === 0) return isInCheck(state, state.turn) ? -(MATE + depth) : 0;
    if (state.halfmove >= 100) return 0;
    if (depth <= 0) return evalFor(state);
    let best = -Infinity;
    for (const m of orderMoves(state, moves)) {
      const s = -negamax(makeMove(state, m), depth - 1, -beta, -alpha, ctx);
      if (ctx.abort) return 0;
      if (s > best) best = s;
      if (best > alpha) alpha = best;
      if (alpha >= beta) break;
    }
    return best;
  }

  // one full root pass at a fixed depth. Returns null if the clock ran out.
  function searchRoot(state, depth, noise, counts, ctx, prev) {
    const moves = orderMoves(state, legalMoves(state, state.turn), prev);
    const out = [];
    let best = -Infinity;
    for (const m of moves) {
      const next = makeMove(state, m);
      const cnt = (counts && counts[positionKey(next)]) || 0;
      let s;
      if (cnt + 1 >= 3) s = 0; // would be a draw by threefold repetition
      else {
        const lo = best === -Infinity ? -Infinity : best - noise - 1;
        s = -negamax(next, depth - 1, -Infinity, -lo, ctx);
        if (ctx.abort) return null;
        if (cnt >= 1) s -= 40; // repeating positions gets us nowhere
        if (state.halfmove >= 80 && (m.capture || type(state.board[m.from[0]][m.from[1]]) === 'P')) s += 30;
      }
      out.push({ move: m, score: s });
      if (s > best) best = s;
    }
    return { list: out, best };
  }

  // ---- forced mate finder (attacker to move wants mate within n of its own moves) ----
  function mateIn1(state) {
    for (const m of legalMoves(state, state.turn)) {
      const nx = makeMove(state, m);
      if (!isInCheck(nx, nx.turn)) continue;
      if (legalMoves(nx, nx.turn).length === 0) return m;
    }
    return null;
  }

  function mateSearch(state, n, ctx) {
    if (ctx.abort) return null;
    if (n === 1) return mateIn1(state);
    if (((++ctx.nodes) & 63) === 0 && Date.now() > ctx.deadline) { ctx.abort = true; return null; }
    const cands = [];
    for (const m of legalMoves(state, state.turn)) {
      const nx = makeMove(state, m);
      const chk = isInCheck(nx, nx.turn);
      if (!chk && n >= 3 && !ctx.wide) continue; // long mates: look at checks only (unless few pieces left)
      cands.push([m, nx, chk]);
    }
    cands.sort((a, b) => (b[2] ? 1 : 0) - (a[2] ? 1 : 0));
    for (const [m, nx, chk] of cands) {
      const replies = legalMoves(nx, nx.turn);
      if (replies.length === 0) { if (chk) return m; continue; }
      if (nx.halfmove >= 100) continue;
      let all = true;
      for (const r of replies) {
        if (!mateSearch(makeMove(nx, r), n - 1, ctx)) { all = false; break; }
        if (ctx.abort) return null;
      }
      if (all) return m;
      if (ctx.abort) return null;
    }
    return null;
  }

  function findMate(state, maxN, ms) {
    let pieces = 0;
    for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) if (state.board[r][c]) pieces++;
    const ctx = { abort: false, nodes: 0, deadline: Date.now() + ms, wide: pieces <= 6 };
    for (let n = 1; n <= maxN; n++) {
      const m = mateSearch(state, n, ctx);
      if (m) return { move: m, n };
      if (ctx.abort) break;
    }
    return null;
  }

  // cfg: { depth, noise, ms, aiMate, hintMate, hintDepth }
  function chooseMove(state, cfg, counts, purpose) {
    const hint = purpose === 'hint';
    const mateN = hint ? (cfg.hintMate || 0) : (cfg.aiMate || 0);
    if (mateN > 0) {
      const r = findMate(state, mateN, hint ? 1500 : 900);
      if (r) return { move: r.move, mate: r.n, score: MATE };
    }
    const maxDepth = Math.max(1, hint ? (cfg.hintDepth || cfg.depth || 2) : (cfg.depth || 1));
    const noise = hint ? 0 : (cfg.noise || 0);
    const ms = hint ? Math.min(cfg.ms || 2500, 2500) : (cfg.ms || 1500);
    const ctx = { abort: false, nodes: 0, deadline: Date.now() + ms, canAbort: false };
    let result = null, prev = null;
    for (let d = 1; d <= maxDepth; d++) {
      ctx.canAbort = d > 1; ctx.abort = false;
      const res = searchRoot(state, d, d === maxDepth ? noise : 0, counts, ctx, prev);
      if (!res) break;
      result = res;
      prev = new Map(res.list.map((x) => [x.move, x.score]));
      if (res.best >= MATE) break;
    }
    if (!result) return { move: null };
    const pool = result.list.filter((x) => x.score >= result.best - noise);
    // prefer the highest score; with noise, pick any near-best move (human-like mistakes at low levels)
    const pick = noise > 0 ? pool[Math.floor(Math.random() * pool.length)] : result.list.reduce((a, b) => (b.score > a.score ? b : a));
    return { move: pick.move, score: pick.score };
  }

  function pieceName(piece) {
    const names = { P: 'pawn', N: 'knight', B: 'bishop', R: 'rook', Q: 'queen', K: 'king' };
    return names[type(piece)] || 'piece';
  }

  global.ChessEngine = {
    initialState,
    createInitialBoard,
    cloneBoard,
    color,
    type,
    opposite,
    squareName,
    legalMoves,
    legalMovesForSquare,
    makeMove,
    isInCheck,
    gameStatus,
    evaluateBoard,
    findBestMove,
    explainMove,
    pieceName,
    chooseMove,
    findMate,
    positionKey,
    insufficientMaterial,
  };
})(window);
