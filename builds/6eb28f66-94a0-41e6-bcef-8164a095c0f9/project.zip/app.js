/* Bena Chess Tutor — App shell, vanilla JS (no framework, zero dependencies) */
(function () {
  const { h, mount } = window.DOM;
  const LEVELS = window.BenaLevels.LEVELS;

  const root = document.getElementById('root');
  const topbar = h('div', { class: 'topbar' });
  const contentArea = h('div', {});
  root.appendChild(topbar);
  root.appendChild(contentArea);

  let screen = 'home';
  let activeLevel = null;
  let mode3d = false;
  let backFn = null;
  let currentScreenHandle = null; // for setMode3d / destroy hooks

  function destroyCurrentScreen() {
    if (currentScreenHandle && currentScreenHandle.destroy) currentScreenHandle.destroy();
    currentScreenHandle = null;
  }

  function goHome() {
    destroyCurrentScreen();
    screen = 'home';
    activeLevel = null;
    renderAll();
  }

  function openLevel(level) {
    destroyCurrentScreen();
    activeLevel = level;
    backFn = level.classic ? goClassic : goLevels;
    screen = level.type === 'lesson' ? 'lesson' : 'play';
    renderAll();
  }

  function goLevels() {
    destroyCurrentScreen();
    screen = 'levels';
    renderAll();
  }

  function goClassic() {
    destroyCurrentScreen();
    screen = 'classic';
    renderAll();
  }

  function openOffline() {
    destroyCurrentScreen();
    screen = 'offline';
    renderAll();
  }

  function openOnline() {
    destroyCurrentScreen();
    screen = 'online';
    renderAll();
  }

  function setMode3d(v) {
    mode3d = v;
    if (currentScreenHandle && currentScreenHandle.setMode3d) currentScreenHandle.setMode3d(v);
    renderTopbar();
  }

  function pieceIcon(code) {
    const wrap = h('span', { class: 'icon-piece' });
    wrap.appendChild(window.BenaPieces.buildPieceSvg(code));
    return wrap;
  }

  function renderTopbar() {
    mount(topbar,
      h('div', { class: 'brand', onClick: goHome }, [
        pieceIcon('bK'),
        h('span', { class: 'brand-name' }, [h('b', {}, ['Bena']), ' Chess Tutor']),
      ]),
      h('div', { class: 'topbar-actions' }, [
        h('div', { class: 'pill-toggle' }, [
          h('button', { class: !mode3d ? 'active' : '', onClick: () => setMode3d(false) }, ['2D']),
          h('button', { class: mode3d ? 'active' : '', onClick: () => setMode3d(true) }, ['3D']),
        ]),
        screen !== 'home' && h('button', { class: 'icon-btn', onClick: goHome }, ['Home']),
      ])
    );
  }

  function renderHome() {
    const hero = h('div', { class: 'hero' }, [
      h('div', { class: 'hero-eyebrow' }, ['Learn chess the right way']),
      h('h1', {}, ['Real teaching. Real games. ', h('em', {}, ['Zero trolling.'])]),
      h('p', {}, [
        'Six structured levels take you from "how does a knight move" to full games with professional-style coaching \u2014 plus 3D and 2D boards, and offline or online play with a friend.',
      ]),
    ]);

    const modeGrid = h('div', { class: 'mode-grid' }, [
      h('button', { class: 'mode-card', onClick: goLevels }, [
        pieceIcon('bK'),
        h('h3', {}, ['Learn \u2014 6 Levels']),
        h('p', {}, ['Guided lessons on piece movement, opening principles and tactics, then real games with live coaching against a built-in opponent.']),
      ]),
      h('button', { class: 'mode-card', onClick: goClassic }, [
        pieceIcon('wR'),
        h('h3', {}, ['Classic Play \u2014 10 Levels']),
        h('p', {}, ['Just chess: no lessons, no coach. Ten opponents from Rookie to Legend, with hints and unlimited undo.']),
      ]),
      h('button', { class: 'mode-card', onClick: openOffline }, [
        pieceIcon('bN'),
        h('h3', {}, ['Play Offline (pass & play)']),
        h('p', {}, ['Two players, one phone. The board fills the whole screen, auto-flips between turns, and works in vertical or horizontal orientation.']),
      ]),
      h('button', { class: 'mode-card', onClick: openOnline }, [
        pieceIcon('bQ'),
        h('h3', {}, ['Play Online']),
        h('p', {}, ['Connect directly to a friend with a one-time room code \u2014 no account, no server, just a live synced game.']),
      ]),
    ]);

    mount(contentArea, hero, modeGrid);
    contentArea.className = 'main-area';
  }

  function renderLevels(list, maxStars, title, sub) {
    list = list || LEVELS; maxStars = maxStars || 6;
    const cards = list.map((lvl) => {
      const stars = '\u2605'.repeat(lvl.difficulty) + '\u2606'.repeat(maxStars - lvl.difficulty);
      return h('div', { class: 'level-card' }, [
        h('span', { class: `level-tag ${lvl.type === 'play' ? 'play' : ''}` }, [lvl.type === 'play' ? 'Real game' : 'Lesson']),
        h('h3', {}, [lvl.title]),
        h('div', { class: 'sub' }, [lvl.subtitle]),
        h('div', { class: 'stars' }, [stars]),
        h('p', {}, [lvl.description]),
        h('button', { onClick: () => openLevel(lvl) }, [lvl.type === 'play' ? 'Play' : 'Start lessons']),
      ]);
    });

    mount(contentArea,
      h('h2', { class: 'section-title' }, [title || 'Choose your level']),
      h('p', { class: 'section-sub' }, [sub || 'Levels 1-3 are guided lessons. Levels 4-6 are real games with live coaching.']),
      h('div', { class: 'level-grid' }, cards),
    );
    contentArea.className = 'main-area';
  }

  function renderAll() {
    renderTopbar();
    if (screen === 'home') { renderHome(); return; }
    if (screen === 'levels') { renderLevels(); return; }
    if (screen === 'classic') { renderLevels(window.BenaLevels.CLASSIC, 10, 'Classic Play', '10 plain games, no lessons and no coach. Each level is a stronger opponent.'); return; }
    if (screen === 'lesson') { currentScreenHandle = window.renderLessonMode(contentArea, activeLevel, mode3d, goLevels); return; }
    if (screen === 'play') { currentScreenHandle = window.renderPlayMode(contentArea, activeLevel, mode3d, backFn || goLevels); return; }
    if (screen === 'offline') { currentScreenHandle = window.renderOfflineMode(contentArea, mode3d, goHome); return; }
    if (screen === 'online') { currentScreenHandle = window.renderOnlineMode(contentArea, mode3d, goHome); return; }
  }

  renderAll();
})();
