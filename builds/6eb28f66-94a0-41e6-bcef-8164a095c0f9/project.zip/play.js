/* Bena Chess Tutor — Play vs AI mode (Levels 4-6), vanilla JS */
function renderPlayMode(container, level, mode3d, onExit) {
  const CE = window.ChessEngine;
  const { h, mount } = window.DOM;
  const depth = level.aiDepth || 2;
  const humanColor = 'w';

  let state = CE.initialState();
  let lastMove = null;
  let coaching = null;
  let thinking = false;
  let hintArrow = null;
  let history = [];
  let aiTimer = null;
  let hintNote = '';
  const cfg = level.cfg || { depth: depth, noise: 0, ms: 1200, aiMate: 1, hintMate: 2, hintDepth: Math.max(depth, 2) };
  let posKeys = [CE.positionKey(state)];
  let undoStack = []; // snapshots taken just before each of your moves
  const countsOf = () => { const c = {}; posKeys.forEach((k) => { c[k] = (c[k] || 0) + 1; }); return c; };
  function getStatus() {
    const st = CE.gameStatus(state);
    if ((st.status === 'active' || st.status === 'check') && countsOf()[CE.positionKey(state)] >= 3) {
      return { status: 'draw', reason: 'threefold repetition' };
    }
    return st;
  }

  const boardView = window.createBoardView({
    mode3d, flipped: false, interactive: true, size: 'normal',
    onUserMove: handleUserMove,
  });

  function describeMove(m, board) {
    const p = board[m.from[0]][m.from[1]];
    return `${CE.pieceName(p)} ${CE.squareName(m.from[0], m.from[1])}-${CE.squareName(m.to[0], m.to[1])}`;
  }

  function handleUserMove(move) {
    if (state.turn !== humanColor || thinking) return;
    hintArrow = null; hintNote = '';
    undoStack.push({ state, lastMove, coaching, history: history.slice(), posKeys: posKeys.slice() });
    const before = state;
    const explanation = level.coaching ? CE.explainMove(before, move, Math.max(depth, 1)) : null;
    const next = CE.makeMove(before, move);
    history = history.concat([describeMove(move, before.board)]);
    state = next;
    posKeys.push(CE.positionKey(state));
    lastMove = move;
    if (explanation) coaching = explanation;
    thinking = true;
    render();
    scheduleAI();
  }

  function scheduleAI() {
    if (aiTimer) clearTimeout(aiTimer);
    if (state.turn === humanColor) return;
    const st = getStatus();
    if (st.status === 'checkmate' || st.status === 'stalemate' || st.status === 'draw') {
      thinking = false;
      render();
      return;
    }
    aiTimer = setTimeout(() => {
      const pick = CE.chooseMove(state, cfg, countsOf(), 'ai');
      const move = pick && pick.move;
      if (move) {
        history = history.concat([describeMove(move, state.board)]);
        lastMove = move;
        state = CE.makeMove(state, move);
        posKeys.push(CE.positionKey(state));
      }
      thinking = false;
      render();
    }, 550 + Math.random() * 500);
  }

  function requestHint() {
    if (state.turn !== humanColor || thinking) return;
    const pick = CE.chooseMove(state, cfg, countsOf(), 'hint');
    const move = pick && pick.move;
    if (move) {
      hintArrow = { from: move.from, to: move.to };
      const mv = `${CE.squareName(move.from[0], move.from[1])}-${CE.squareName(move.to[0], move.to[1])}`;
      if (pick.mate) hintNote = `Hint: forced checkmate in ${pick.mate}! Start with ${mv}.`;
      else if (move.capture) hintNote = `Hint: ${mv} wins material and keeps the pressure on.`;
      else hintNote = `Hint: ${mv} is the strongest move here. Aim for a quick checkmate, and avoid repeating positions (3 repeats is a draw).`;
    } else hintNote = 'No legal moves available.';
    render();
  }

  function undo() {
    if (!undoStack.length) return;
    if (aiTimer) clearTimeout(aiTimer);
    const snap = undoStack.pop();
    state = snap.state; lastMove = snap.lastMove; coaching = snap.coaching;
    history = snap.history; posKeys = snap.posKeys;
    hintArrow = null; hintNote = ''; thinking = false;
    render();
  }

  function resetGame() {
    if (aiTimer) clearTimeout(aiTimer);
    state = CE.initialState();
    lastMove = null;
    coaching = null;
    hintArrow = null; hintNote = '';
    history = [];
    posKeys = [CE.positionKey(state)];
    undoStack = [];
    thinking = false;
    render();
  }

  function render() {
    const status = getStatus();
    boardView.setState(state, {
      mode3d, flipped: false,
      interactive: state.turn === humanColor && !thinking && (status.status === 'active' || status.status === 'check'),
      lastMove, arrow: hintArrow, appliedMove: lastMove,
    });

    let statusText = state.turn === humanColor ? 'Your move' : (thinking ? 'Opponent is thinking\u2026' : "Opponent's move");
    if (status.status === 'checkmate') statusText = `Checkmate \u2014 ${status.winner === humanColor ? 'You win!' : 'The opponent wins.'}`;
    else if (status.status === 'stalemate') statusText = 'Stalemate \u2014 the game is a draw.';
    else if (status.status === 'draw') statusText = `Draw \u2014 ${status.reason || 'the game is drawn'}.`;
    else if (status.status === 'check') statusText += ' \u00b7 Check!';

    const statusBar = h('div', { class: 'status-bar' }, [
      h('span', { class: `turn-dot ${state.turn}` }),
      h('span', {}, [statusText]),
    ]);

    const btnRow = h('div', { class: 'btn-row' }, [
      h('button', { class: 'btn secondary', onClick: undo, disabled: undoStack.length === 0, 'aria-label': 'Undo', title: 'Undo' }, ['\u21B6 Undo']),
      h('button', { class: 'btn secondary', onClick: requestHint, disabled: state.turn !== humanColor || thinking }, ['Show hint']),
      h('button', { class: 'btn secondary', onClick: resetGame }, ['New game']),
    ]);

    const boardColumn = h('div', { class: 'board-column' }, [statusBar, boardView.el, btnRow, hintNote ? h('p', { class: 'hint-note' }, [hintNote]) : null]);

    const coachBox = coaching
      ? h('div', { class: `coach-box tone-${coaching.tone}` }, [
          h('span', { class: 'coach-title' }, [coaching.quality]),
          coaching.text,
        ])
      : h('p', {}, ["Play a move \u2014 you'll get instant, professional feedback here, not just a score."]);

    const moveList = h('div', { class: 'move-history' },
      history.length === 0
        ? [h('div', {}, ['No moves yet.'])]
        : history.map((mv, i) => h('div', {}, [`${i + 1}. ${mv}`]))
    );

    const sidePanel = h('div', { class: 'side-panel' }, level.coaching ? [
      h('h4', {}, ['Coach']),
      coachBox,
      h('h4', { style: { marginTop: '18px' } }, ['Move list']),
      moveList,
    ] : [
      h('h4', {}, ['Move list']),
      moveList,
    ]);

    mount(container,
      h('button', { class: 'back-link', onClick: onExit }, ['\u2190 Levels']),
      h('h2', { class: 'section-title' }, [level.title]),
      h('p', { class: 'section-sub' }, [level.subtitle]),
      h('div', { class: 'play-layout' }, [boardColumn, sidePanel]),
    );
    container.className = 'main-area';
  }

  render();
  return {
    setMode3d: (v) => { mode3d = v; render(); },
    destroy: () => { if (aiTimer) clearTimeout(aiTimer); },
  };
}

window.renderPlayMode = renderPlayMode;
